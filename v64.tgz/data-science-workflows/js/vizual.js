/* ===========================================================================
   COMPONENTE VIZUALE

   Lucrurile pe care un tabel le descrie, dar nu le arată: un pachet care
   pleacă și se întoarce, un fișier care trece prin zonele lui Git, o ramură
   care se desprinde și se întoarce, un conflict care trebuie rezolvat cu
   mâna.

   Toate sunt desenate cu HTML și SVG, fără biblioteci: pagina trebuie să se
   deschidă repede pe wifi-ul facultății, cu douăzeci și cinci de oameni pe el.

   Cele care cer o decizie sunt porți: se salvează, apar la profesor, și
   deschid slide-ul următor. Cele care doar arată ceva, nu.
   =========================================================================== */

const V = {};

const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;");

/** O poartă trecută, scrisă și în baza de date. */
async function poarta(gazda, id, ce = ""){
  const ix = gazda.closest(".ix");
  if (ix){
    if (ix.classList.contains("gata")) return;
    ix.classList.add("gata");
  }
  document.dispatchEvent(new CustomEvent("poarta:gata", { detail:{ id } }));
  try {
    const m = await import("/data-science-workflows/js/colectare.js?v=64");
    await m.salveazaCod({ exercitiuId: id, cod: String(ce).slice(0, 400), trecut: true });
  } catch { /* fără cont, poarta se deschide oricum */ }
}


/* ===========================================================================
   1. FLUX — un pachet care pleacă și se întoarce

   Pentru analogia restaurantului și pentru arhitectura REST: aceleași stații,
   alt vocabular. Apeși „trimite" și vezi unde ajunge cererea, pas cu pas.
   =========================================================================== */

V.flux = (gazda, d) => {
  const S = d.statii || [];
  let pas = -1, ceas = null;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="flx">
      <div class="flx__sina">
        ${S.map((s, i) => `
          <div class="flx__s${s.c ? " flx__s--c" : ""}" data-i="${i}"${s.c ? ` style="--fc:var(--${s.c})"` : ""}>
            <span class="flx__ic">${s.ic || "●"}</span>
            <span class="flx__n">${esc(s.n)}</span>
            <span class="flx__et">${esc(s.et || "")}</span>
          </div>
          ${i < S.length - 1 ? `<div class="flx__leg" data-l="${i}">
             <span class="flx__pachet"></span></div>` : ""}`).join("")}
      </div>
      <div class="flx__act">
        <button class="btn btn--mic btn--tare" data-rol="porneste" type="button">
          ${esc(d.buton || "Trimite cererea")}</button>
        <span class="flx__stare"></span>
      </div>
      <div class="flx__i"><h5>${esc(d.titlu || "Apasă pe o stație")}</h5>
        <p>${d.intro || ""}</p></div>
    </div>`;

  const sine  = [...gazda.querySelectorAll(".flx__s")];
  const legi  = [...gazda.querySelectorAll(".flx__leg")];
  const info  = gazda.querySelector(".flx__i");
  const stare = gazda.querySelector(".flx__stare");
  const bt    = gazda.querySelector('[data-rol="porneste"]');

  const arata = i => {
    const s = S[i];
    sine.forEach((x, k) => x.classList.toggle("on", k === i));
    info.innerHTML = `<h5>${esc(s.n)}${s.et ? ` <small>${esc(s.et)}</small>` : ""}</h5>
      <p>${s.d || ""}</p>`;
  };

  gazda.addEventListener("click", e => {
    const s = e.target.closest(".flx__s");
    if (s){ pas = +s.dataset.i; arata(pas); }
  });

  bt.onclick = () => {
    clearInterval(ceas);
    sine.forEach(x => x.classList.remove("on", "atins"));
    legi.forEach(x => x.classList.remove("dus", "intors"));
    let i = 0, inapoi = false;
    stare.textContent = d.dus || "cererea pleacă";
    arata(0); sine[0].classList.add("atins");

    ceas = setInterval(() => {
      if (!inapoi){
        if (i >= S.length - 1){
          inapoi = true;
          stare.textContent = d.intors || "răspunsul se întoarce";
          return;
        }
        legi[i].classList.add("dus");
        i++; sine[i].classList.add("atins"); arata(i);
      } else {
        if (i <= 0){
          clearInterval(ceas);
          stare.textContent = d.gata || "gata, ai răspunsul";
          return;
        }
        i--; legi[i].classList.add("intors"); arata(i);
      }
    }, 820);
  };

  arata(0);
};


/* ===========================================================================
   2. CRONOLOGIE — o axă cu ani

   Lista de ani dintr-un tabel nu spune nimic despre ritm. O axă spune: se
   vede că între 1991 și 2000 s-a încercat de patru ori, și că de atunci s-a
   mai schimbat de două ori.
   =========================================================================== */

V.cronologie = (gazda, d) => {
  const P = (d.puncte || []).slice().sort((a, b) => a.an - b.an);
  if (!P.length) return;
  const a0 = P[0].an, a1 = P[P.length - 1].an, lat = Math.max(1, a1 - a0);
  /* nu de la 0 la 100: primul și ultimul punct ar fi tăiate pe jumătate de
     marginea casetei, iar anul lor n-ar mai încăpea întreg */
  const MARG = 7;
  const poz = p => MARG + ((p.an - a0) / lat) * (100 - 2 * MARG);

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="crn">
      <div class="crn__axa">
        <span class="crn__linie"></span>
        ${P.map((p, i) => `
          <button class="crn__p ${i % 2 ? "jos" : "sus"}" data-i="${i}" type="button"
                  style="left:${poz(p)}%">
            <span class="crn__an">${p.an}</span>
            <span class="crn__nod"></span>
            <span class="crn__nume">${esc(p.nume)}</span>
          </button>`).join("")}
      </div>
      <div class="crn__bara"><button class="btn btn--mic btn--tare" data-rol="joc" type="button">▶ Derulează</button>
        <span class="crn__prog"><i></i></span></div>
      <div class="crn__i"><h5>${esc(d.titlu || "Apasă pe oricare")}</h5>
        <p>${d.intro || ""}</p></div>
    </div>`;

  const info = gazda.querySelector(".crn__i"), joc = gazda.querySelector('[data-rol="joc"]'), prog = gazda.querySelector(".crn__prog i");
  let t = null, k = -1;
  function arata(i){
    k = i;
    gazda.querySelectorAll(".crn__p").forEach((x, j) => { x.classList.toggle("on", j === i); x.classList.toggle("trecut", j < i); });
    const p = P[i];
    info.innerHTML = `<h5>${p.an} · ${esc(p.nume)}${
      p.et ? ` <small>${esc(p.et)}</small>` : ""}</h5><p>${p.text || ""}</p>`;
    prog.style.width = ((i + 1) / P.length * 100) + "%";
  }
  /* derularea: un an după altul, ca la proiector; un clic pe un an o oprește */
  function opreste(){ clearInterval(t); t = null; joc.textContent = k >= P.length - 1 ? "↺ De la capăt" : "▶ Derulează"; }
  joc.onclick = () => {
    if (t) return opreste();
    if (k >= P.length - 1) k = -1;
    joc.textContent = "❚❚ Pauză";
    arata(k + 1);
    t = setInterval(() => { if (k >= P.length - 1) return opreste(); arata(k + 1); }, 2200);
  };
  gazda.addEventListener("click", e => {
    const b = e.target.closest(".crn__p");
    if (!b) return;
    opreste(); arata(+b.dataset.i); opreste();
  });
};


/* ===========================================================================
   3. RĂSPUNS — ce întoarce serverul

   Codurile de stare se învață prost dintr-un tabel și bine dintr-o cerere
   care eșuează sub ochii tăi. Alegi o situație, apeși trimite, vezi codul.
   =========================================================================== */

V.raspuns = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  const C = d.cazuri || [];
  const incercate = new Set();
  let ales = 0;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="rsp">
      <div class="rsp__cazuri">${C.map((c, i) =>
        `<button class="rsp__c ${i ? "" : "on"}" data-i="${i}" type="button">${esc(c.et)}</button>`).join("")}</div>
      <div class="rsp__bara">
        <span class="rsp__met">GET</span>
        <code class="rsp__url">${esc(C[0]?.url || "")}</code>
        <button class="btn btn--mic btn--tare" data-rol="trimite" type="button">Trimite</button>
      </div>
      <div class="rsp__out" hidden>
        <div class="rsp__cod"><b></b><span></span></div>
        <pre class="rsp__corp"></pre>
        <p class="rsp__ce"></p>
      </div>
      <p class="rsp__nr"></p>
      <p class="ex__stare"></p>
    </div>`;

  const url  = gazda.querySelector(".rsp__url");
  const out  = gazda.querySelector(".rsp__out");
  const cod  = gazda.querySelector(".rsp__cod");
  const corp = gazda.querySelector(".rsp__corp");
  const ce   = gazda.querySelector(".rsp__ce");
  const nr   = gazda.querySelector(".rsp__nr");
  const st   = gazda.querySelector(".ex__stare");

  const numara = () => {
    nr.textContent = `${incercate.size} din ${C.length} încercate`;
    nr.classList.toggle("gata", incercate.size >= C.length);
  };

  gazda.addEventListener("click", e => {
    const b = e.target.closest(".rsp__c");
    if (!b) return;
    gazda.querySelectorAll(".rsp__c").forEach(x => x.classList.toggle("on", x === b));
    ales = +b.dataset.i;
    url.textContent = C[ales].url || "";
    out.hidden = true;
  });

  gazda.querySelector('[data-rol="trimite"]').onclick = async () => {
    const c = C[ales];
    out.hidden = false;
    const fel = c.cod < 300 ? "ok" : c.cod < 500 ? "tu" : "ei";
    cod.className = "rsp__cod rsp__cod--" + fel;
    cod.querySelector("b").textContent = c.cod;
    cod.querySelector("span").textContent = c.nume || "";
    corp.textContent = c.corp || "";
    ce.innerHTML = c.ce || "";
    incercate.add(ales);
    numara();
    if (incercate.size >= C.length){
      const salvat = await poarta(gazda, d.id, [...incercate].join(","));
      st.textContent = "Le-ai încercat pe toate.";
      st.classList.add("vazut");
    }
  };

  numara();
};


/* ===========================================================================
   4. ZONE — cele trei zone ale lui Git

   Modelul mental fără de care comenzile lui Git se învață pe de rost. Aici nu
   se citește, se mută: apeși comanda și vezi unde ajung fișierele.
   =========================================================================== */

V.zone = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  const ZONE = [
    { t: "Dosarul de lucru", d: "aici editezi" },
    { t: "Pregătire", d: "ce intră în commit" },
    { t: "Istoric local", d: "commit-urile tale" },
    { t: "GitHub", d: "copia de pe internet" },
  ];
  const COM = [
    { c: "git status", z: null, d: "nu mută nimic; spune unde ești" },
    { c: "git add", z: 1, d: "din dosar în pregătire" },
    { c: "git commit", z: 2, d: "din pregătire în istoricul local" },
    { c: "git push", z: 3, d: "din local pe GitHub" },
  ];
  const F = (d.fisiere || ["colectare.py", "README.md"]).map(t => ({ t, z: 0 }));
  let jurnal = [];

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="zn">
      <div class="zn__zone">${ZONE.map((z, i) => `
        <div class="zn__z" data-z="${i}">
          <span class="zn__zt">${esc(z.t)}</span>
          <span class="zn__zd">${esc(z.d)}</span>
          <div class="zn__in"></div>
        </div>`).join("")}</div>
      <div class="zn__com">${COM.map((c, i) =>
        `<button class="zn__cb" data-c="${i}" type="button">${esc(c.c)}</button>`).join("")}
        <button class="zn__cb zn__cb--rau" data-rol="reset" type="button">de la capăt</button>
      </div>
      <p class="zn__msg"></p>
      <p class="ex__stare"></p>
    </div>`;

  const cosuri = [...gazda.querySelectorAll(".zn__in")];
  const msg = gazda.querySelector(".zn__msg");
  const st  = gazda.querySelector(".ex__stare");

  const deseneaza = () => {
    cosuri.forEach((c, i) => {
      c.innerHTML = F.filter(f => f.z === i)
        .map(f => `<span class="zn__f">${esc(f.t)}</span>`).join("");
    });
    gazda.querySelectorAll(".zn__z").forEach((z, i) =>
      z.classList.toggle("plin", F.some(f => f.z === i)));
  };

  gazda.addEventListener("click", async e => {
    if (e.target.closest('[data-rol="reset"]')){
      F.forEach(f => f.z = 0); jurnal = []; msg.textContent = ""; deseneaza(); return;
    }
    const b = e.target.closest(".zn__cb");
    if (!b || b.dataset.c === undefined) return;
    const c = COM[+b.dataset.c];
    jurnal.push(c.c);

    if (c.z === null){
      const pe = ZONE.map((z, i) => `${F.filter(f => f.z === i).length} în „${z.t}”`).join(", ");
      msg.textContent = `${c.c}: ${pe}. Nu s-a mutat nimic.`;
      return;
    }
    const muta = F.filter(f => f.z === c.z - 1);
    if (!muta.length){
      msg.textContent = `${c.c}: n-are ce muta. În „${ZONE[c.z - 1].t}” nu e nimic.`;
      return;
    }
    muta.forEach(f => f.z = c.z);
    msg.textContent = `${c.c}: ${muta.length} ${muta.length === 1 ? "fișier" : "fișiere"} → ${ZONE[c.z].t}.`;
    deseneaza();

    if (F.every(f => f.z === 3)){
      msg.textContent = "Toate au ajuns pe GitHub. Ăsta e drumul, de fiecare dată.";
      await poarta(gazda, d.id, jurnal.join(" → "));
      st.textContent = "Rezolvare înregistrată.";
      st.classList.add("vazut");
    }
  });

  deseneaza();
};


/* ===========================================================================
   5. RAMURI — graful care crește sub ochii tăi

   O ramură e greu de explicat în cuvinte și evidentă într-un desen. Aici se
   desenează pe măsură ce apeși.
   =========================================================================== */

V.ramuri = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  let main = 2, ram = 0, peRamura = false, unit = 0, nodRam = null;
  /* main: câte commit-uri pe main; ram: câte pe ramură; unit: s-a îmbinat */

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="rm">
      <div class="rm__desen"></div>
      <div class="rm__com">
        <button class="zn__cb" data-a="commit" type="button">commit</button>
        <button class="zn__cb" data-a="ramura" type="button">git switch -c curatare</button>
        <button class="zn__cb" data-a="main" type="button">git switch main</button>
        <button class="zn__cb" data-a="merge" type="button">git merge curatare</button>
        <button class="zn__cb zn__cb--rau" data-a="reset" type="button">de la capăt</button>
      </div>
      <p class="rm__unde"></p>
      <p class="ex__stare"></p>
    </div>`;

  const desen = gazda.querySelector(".rm__desen");
  const unde  = gazda.querySelector(".rm__unde");
  const st    = gazda.querySelector(".ex__stare");

  function deseneaza(){
    const PAS = 54, R = 9, SUS = 34, JOS = 84;
    const n = main + (ram ? ram : 0) + (unit ? 1 : 0);
    const lat = Math.max(420, (main + ram + 2) * PAS);
    let p = [], linii = [];

    for (let i = 0; i < main; i++) p.push({ x: (i + 1) * PAS, y: JOS, t: "main" });
    for (let i = 1; i < main; i++)
      linii.push(`M${i * PAS} ${JOS} H${(i + 1) * PAS}`);

    const bif = nodRam === null ? null : nodRam;
    for (let i = 0; i < ram; i++){
      const x = (bif + i + 1) * PAS;
      p.push({ x, y: SUS, t: "ramura" });
      if (i === 0) linii.push(`R M${bif * PAS} ${JOS} C${bif * PAS + 22} ${JOS} ${x - 22} ${SUS} ${x} ${SUS}`);
      else linii.push(`R M${x - PAS} ${SUS} H${x}`);
    }
    if (unit){
      const x = (main) * PAS;
      p.push({ x, y: JOS, t: "unit" });
      linii.push(`M${(main - 1) * PAS} ${JOS} H${x}`);
      linii.push(`R M${(bif + ram) * PAS} ${SUS} C${(bif + ram) * PAS + 22} ${SUS} ${x - 22} ${JOS} ${x} ${JOS}`);
    }

    desen.innerHTML = `
      <svg viewBox="0 0 ${lat} 120" width="100%" height="120" role="img"
           aria-label="graful ramurilor">
        <text x="6" y="${JOS + 4}" class="rm__et">main</text>
        ${ram ? `<text x="6" y="${SUS + 4}" class="rm__et rm__et--r">curatare</text>` : ""}
        ${linii.map(dd => dd[0] === "R"
          ? `<path d="${dd.slice(2)}" class="rm__l rm__l--r"/>` : `<path d="${dd}" class="rm__l"/>`).join("")}
        ${p.map(q => `<circle cx="${q.x}" cy="${q.y}" r="${R}" class="rm__n rm__n--${q.t}"/>`).join("")}
      </svg>`;
    unde.textContent = peRamura ? "ești pe ramura curatare" : "ești pe main";
  }

  gazda.addEventListener("click", async e => {
    const b = e.target.closest("[data-a]");
    if (!b) return;
    const a = b.dataset.a;
    if (a === "reset"){ main = 2; ram = 0; peRamura = false; unit = 0; nodRam = null; deseneaza(); return; }
    if (a === "commit"){
      if (peRamura) ram++; else main++;
    }
    if (a === "ramura"){
      if (unit){ return; }
      peRamura = true; if (nodRam === null) nodRam = main;
    }
    if (a === "main") peRamura = false;
    if (a === "merge"){
      if (!ram || peRamura){
        unde.textContent = ram ? "întâi git switch main" : "n-ai ce îmbina: ramura e goală";
        return;
      }
      unit = 1; main++;
      await poarta(gazda, d.id, `main:${main} ramura:${ram}`);
      st.textContent = "Ai dus o ramură până la capăt.";
      st.classList.add("vazut");
    }
    deseneaza();
  });

  deseneaza();
};


/* ===========================================================================
   6. CONFLICT — îl rezolvi cu mâna, cum se face și în viață

   Marcajele acelea cu paranteze unghiulare sperie prima dată. Aici le vezi,
   alegi, și vezi ce rămâne în fișier.
   =========================================================================== */

V.conflict = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  let ales = null;

  const randuri = () => {
    if (ales === null){
      return `<span class="cf__m">&lt;&lt;&lt;&lt;&lt;&lt;&lt; HEAD</span>\n` +
             `<span class="cf__a">${esc(d.alMeu)}</span>\n` +
             `<span class="cf__m">=======</span>\n` +
             `<span class="cf__b">${esc(d.alLor)}</span>\n` +
             `<span class="cf__m">&gt;&gt;&gt;&gt;&gt;&gt;&gt; ${esc(d.ramura || "curatare")}</span>`;
    }
    if (ales === "meu")  return `<span class="cf__a">${esc(d.alMeu)}</span>`;
    if (ales === "lor")  return `<span class="cf__b">${esc(d.alLor)}</span>`;
    return `<span class="cf__a">${esc(d.alMeu)}</span>\n<span class="cf__b">${esc(d.alLor)}</span>`;
  };

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="cf">
      <div class="ed">
        <div class="ed__bara"><span class="ed__pct"><i></i><i></i><i></i></span>
          <span class="ed__nume">${esc(d.fisier || "analiza.py")}</span></div>
        <div class="ed__corp"><div class="ed__cod"><pre class="cf__cod"></pre></div></div>
      </div>
      <div class="cf__alege">
        <button class="zn__cb" data-k="meu" type="button">păstrez ce am eu</button>
        <button class="zn__cb" data-k="lor" type="button">păstrez ce vine</button>
        <button class="zn__cb" data-k="ambele" type="button">le păstrez pe amândouă</button>
      </div>
      <div class="ex__jos">
        <button class="btn btn--mic btn--tare" data-rol="verifica" type="button" disabled>
          git add și commit</button>
        <span class="ex__raspuns"></span>
      </div>
      <p class="ex__ex"></p>
      <p class="ex__stare"></p>
    </div>`;

  const cod = gazda.querySelector(".cf__cod");
  const btV = gazda.querySelector('[data-rol="verifica"]');
  const out = gazda.querySelector(".ex__raspuns");
  const ex  = gazda.querySelector(".ex__ex");
  const st  = gazda.querySelector(".ex__stare");

  const scrie = () => { cod.innerHTML = randuri(); };

  gazda.addEventListener("click", e => {
    const b = e.target.closest("[data-k]");
    if (!b) return;
    ales = b.dataset.k;
    gazda.querySelectorAll("[data-k]").forEach(x => x.classList.toggle("on", x === b));
    btV.disabled = false;
    out.textContent = "";
    scrie();
  });

  btV.onclick = async () => {
    const bun = ales === (d.bun || "lor");
    out.innerHTML = bun
      ? "<b>Așa e.</b> Marcajele au dispărut, fișierul rulează din nou."
      : `<b>Merge, dar nu e ce trebuia.</b> ${d.deCe || ""}`;
    ex.classList.add("vazut");
    ex.innerHTML = d.explicatie || "";
    btV.disabled = true;
    gazda.querySelectorAll("[data-k]").forEach(x => x.disabled = true);
    await poarta(gazda, d.id, ales);
    st.textContent = "Rezolvare înregistrată.";
    st.classList.add("vazut");
  };

  scrie();
};


/* ===========================================================================
   7. COTE — cât din întreg

   Un cerc tăiat în felii se citește prost: ochiul compară greu unghiuri. Bare
   orizontale, sortate, cu aceeași culoare, se citesc dintr-o privire. Culoarea
   nu poartă informație aici: lungimea o poartă.
   =========================================================================== */

V.cote = (gazda, d) => {
  const C = (d.cote || []).slice().sort((a, b) => b.v - a.v);
  const max = Math.max(...C.map(x => x.v), 1);

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="cot">
      ${C.map(x => `
        <div class="cot__r ${x.ac ? "ac" : ""}">
          <span class="cot__t">${esc(x.t)}</span>
          <span class="cot__b"><i style="width:${(x.v / max) * 100}%"></i></span>
          <span class="cot__v">${x.v}${d.unitate || "%"}</span>
        </div>`).join("")}
      ${d.sursa ? `<p class="cot__s">${d.sursa}</p>` : ""}
    </div>`;
};


/* ===========================================================================
   8. PRAG — unde tai valorile extreme

   Regula „peste 1,5 ori intervalul intercuartilic" pare obiectivă până muți
   pragul și vezi că numărul de „valori extreme" se schimbă cum vrei tu. Asta
   e lecția: pragul e o alegere, iar o valoare extremă nu e automat o greșeală.
   =========================================================================== */

V.prag = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  const X = (d.valori || []).slice().sort((a, b) => a.v - b.v);
  if (!X.length) return;
  const vals = X.map(x => x.v);
  const cuant = q => {
    const i = (vals.length - 1) * q, j = Math.floor(i), r = i - j;
    return vals[j] + (vals[Math.min(j + 1, vals.length - 1)] - vals[j]) * r;
  };
  const q1 = cuant(0.25), q3 = cuant(0.75), iqr = q3 - q1;
  const maxv = vals[vals.length - 1];
  /* o margine de fiecare parte, ca bulina cea mai mare să nu fie tăiată de
     marginea benzii, exact ca la cronologie */
  const MARG = 2;
  const poz = v => MARG + (Math.min(1, v / maxv)) * (100 - 2 * MARG);
  let k = 1.5, raspuns = null;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="prg">
      <div class="prg__banda">
        ${X.map((x, i) => `<span class="prg__p" data-v="${x.v}"
            style="left:${poz(x.v)}%;bottom:${(i % 4) * 9}px" title="${esc(x.t)}: ${x.v}"></span>`).join("")}
        ${X.slice(-3).map((x, i) => `<span class="prg__nume${i === 2 ? " dr" : ""}" style="left:${poz(x.v)}%">${esc(x.t)}</span>`).join("")}
        <span class="prg__linie"></span>
      </div>
      <div class="prg__ctrl">
        <label>prag = Q3 + <b class="prg__k">1,5</b> × IQR</label>
        <input class="prg__s" type="range" min="5" max="50" step="1" value="15">
      </div>
      <p class="prg__cif"></p>
      <p class="prg__lista"></p>
      <div class="prg__intreb">
        <p>${d.intrebare || "Valorile marcate sunt greșeli de date?"}</p>
        <div class="cf__alege">
          <button class="zn__cb" data-r="scot" type="button">Sunt greșeli, le scot</button>
          <button class="zn__cb" data-r="pastrez" type="button">Nu sunt greșeli, le păstrez</button>
        </div>
        <p class="ex__raspuns"></p>
      </div>
      <p class="ex__stare"></p>
    </div>`;

  const banda = gazda.querySelector(".prg__banda");
  const cif   = gazda.querySelector(".prg__cif");
  const lst   = gazda.querySelector(".prg__lista");
  const out   = gazda.querySelector(".ex__raspuns");
  const st    = gazda.querySelector(".ex__stare");

  function deseneaza(){
    const prag = q3 + k * iqr;
    const peste = X.filter(x => x.v > prag);
    gazda.querySelector(".prg__k").textContent = String(k).replace(".", ",");
    gazda.querySelector(".prg__linie").style.left = poz(prag) + "%";
    banda.querySelectorAll(".prg__p").forEach(p =>
      p.classList.toggle("peste", +p.dataset.v > prag));
    cif.innerHTML = `prag <b>${Math.round(prag).toLocaleString("ro-RO")}</b> · ` +
      `<b>${peste.length}</b> din ${X.length} sunt peste el`;
    lst.innerHTML = peste.length
      ? "marcate: " + peste.slice(-8).reverse().map(x => esc(x.t)).join(", ") +
        (peste.length > 8 ? ", …" : "")
      : "nicio valoare peste prag";
  }

  gazda.querySelector(".prg__s").addEventListener("input", e => {
    k = (+e.target.value) / 10;
    deseneaza();
  });

  gazda.addEventListener("click", async e => {
    const b = e.target.closest("[data-r]");
    if (!b || raspuns) return;
    raspuns = b.dataset.r;
    gazda.querySelectorAll("[data-r]").forEach(x => { x.disabled = true;
      x.classList.toggle("on", x === b); });
    out.innerHTML = raspuns === "pastrez"
      ? `<b>Da.</b> ${d.laBine || ""}`
      : `<b>Nu încă.</b> ${d.laRau || ""}`;
    out.classList.add("vazut");
    await poarta(gazda, d.id, `k=${k} raspuns=${raspuns}`);
    st.textContent = "Rezolvare înregistrată.";
    st.classList.add("vazut");
  });

  deseneaza();
};


/* ===========================================================================
   9. ÎMBINARE — ce rămâne când lipești două tabele

   `inner`, `left`, `outer` se învață prost din definiție și bine din numărare.
   Aici stau două tabele mici, unul lângă altul, cu cheile colorate după cum se
   potrivesc sau nu. Apeși un fel de îmbinare și vezi tabelul care iese: câte
   rânduri, care au goluri, care au dispărut.

   Poarta se deschide după ce au fost încercate toate felurile: scopul nu e să
   nimerească unul, e să le vadă pe toate patru una după alta.
   =========================================================================== */

V.imbinare = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");

  const chS = d.cheie || "cod";                     /* coloana-cheie */
  const A = d.stanga || { nume: "stânga", randuri: [] };
  const B = d.dreapta || { nume: "dreapta", randuri: [] };
  const colA = Object.keys(A.randuri[0] || {});
  const colB = Object.keys(B.randuri[0] || {});
  const doarB = colB.filter(c => c !== chS);        /* ce aduce tabelul din dreapta */

  const FELURI = d.feluri || ["concat", "inner", "left", "right", "outer"];
  const NUME = { concat: "concat", inner: "inner", left: "left",
                 right: "right", outer: "outer" };
  const vazute = new Set();
  let fel = null;

  /* ---- ce iese din fiecare fel de îmbinare ---------------------------- */
  function rezultat(f){
    const cheiA = A.randuri.map(r => r[chS]);
    const cheiB = B.randuri.map(r => r[chS]);

    if (f === "concat"){
      /* una sub alta: coloanele se reunesc, ce lipsește rămâne gol */
      const col = [...new Set([...colA, ...colB])];
      const r = [...A.randuri.map(x => ({ ...x, _din: "a" })),
                 ...B.randuri.map(x => ({ ...x, _din: "b" }))];
      return { col, randuri: r };
    }

    const col = [...colA, ...doarB];
    const out = [];
    const potrivit = k => B.randuri.filter(x => x[chS] === k);

    if (f === "inner" || f === "left"){
      for (const a of A.randuri){
        const p = potrivit(a[chS]);
        if (p.length) p.forEach(b => out.push({ ...a, ...b, _din: "ab" }));
        else if (f === "left") out.push({ ...a, _din: "a" });
      }
    }
    if (f === "right"){
      for (const b of B.randuri){
        const p = A.randuri.filter(x => x[chS] === b[chS]);
        if (p.length) p.forEach(a => out.push({ ...a, ...b, _din: "ab" }));
        else out.push({ ...b, _din: "b" });
      }
    }
    if (f === "outer"){
      for (const a of A.randuri){
        const p = potrivit(a[chS]);
        if (p.length) p.forEach(b => out.push({ ...a, ...b, _din: "ab" }));
        else out.push({ ...a, _din: "a" });
      }
      for (const b of B.randuri)
        if (!cheiA.includes(b[chS])) out.push({ ...b, _din: "b" });
    }
    return { col, randuri: out };
  }

  /* ---- tabelele de sus, cu cheile colorate ---------------------------- */
  const cheiComune = new Set(A.randuri.map(r => r[chS])
    .filter(k => B.randuri.some(x => x[chS] === k)));

  const tabel = (t, col, randuri, lat) => `
    <div class="imb__t">
      <span class="imb__tn">${esc(t)}<small>${randuri.length} rânduri</small></span>
      <table class="imb__tb">
        <thead><tr>${col.map(c =>
          `<th class="${c === chS ? "ch" : ""}">${esc(c)}</th>`).join("")}</tr></thead>
        <tbody>${randuri.map(r => `<tr>${col.map(c => {
          const v = r[c];
          const gol = v === undefined || v === null || v === "";
          const ch = c === chS;
          const sg = ch && !cheiComune.has(r[c]);
          return `<td class="${ch ? "ch " : ""}${sg ? "sg " : ""}${gol ? "gol" : ""}">${
            gol ? (lat ? "NaN" : "—") : esc(v)}</td>`;
        }).join("")}</tr>`).join("")}</tbody>
      </table>
    </div>`;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="imb">
      <div class="imb__sus">
        ${tabel(A.nume, colA, A.randuri)}
        <span class="imb__plus">+</span>
        ${tabel(B.nume, colB, B.randuri)}
      </div>
      <p class="imb__leg">
        <span class="imb__pct imb__pct--ab"></span>cheie în amândouă
        <span class="imb__pct imb__pct--un"></span>cheie într-unul singur
      </p>
      <div class="imb__fel">
        ${FELURI.map(f => `<button class="imb__b" data-f="${f}" type="button">${
          f === "concat" ? "pd.concat" : `how=&quot;${NUME[f]}&quot;`}</button>`).join("")}
      </div>
      <div class="imb__jos"><p class="imb__gol">Apasă pe un fel de îmbinare.</p></div>
      <p class="imb__exp"></p>
      <p class="ex__stare"></p>
    </div>`;

  const jos = gazda.querySelector(".imb__jos");
  const exp = gazda.querySelector(".imb__exp");
  const st  = gazda.querySelector(".ex__stare");

  gazda.addEventListener("click", async e => {
    const b = e.target.closest(".imb__b");
    if (!b) return;
    fel = b.dataset.f;
    gazda.querySelectorAll(".imb__b").forEach(x => x.classList.toggle("on", x === b));
    const r = rezultat(fel);
    jos.innerHTML = tabel(d.numeRez || "rezultat", r.col, r.randuri, true);
    jos.querySelectorAll("tbody tr").forEach((tr, i) =>
      tr.classList.add("din-" + (r.randuri[i]._din || "ab")));
    exp.innerHTML = (d.explicatii || {})[fel] || "";

    vazute.add(fel);
    if (vazute.size >= FELURI.length){
      await poarta(gazda, d.id || "imbinare", [...vazute].join(","));
      st.textContent = "Le-ai văzut pe toate. Înregistrat.";
      st.classList.add("vazut");
    } else {
      st.textContent = `${vazute.size} din ${FELURI.length} încercate.`;
      st.classList.add("vazut");
    }
  });
};


/* ===========================================================================
   10. COLOANE — ce tip are fiecare coloană

   Un tabel de tipuri cu patru rânduri se citește și se uită. Aici se vede
   tabelul adevărat, cu valorile lui, și pentru fiecare coloană trebuie ales
   un tip. Alegerea se face uitându-te la valori, care e exact ce faci în
   realitate când scrii un `create table`.
   =========================================================================== */

V.coloane = (gazda, d) => {
  gazda.closest(".ix")?.classList.add("exc");
  const C = d.coloane || [];
  const T = d.tipuri || [];
  let verificat = false;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="col">
      <div class="col__t">
        <span class="col__tn">${esc(d.fisier || "tabel")}<small>${
          d.nota || `${C.length} coloane`}</small></span>
        <table class="col__tb">
          <thead><tr>${C.map(c => `<th>${esc(c.nume)}</th>`).join("")}</tr></thead>
          <tbody>${(d.cap || []).map(r => `<tr>${r.map(v =>
            `<td class="${typeof v === "number" ? "nr" : ""}">${esc(v)}</td>`
            ).join("")}</tr>`).join("")}</tbody>
          <tfoot><tr>${C.map((c, i) => `<td>
            <select class="col__s" data-i="${i}">
              <option value="">alege tipul…</option>
              ${T.map(t => `<option value="${esc(t)}">${esc(t)}</option>`).join("")}
            </select></td>`).join("")}</tr></tfoot>
        </table>
      </div>
      <div class="col__act">
        <button class="btn btn--mic btn--tare" data-rol="verifica" type="button"
          disabled>Verifică</button>
        <button class="btn btn--mic" data-rol="din-nou" type="button" hidden>Încearcă din nou</button>
      </div>
      <p class="ex__raspuns"></p>
      <div class="col__de"></div>
      <p class="ex__stare"></p>
    </div>`;

  const sel = [...gazda.querySelectorAll(".col__s")];
  const btV = gazda.querySelector('[data-rol="verifica"]');
  const btN = gazda.querySelector('[data-rol="din-nou"]');
  const out = gazda.querySelector(".ex__raspuns");
  const de  = gazda.querySelector(".col__de");
  const st  = gazda.querySelector(".ex__stare");

  const gata = () => sel.every(s => s.value);
  sel.forEach(s => s.addEventListener("change", () => {
    btV.disabled = !gata();
    if (verificat) return;
    s.classList.remove("bun", "rau");
  }));

  btV.onclick = async () => {
    verificat = true;
    let bune = 0;
    sel.forEach((s, i) => {
      const ok = String(s.value).toUpperCase() === String(C[i].ok).toUpperCase();
      s.classList.toggle("bun", ok); s.classList.toggle("rau", !ok);
      if (ok) bune++;
    });
    const tot = bune === C.length;
    out.innerHTML = tot ? `<b>Tot corect.</b> ${d.laBine || ""}`
                        : `<b>${bune} din ${C.length}.</b> ${d.laRau || ""}`;
    btN.hidden = tot;
    if (!tot) return;
    btV.disabled = true;
    de.innerHTML = C.map(c => `<p><code>${esc(c.nume)}</code>
      <b>${esc(c.ok)}</b> ${c.de_ce || ""}</p>`).join("");
    de.classList.add("vazut");
    await poarta(gazda, d.id || "coloane", sel.map(s => s.value).join(","));
    st.textContent = "Rezolvare înregistrată.";
    st.classList.add("vazut");
  };

  btN.onclick = () => {
    verificat = false; btN.hidden = true; out.textContent = "";
    sel.forEach(s => s.classList.remove("bun", "rau"));
    btV.disabled = !gata();
  };
};


/* ===========================================================================
   11. DESFĂ — cum devine un JSON un tabel

   Ce se întâmplă între răspunsul unui API și `DataFrame` e operația pe care
   toată lumea o scrie fără s-o vadă. Aici se vede: apeși, se aprinde lista
   dinăuntru, apoi fiecare element devine un rând, unul câte unul.
   =========================================================================== */

V.desfa = (gazda, d) => {
  /* E poartă: se deschide după ce au apăsat de două ori, adică după ce au
     văzut și lista aprinsă, și tabelul făcut din ea. */
  if (d.id) gazda.closest(".ix")?.classList.add("exc");
  const EL = d.elemente || [];
  const COL = d.coloane || [];
  const PASI = [
    d.p0 || "Tot răspunsul, așa cum vine.",
    d.p1 || "Lista dinăuntru: asta devine tabel.",
    d.p2 || "Fiecare element al listei devine un rând.",
  ];
  let pas = 0;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="dsf">
      <div class="dsf__doi">
        <div class="dsf__st">
          <span class="dsf__et">${esc(d.sursa || "răspunsul API")}</span>
          <pre class="dsf__j"></pre>
        </div>
        <div class="dsf__dr">
          <span class="dsf__et">DataFrame</span>
          <table class="dsf__tb">
            <thead><tr>${COL.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead>
            <tbody></tbody>
          </table>
          <p class="dsf__gol">Încă nimic.</p>
        </div>
      </div>
      <div class="dsf__act">
        <button class="btn btn--mic btn--tare" data-rol="pas" type="button"></button>
        <span class="dsf__stare"></span>
      </div>
    </div>`;

  const j    = gazda.querySelector(".dsf__j");
  const tb   = gazda.querySelector(".dsf__tb tbody");
  const gol  = gazda.querySelector(".dsf__gol");
  const bt   = gazda.querySelector('[data-rol="pas"]');
  const stare= gazda.querySelector(".dsf__stare");

  /* JSON-ul scris de mână, ca să pot aprinde exact ce vreau */
  function scrieJson(aprins){
    const cap = `{\n  "${esc(d.cheieCap || "cap")}": { "pagina": 1, "total": ${EL.length} },\n`;
    const lista = EL.map((e, i) =>
      `    {${COL.map(c => ` "${esc(c)}": ${
        typeof e[c] === "number" ? e[c] : `"${esc(e[c])}"`}`).join(",")} }`
    ).join(",\n");
    const corp = `  "${esc(d.cheieLista || "date")}": [\n${lista}\n  ]\n}`;
    j.innerHTML = aprins
      ? esc(cap) + `<mark>${esc(corp.slice(0, corp.length))}</mark>`
      : esc(cap + corp);
  }

  function deseneaza(){
    scrieJson(pas >= 1);
    tb.innerHTML = "";
    if (pas >= 2){
      EL.forEach((e, i) => {
        const tr = document.createElement("tr");
        tr.innerHTML = COL.map(c => `<td class="${
          typeof e[c] === "number" ? "nr" : ""}">${esc(e[c])}</td>`).join("");
        tr.style.animationDelay = (i * 90) + "ms";
        tb.appendChild(tr);
      });
    }
    gol.hidden = pas >= 2;
    stare.textContent = PASI[Math.min(pas, PASI.length - 1)];
    bt.textContent = pas === 0 ? (d.buton || "Arată-mi lista")
                   : pas === 1 ? "Fă tabelul"
                   : "Încă o dată";
  }

  bt.onclick = async () => {
    pas = pas >= 2 ? 0 : pas + 1;
    deseneaza();
    if (pas === 2 && d.id) await poarta(gazda, d.id, d.cheieLista || "date");
  };

  deseneaza();
};


/* ===========================================================================
   12. DRUM — fluxul unui proiect de analiză, ca schemă

   Zece cartonașe egale într-un grid nu spun nimic despre ordine. Schema de
   la curs spune: etapele curg spre dreapta, sunt două benzi (analiza sus,
   ingineria jos), baza de date stă deoparte fiindcă nu e o etapă, iar
   săgețile punctate sunt întoarcerile, adică partea cea mai importantă.

   Forma e fixă, ca în prezentare. Ce se schimbă e textul, care vine din
   lecție. Apeși pe o etapă și îi citești rostul.
   =========================================================================== */

V.drum = (gazda, d) => {
  const SUS = (d.sus || []).slice(0, 4);
  const JOS = (d.jos || []).slice(0, 4);
  const FIN = d.final || { n: "Raportare" };
  const BAZA = d.baza || { n: "Baza de date" };
  const toate = [...SUS, ...JOS, FIN, BAZA];

  const chev = (x, i, banda) => `
    <button class="drm__e drm__e--${banda} et--${esc(x.et || "")}" data-i="${esc(x.n)}"
      style="--k:${i}" type="button">
      <span class="drm__nr">${String(i + 1).padStart(2, "0")}</span>
      <span class="drm__n">${esc(x.n)}</span>
    </button>`;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="drm">
      <div class="drm__plan">
        <svg class="drm__linii" aria-hidden="true"></svg>

        <span class="drm__banda drm__banda--sus">${esc(d.bandaSus || "Analiza datelor")}</span>
        <div class="drm__rand drm__rand--sus">${SUS.map((x, i) => chev(x, i, "a")).join("")}</div>

        <button class="drm__fin et--${esc(FIN.et || "raport")}" data-i="${esc(FIN.n)}" type="button">${esc(FIN.n)}</button>

        <button class="drm__baza et--${esc(BAZA.et || "agregare")}" data-i="${esc(BAZA.n)}" type="button">
          <span class="drm__bt">${esc(BAZA.n)}</span>
          <span class="drm__bd">nu e o etapă, e depozitul</span>
        </button>

        <div class="drm__rand drm__rand--jos">${JOS.map((x, i) => chev(x, i + 4, "b")).join("")}</div>
        <span class="drm__banda drm__banda--jos">${esc(d.bandaJos || "Ingineria modelelor")}</span>
      </div>

      <p class="drm__leg">
        <span class="drm__lp"></span>drumul înainte
        <span class="drm__lp drm__lp--p"></span>întoarcerile, la fel de normale
      </p>
      <div class="drm__i"><h5>${esc(d.titlu || "Apasă pe o etapă")}</h5>
        <p>${d.intro || ""}</p></div>
    </div>`;

  const plan = gazda.querySelector(".drm__plan");
  const svg  = gazda.querySelector(".drm__linii");
  const info = gazda.querySelector(".drm__i");

  function trage(){
    const P = plan.getBoundingClientRect();
    if (!P.width) return;
    svg.setAttribute("viewBox", `0 0 ${P.width} ${P.height}`);
    svg.setAttribute("width", P.width); svg.setAttribute("height", P.height);

    const c = sel => {
      const el = plan.querySelector(sel);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { st: r.left - P.left, dr: r.right - P.left,
               sus: r.top - P.top, jos: r.bottom - P.top,
               x: r.left - P.left + r.width / 2,
               y: r.top - P.top + r.height / 2 };
    };

    const ultimSus = c(".drm__rand--sus .drm__e:last-child");
    const primJos  = c(".drm__rand--jos .drm__e:first-child");
    const alDoiJos = c(".drm__rand--jos .drm__e:nth-child(2)");
    const fin      = c(".drm__fin");
    const baza     = c(".drm__baza");
    const primSus  = c(".drm__rand--sus .drm__e:nth-child(2)");

    const pline = [], punct = [], varf = [];
    const sageata = (x, y, rot) => {
      const p = [[0,0],[-4.4,-6.4],[4.4,-6.4]]
        .map(([a,b]) => { const r = rot * Math.PI / 180;
          return `${(x + a*Math.cos(r) - b*Math.sin(r)).toFixed(1)},` +
                 `${(y + a*Math.sin(r) + b*Math.cos(r)).toFixed(1)}`; });
      varf.push(p.join(" "));
    };

    if (ultimSus && fin){                       /* EDA → raportare */
      const m = (ultimSus.dr + fin.st) / 2;
      pline.push(`M${ultimSus.dr},${ultimSus.y} H${fin.st - 7}`);
      sageata(fin.st, ultimSus.y, 90);
    }
    if (ultimSus && primJos){                   /* EDA ↓ feature engineering */
      pline.push(`M${ultimSus.x},${ultimSus.jos} V${primJos.sus - 7}`);
      sageata(primJos.x, primJos.sus, 180);
      pline.push(`M${ultimSus.x},${ultimSus.jos} V${(ultimSus.jos + primJos.sus)/2} ` +
                 `H${primJos.x}`);
    }
    if (alDoiJos && fin){                       /* modelare ↗ raportare */
      pline.push(`M${alDoiJos.x},${alDoiJos.sus} V${fin.jos + 7}`);
      sageata(alDoiJos.x, fin.jos, 0);
    }
    if (primSus && baza){                       /* colectarea ↕ baza */
      pline.push(`M${primSus.x},${primSus.jos} V${baza.sus - 7}`);
      sageata(primSus.x, baza.sus, 180);
    }
    if (baza && fin){                           /* intoarcerile, punctate */
      punct.push(`M${baza.dr},${baza.y} H${fin.st - 14} V${fin.jos + 10}`);
      sageata(fin.st - 14, fin.jos + 8, 0);
    }
    if (baza && primJos){
      punct.push(`M${primJos.st - 10},${primJos.jos + 12} H${baza.x} V${baza.jos + 7}`);
      sageata(baza.x, baza.jos + 9, 0);
    }

    svg.innerHTML =
      `<path d="${pline.join(" ")}" fill="none" stroke="currentColor" stroke-width="1.6"/>` +
      `<path d="${punct.join(" ")}" fill="none" stroke="currentColor" stroke-width="1.3"
         stroke-dasharray="3 4" opacity=".65"/>` +
      varf.map(v => `<polygon points="${v}" fill="currentColor"/>`).join("");
  }

  trage();
  requestAnimationFrame(trage);
  if (window.ResizeObserver) new ResizeObserver(trage).observe(plan);

  plan.addEventListener("click", ev => {
    const b = ev.target.closest("[data-i]");
    if (!b) return;
    plan.querySelectorAll("[data-i]").forEach(x => x.classList.remove("on"));
    b.classList.add("on");
    const x = toate.find(t => t.n === b.dataset.i);
    if (!x) return;
    info.className = `drm__i drm__i--plin et--${x.et || ""}`;
    info.innerHTML = `<h5>${esc(x.n)}${x.unde ? ` <small>${esc(x.unde)}</small>` : ""}</h5>
      <p>${x.d || ""}</p>
      ${x.noi || x.lit || x.capcana ? `<div class="drm__blocuri">
        ${x.noi ? `<div><h6>În proiectul nostru</h6><p>${x.noi}</p></div>` : ""}
        ${x.lit ? `<div><h6>Ce citești aici</h6><p>${x.lit}</p></div>` : ""}
        ${x.capcana ? `<div class="drm__cap"><h6>Capcana</h6><p>${x.capcana}</p></div>` : ""}
      </div>` : ""}`;
  });
};


/* ===========================================================================
   13. SEMESTRU — cele unsprezece teme, așezate pe cele opt ședințe

   O grilă de cartonașe răspunde la „ce teme sunt” și deloc la „când”. Aici
   ședințele sunt o linie, iar temele atârnă de ședința în care se fac: se
   vede dintr-o privire că primul curs duce două teme, că Git-ul vine înaintea
   API-urilor, și unde e aglomerat semestrul.
   =========================================================================== */

V.semestru = (gazda, d) => {
  const T = d.teme || [], F = d.fise || [], N = d.sedinte || 8;
  const fisa = k => F.find(f => f.c === k) || { c: k, titlu: "" };
  let ales = d.azi || 1;
  gazda.innerHTML = `
    <div class="sm">
      <ol class="sm__linie">${Array.from({ length: N }, (_, i) => { const k = i + 1, f = fisa(k);
        return `<li><button class="sm__p et--${esc(f.etapa || "")}" data-c="${k}" type="button">
          <i></i><span class="sm__c">C${k}</span><span class="sm__t">${esc(f.scurt || f.titlu)}</span></button></li>`; }).join("")}</ol>
      <div class="sm__det" aria-live="polite"></div>
    </div>`;
  const det = gazda.querySelector(".sm__det");
  function arata(k){
    ales = k; const f = fisa(k);
    gazda.querySelectorAll(".sm__p").forEach(b => b.classList.toggle("on", +b.dataset.c === k));
    const teme = T.filter(t => t.c === k).map(t => t.n).join(" · ");
    det.innerHTML = `<p class="sm__d1"><b>Cursul ${k}</b> ${esc(teme)}</p>
      <p class="sm__d2">În proiect: ${f.proiect || ""}</p>`;
  }
  gazda.querySelector(".sm__linie").addEventListener("click", ev => {
    const b = ev.target.closest(".sm__p"); if (b) arata(+b.dataset.c);
  });
  arata(ales);
};


/* ===========================================================================
   14. ANATOMIE — părțile unui JSON, arătate pe el

   Un tabel „object → dict, array → list" se învață pe de rost și nu ajută la
   primul răspuns real. Aici stă JSON-ul întreg, iar fiecare parte se aprinde
   pe el: obiectul principal, tabloul, un obiect din tablou, o pereche
   cheie–valoare, un tablou de numere. Se vede unde începe și unde se termină
   fiecare, care e tot ce lipsea.
   =========================================================================== */

V.anatomie = (gazda, d) => {
  /* Poartă după ce au deschis câteva părți: scopul e să se uite pe cod, nu
     să nimerească un răspuns. */
  if (d.id) gazda.closest(".ix")?.classList.add("exc");
  const L = d.linii || [];
  const P = d.parti || [];
  const CERUT = d.cerute || 4;
  const vazute = new Set();
  let ales = null;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="ana">
      <div class="ana__parti">
        ${P.map((x, i) => `<button class="ana__p" data-i="${i}" type="button">
          <span class="ana__pe">${esc(x.et)}</span>
          ${x.py ? `<span class="ana__py">${esc(x.py)}</span>` : ""}
        </button>`).join("")}
      </div>
      <div class="ana__cod">
        <span class="ana__acolada"></span>
        ${L.map((l, i) => `<span class="ana__l" data-l="${i}">${
          esc(l) || "&nbsp;"}</span>`).join("")}
      </div>
      <p class="ana__i">${d.intro || "Apasă pe o parte ca s-o vezi aprinsă."}</p>
      <p class="ex__stare ana__st"></p>
    </div>`;

  const cod = gazda.querySelector(".ana__cod");
  const acol = gazda.querySelector(".ana__acolada");
  const info = gazda.querySelector(".ana__i");
  const linii = [...gazda.querySelectorAll(".ana__l")];

  gazda.querySelector(".ana__parti").addEventListener("click", ev => {
    const b = ev.target.closest(".ana__p");
    if (!b) return;
    const i = +b.dataset.i, x = P[i];
    if (ales === i){                       /* a doua apăsare stinge */
      ales = null;
      b.classList.remove("on");
      linii.forEach(l => l.classList.remove("on"));
      acol.style.display = "none";
      info.textContent = d.intro || "";
      return;
    }
    ales = i;
    gazda.querySelectorAll(".ana__p").forEach(y => y.classList.remove("on"));
    b.classList.add("on");
    const a = Math.max(0, Math.min(x.l[0], linii.length - 1));
    const z = Math.max(a, Math.min(x.l[1], linii.length - 1));
    linii.forEach((l, k) => l.classList.toggle("on", k >= a && k <= z));

    /* acolada din stânga, exact cât ține partea aleasă */
    const r1 = linii[a].getBoundingClientRect();
    const r2 = linii[Math.min(z, linii.length - 1)].getBoundingClientRect();
    const rc = cod.getBoundingClientRect();
    acol.style.display = "block";
    acol.style.top = (r1.top - rc.top + cod.scrollTop) + "px";
    acol.style.height = (r2.bottom - r1.top) + "px";

    info.innerHTML = `<b>${esc(x.et)}</b> ${x.d || ""}`;

    vazute.add(i);
    const st = gazda.querySelector(".ana__st");
    if (vazute.size >= CERUT && d.id){
      poarta(gazda, d.id, [...vazute].join(","));
      st.textContent = "Le-ai văzut. Înregistrat.";
    } else if (d.id){
      st.textContent = `${vazute.size} din ${CERUT} părți deschise.`;
    }
    st.classList.add("vazut");
  });
};


/* ===========================================================================
   15. INDICE — ce măsoară SCI, și ce nu

   Prima oră trebuie să lase un singur lucru în cap: indicele e o
   probabilitate, nu o numărătoare. Formula scrisă pe tablă se uită; aici se
   mută un cursor și se vede cum aceeași legătură dă alt indice când locul
   partener e mare sau mic. Asta e exact capcana în care cade oricine
   deschide datele.
   =========================================================================== */

V.indice = (gazda, d) => {
  const A = d.a || { n: "Cluj", u: 300 };
  const B = d.b || [];                       /* locuri partenere, cu marimea */
  let i = 0;

  const linii = 1200;                        /* legaturi observate, fix */
  const maxSci = Math.max(...B.map(x => linii / (A.u * x.u) * 1e6), 1);

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="ind">
      <div class="ind__scena">
        <div class="ind__loc ind__loc--a">
          <span class="ind__ln">${esc(A.n)}</span>
          <span class="ind__lu"><b>${A.u}</b> mii de utilizatori</span>
        </div>
        <div class="ind__pod"><i class="ind__banda"></i>
          <span class="ind__pn"><b>${linii}</b> de legături</span></div>
        <div class="ind__loc ind__loc--b">
          <span class="ind__ln ind__ln--b"></span>
          <span class="ind__lu ind__lu--b"></span>
        </div>
      </div>

      <div class="ind__alege">
        ${B.map((x, k) => `<button class="ind__b" data-k="${k}" type="button">${
          esc(x.n)}</button>`).join("")}
      </div>

      <div class="ind__calcul">
        <span class="ind__f">
          <i>SCI</i> =
          <span class="ind__fr">
            <span class="ind__sus">legături</span>
            <span class="ind__jos">utilizatori ${esc(A.n)} × utilizatori partener</span>
          </span>
        </span>
        <span class="ind__rez">= <b class="ind__v">—</b></span>
      </div>

      <p class="ind__i">${d.intro || ""}</p>
    </div>`;

  const nume = gazda.querySelector(".ind__ln--b");
  const util = gazda.querySelector(".ind__lu--b");
  const val  = gazda.querySelector(".ind__v");
  const info = gazda.querySelector(".ind__i");
  const banda = gazda.querySelector(".ind__banda");

  function arata(k){
    const x = B[k]; if (!x) return;
    i = k;
    gazda.querySelectorAll(".ind__b").forEach((b, j) =>
      b.classList.toggle("on", j === k));
    nume.textContent = x.n;
    util.innerHTML = `<b>${x.u.toLocaleString("ro-RO")}</b> mii de utilizatori`;
    const sci = Math.round(linii / (A.u * x.u) * 1e6);
    val.textContent = sci.toLocaleString("ro-RO");
    /* marimea locului partener se vede in cerc, indicele in grosimea benzii */
    gazda.querySelector(".ind__loc--b").style.setProperty("--m",
      Math.min(2.4, 0.5 + Math.sqrt(x.u / A.u)));
    /* grosimea benzii o raportez la cel mai mare indice dintre variante:
       altfel se lovește de limită la toate și nu se mai vede scăderea */
    banda.style.setProperty("--g", (3 + 23 * (sci / maxSci)).toFixed(1));
    info.innerHTML = x.d || "";
  }

  gazda.querySelector(".ind__alege").addEventListener("click", ev => {
    const b = ev.target.closest(".ind__b");
    if (b) arata(+b.dataset.k);
  });

  arata(0);
};


/* ===========================================================================
   16. CUB — cum devine un răspuns JSON-stat un tabel
   Eurostat nu trimite rânduri, trimite un cub: lista dimensiunilor, codurile
   fiecăreia cu poziția lor, și valorile puse pe poziții. Aici se vede regula:
   apeși o valoare (sau „Următoarea”), se aprind codurile din care vine, iar
   rândul ei apare în tabel. Nu e poartă: e de privit, nu de nimerit.
   =========================================================================== */
V.cub = (gazda, d) => {
  const DIM = d.dimensiuni || [];            // [{id, et, coduri:[...]}], ultima variază cel mai repede
  const VAL = d.valori || [];                // în ordinea pozițiilor
  const fmtN = x => x == null ? "null" : Number(x).toLocaleString("ro-RO");
  const marimi = DIM.map(x => x.coduri.length);
  const combinatie = poz => {                // poziție -> indicele fiecărei dimensiuni
    const r = []; let rest = poz;
    for (let k = DIM.length - 1; k >= 0; k--){ r[k] = rest % marimi[k]; rest = Math.floor(rest / marimi[k]); }
    return r;
  };
  const vazute = new Set();
  let ales = null;

  /* valorile, câte un rând pe codul primei dimensiuni: așa se vede cubul */
  const randuriValori = () => {
    const pe = marimi.slice(1).reduce((a, b) => a * b, 1), r = [];
    for (let i = 0; i < VAL.length; i += pe)
      r.push("    " + VAL.slice(i, i + pe).map((v, j) =>
        `<span class="cub__v" data-p="${i + j}">"${i + j}": ${v == null ? "null" : v}</span>`).join(", "));
    return r.join(",\n");
  };
  const linieDim = (x, k) => `    "${esc(x.id)}": { "category": { "index": {\n      ${x.coduri.map((c, i) =>
      `<span class="cub__c" data-k="${k}" data-i="${i}">"${esc(c)}": ${i}</span>`).join(", ")} } } }`;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="cub">
      <div class="dsf__doi">
        <div>
          <span class="dsf__et">${esc(d.sursa || "răspunsul Eurostat")}</span>
<pre class="dsf__j cub__j">{
  "id": [${DIM.map(x => `"${esc(x.id)}"`).join(", ")}],
  "dimension": {
${DIM.map(linieDim).join(",\n")}
  },
  "value": {
${randuriValori()}
  }
}</pre>
        </div>
        <div>
          <span class="dsf__et">DataFrame</span>
          <table class="dsf__tb cub__tb">
            <thead><tr>${DIM.map((x, k) => `<th class="k${k}">${esc(x.id)}</th>`).join("")}<th>valoare</th></tr></thead>
            <tbody></tbody>
          </table>
          <p class="dsf__gol">Apasă pe o valoare din <code>value</code>.</p>
        </div>
      </div>
      <p class="cub__regula"></p>
      <div class="dsf__act">
        <button class="btn btn--mic btn--tare" data-rol="urm" type="button">Următoarea valoare</button>
        <button class="btn btn--mic" data-rol="tot" type="button">Toate odată</button>
        <span class="dsf__stare"></span>
      </div>
    </div>`;

  const tb = gazda.querySelector(".cub__tb tbody"), gol = gazda.querySelector(".dsf__gol");
  const reg = gazda.querySelector(".cub__regula"), stare = gazda.querySelector(".dsf__stare");

  function deseneaza(){
    const ci = ales === null ? null : combinatie(ales);
    gazda.querySelectorAll(".cub__v").forEach(e => {
      e.classList.toggle("on", +e.dataset.p === ales); e.classList.toggle("vazut", vazute.has(+e.dataset.p)); });
    gazda.querySelectorAll(".cub__c").forEach(e => e.classList.toggle("on", ci !== null && ci[+e.dataset.k] === +e.dataset.i));
    const rand = [...vazute].sort((a, b) => a - b);
    tb.innerHTML = rand.map(p => { const c = combinatie(p);
      return `<tr class="${p === ales ? "on" : ""}">${c.map((i, k) => `<td class="k${k}">${esc(DIM[k].coduri[i])}</td>`).join("")}<td class="nr">${fmtN(VAL[p])}</td></tr>`; }).join("");
    gol.hidden = vazute.size > 0;
    if (ci){
      const parti = ci.map((i, k) => `${esc(DIM[k].id)} „${esc(DIM[k].coduri[i])}” e pe poziția ${i}`).join(", ");
      const n = marimi[marimi.length - 1];
      reg.innerHTML = `<b>Poziția ${ales}</b>: ${parti}. ${DIM.length === 2
        ? `${ci[0]} × ${n} + ${ci[1]} = ${ales}.` : ""} ${d.cine && d.cine[ales] ? esc(d.cine[ales]) : ""}`;
    } else reg.innerHTML = d.intro || "Fiecare valoare stă pe o poziție. Poziția spune din ce coduri vine.";
    stare.textContent = `${vazute.size} din ${VAL.length} rânduri`;
  }
  const alege = p => { ales = p; vazute.add(p); deseneaza(); };
  gazda.querySelector(".cub__j").addEventListener("click", e => { const v = e.target.closest(".cub__v"); if (v) alege(+v.dataset.p); });
  gazda.querySelector('[data-rol="urm"]').onclick = () => alege(ales === null ? 0 : (ales + 1) % VAL.length);
  gazda.querySelector('[data-rol="tot"]').onclick = () => { VAL.forEach((_, i) => vazute.add(i)); ales = null; deseneaza(); };
  deseneaza();
};

/* ===========================================================================
   17. COMANDA — o cerere, ca scenă: masa, ospătarul, bucătăria
   Logica analogiei, nu doar numele ei: meniul stă pe masă (se citește înainte
   de a comanda, nu e o stație pe drum), bonul pleacă de la client prin ospătar
   la bucătărie, bucătăria scoate din cămară, iar farfuria se întoarce pe
   același drum. A doua comandă cere ceva ce nu e în meniu: farfuria vine
   goală, cu un număr. Aceeași scenă servește și varianta „în cod”.
   =========================================================================== */
V.comanda = (gazda, d) => {
  const Z = d.zone || [];                      // [client, intermediar, bucătărie]
  const SC = d.scenarii || [];
  const PASI = d.pasi || [];                   // 5 explicații, câte una pe pas
  let sc = 0, pas = -1;

  const zona = (z, i) => `
    <div class="cmd__z cmd__z--${i}" data-z="${i}">
      <div class="cmd__ic">${z.ic}</div>
      <div class="cmd__n">${esc(z.n)}</div>
      <div class="cmd__et">${esc(z.et)}</div>
      ${z.obiect ? `<div class="cmd__ob" data-ob="${i}"><span>${z.obiect.ic}</span>
        <b>${esc(z.obiect.n)}</b><i>${esc(z.obiect.et)}</i></div>` : ""}
    </div>`;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="cmd">
      <div class="cmd__sc">${SC.map((s, i) => `<button type="button" data-sc="${i}">${esc(s.t)}</button>`).join("")}</div>
      <div class="cmd__scena">
        <div class="cmd__drum"><span></span><span></span></div>
        ${Z.map(zona).join("")}
        <div class="cmd__bon" hidden></div>
        <div class="cmd__far" hidden></div>
      </div>
      <div class="cmd__jos">
        <div class="cmd__txt"></div>
        <div class="cmd__nav">
          <div class="cmd__puncte">${PASI.map((_, i) => `<i data-p="${i}"></i>`).join("")}</div>
          <button class="btn btn--mic" data-rol="inapoi" type="button">Înapoi</button>
          <button class="btn btn--mic btn--tare" data-rol="inainte" type="button"></button>
        </div>
      </div>
    </div>`;

  const $ = q => gazda.querySelector(q);
  const bon = $(".cmd__bon"), far = $(".cmd__far"), txt = $(".cmd__txt");

  function deseneaza(){
    const s = SC[sc] || {};
    gazda.querySelectorAll(".cmd__sc button").forEach(b => b.classList.toggle("on", +b.dataset.sc === sc));
    gazda.querySelectorAll(".cmd__puncte i").forEach(e => e.classList.toggle("on", +e.dataset.p <= pas));
    /* cine e activ la pasul ăsta */
    const activ = [[0], [0], [1], [2], [0]][pas] || [];
    gazda.querySelectorAll(".cmd__z").forEach(z => z.classList.toggle("on", activ.includes(+z.dataset.z)));
    $('.cmd__ob[data-ob="0"]')?.classList.toggle("on", pas === 0);
    $('.cmd__ob[data-ob="2"]')?.classList.toggle("on", pas === 3);
    $(".cmd__drum span:first-child").classList.toggle("on", pas === 2);
    $(".cmd__drum span:last-child").classList.toggle("on", pas === 4);

    bon.hidden = !(pas >= 1 && pas <= 3);
    bon.innerHTML = `<span class="cmd__mic">${esc(d.etBon || "comanda")}</span>${esc(s.bon || "")}`;
    const la = pas <= 1 ? 0 : pas === 2 ? 1 : 2;      // bonul: la client, la ospătar, la bucătărie
    bon.className = `cmd__bon la-${la}${pas >= 2 ? " dus" : ""}`;

    const vine = pas === 4 && far.hidden;
    far.hidden = pas !== 4;
    const rau = s.rau ? " rau" : "";
    if (vine){ far.className = "cmd__far la-2" + rau; void far.offsetWidth; }
    if (pas === 4) far.className = "cmd__far la-0" + rau;
    far.innerHTML = `<span class="cmd__mic">${esc(d.etFar || "farfuria")}</span><span class="cmd__cod">${esc(s.cod || "")}</span><span class="cmd__corp">${esc(s.far || "")}</span>`;

    const p = pas < 0 ? (d.intro || "") : (PASI[pas] || {});
    txt.innerHTML = pas < 0 ? `<p>${p}</p>`
      : `<b>${pas + 1}. ${p.t}</b><p>${(s.text && s.text[pas]) || p.d}</p>`;
    $('[data-rol="inapoi"]').disabled = pas < 0;
    $('[data-rol="inainte"]').textContent = pas < 0 ? (d.buton || "Începe") : pas >= PASI.length - 1 ? "Încă o dată" : "Pasul următor";
  }
  $('[data-rol="inainte"]').onclick = () => { pas = pas >= PASI.length - 1 ? -1 : pas + 1; deseneaza(); };
  $('[data-rol="inapoi"]').onclick = () => { pas = Math.max(-1, pas - 1); deseneaza(); };
  gazda.querySelectorAll(".cmd__sc button").forEach(b => b.onclick = () => { sc = +b.dataset.sc; pas = 0; deseneaza(); });
  deseneaza();
};

/* ===========================================================================
   18. DIRECȚII — migrația are sens, SCI-ul nu
   Tabelul de migrație are un rând pe direcție: românii din Italia, apoi
   italienii din România. Ca să stea lângă SCI, care are o valoare pe pereche,
   cele două direcții se pun pe același rând. Aici se vede mutarea, și se vede
   ce se întâmplă când o direcție lipsește: suma iese lipsă, nu zero.
   =========================================================================== */
V.directii = (gazda, d) => {
  const R = d.randuri || [];        // [{a, b, ab, ba}] ab = din a în b, ba = din b în a (null = lipsă)
  const f = x => x == null ? `<span class="dir__gol">lipsă</span>` : Number(x).toLocaleString("ro-RO");
  let pas = 0;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="dir">
      <div class="dsf__doi">
        <div>
          <span class="dsf__et">${esc(d.etSt || "migratie.csv: un rând pe direcție")}</span>
          <table class="dsf__tb dir__tb"><thead><tr><th>cetățenie</th><th>rezidență</th><th>persoane</th></tr></thead>
          <tbody>${R.map((r, i) => `
            <tr class="d1" data-i="${i}"><td>${esc(r.a)}</td><td>${esc(r.b)}</td><td class="nr">${f(r.ab)}</td></tr>
            <tr class="d2" data-i="${i}"><td>${esc(r.b)}</td><td>${esc(r.a)}</td><td class="nr">${f(r.ba)}</td></tr>`).join("")}</tbody></table>
        </div>
        <div>
          <span class="dsf__et">${esc(d.etDr || "perechi: un rând pe pereche")}</span>
          <table class="dsf__tb dir__tb"><thead><tr><th>tara_1</th><th>tara_2</th><th class="c1">din_1_in_2</th><th class="c2">din_2_in_1</th><th class="c3">migranti</th></tr></thead>
          <tbody></tbody></table>
          <p class="dsf__gol">Încă nimic.</p>
        </div>
      </div>
      <p class="cub__regula"></p>
      <div class="dsf__act">
        <button class="btn btn--mic btn--tare" data-rol="pas" type="button"></button>
      </div>
    </div>`;
  const tb = gazda.querySelectorAll(".dir__tb tbody")[1], gol = gazda.querySelector(".dsf__gol");
  const reg = gazda.querySelector(".cub__regula"), bt = gazda.querySelector('[data-rol="pas"]');
  const TEXT = [
    d.t0 || "Fiecare pereche apare de două ori, o dată pe direcție.",
    d.t1 || "Cele două direcții stau acum pe același rând, ca la SCI.",
    d.t2 || "Suma: unde lipsește o direcție, suma lipsește. Nu știm, deci nu punem zero.",
  ];
  function deseneaza(){
    gazda.querySelector(".dir").classList.toggle("aprins", pas >= 1);
    tb.innerHTML = pas < 1 ? "" : R.map(r => `<tr><td>${esc(r.a)}</td><td>${esc(r.b)}</td>
      <td class="nr c1">${f(r.ab)}</td><td class="nr c2">${f(r.ba)}</td>
      <td class="nr c3">${pas < 2 ? "" : (r.ab == null || r.ba == null) ? f(null) : f(r.ab + r.ba)}</td></tr>`).join("");
    gol.hidden = pas >= 1;
    reg.innerHTML = TEXT[pas];
    bt.textContent = pas === 0 ? "Pune-le pe un rând" : pas === 1 ? "Adună direcțiile" : "Încă o dată";
  }
  bt.onclick = () => { pas = (pas + 1) % 3; deseneaza(); };
  deseneaza();
};

/* ===========================================================================
   19. HISTO — aceeași variabilă, pe scară liniară și pe scară logaritmică
   SCI-ul perechilor de țări are o coadă lungă: câteva perechi uriașe, multe
   mici. Pe scară liniară aproape toate stau într-o singură bară. Apeși
   „logaritm” și distribuția se desface. Asimetria (skew) e scrisă sub fiecare.
   =========================================================================== */
V.histo = (gazda, d) => {
  const X = (d.valori || []).filter(v => v > 0);
  const NB = d.bare || 24;
  let log = false;
  const asim = a => {               // skew, aceeași formulă ca pandas
    const n = a.length, m = a.reduce((s, v) => s + v, 0) / n;
    const s2 = a.reduce((s, v) => s + (v - m) ** 2, 0) / (n - 1);
    const s3 = a.reduce((s, v) => s + (v - m) ** 3, 0) / n;
    return (Math.sqrt(n * (n - 1)) / (n - 2)) * (s3 / Math.pow(s2 * (n - 1) / n, 1.5));
  };
  const fmt = v => v >= 1000 ? Math.round(v).toLocaleString("ro-RO") : v.toLocaleString("ro-RO", { maximumFractionDigits: 1 });
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="hst">
      <div class="cmd__sc hst__sc">
        <button type="button" data-l="0">${esc(d.etLin || "scară liniară")}</button>
        <button type="button" data-l="1">${esc(d.etLog || "logaritm")}</button>
      </div>
      <svg class="hst__svg" viewBox="0 0 600 220" role="img" aria-label="histogramă"></svg>
      <p class="cub__regula hst__txt"></p>
    </div>`;
  const svg = gazda.querySelector("svg"), txt = gazda.querySelector(".hst__txt");
  function deseneaza(){
    gazda.querySelectorAll(".hst__sc button").forEach(b => b.classList.toggle("on", +b.dataset.l === +log));
    const v = X.map(x => log ? Math.log10(x) : x);
    const lo = Math.min(...v), hi = Math.max(...v), w = (hi - lo) / NB;
    const nr = Array(NB).fill(0);
    v.forEach(x => nr[Math.min(NB - 1, Math.floor((x - lo) / w))]++);
    const max = Math.max(...nr), L = 40, R = 580, T = 28, B = 180, bw = (R - L) / NB;
    const ticks = log
      ? [3, 4, 5, 6].filter(t => t >= lo - .01 && t <= hi + .01).map(t => [t, (10 ** t).toLocaleString("ro-RO")])
      : [0, .25, .5, .75, 1].map(f => [lo + f * (hi - lo), fmt(lo + f * (hi - lo))]);
    const xp = x => L + (x - lo) / (hi - lo) * (R - L);
    svg.innerHTML = `
      <line x1="${L}" y1="${B}" x2="${R}" y2="${B}" class="hst__axa"/>
      ${nr.map((n, i) => n ? `<rect x="${L + i * bw + 1}" y="${B - n / max * (B - T)}" width="${bw - 2}" height="${n / max * (B - T)}" rx="2" class="hst__b${log ? " log" : ""}"><title>${n} perechi</title></rect>` : "").join("")}
      ${ticks.map(([t, e], i) => `<text x="${xp(t)}" y="${B + 18}" class="hst__et"${xp(t) > R - 30 ? ' style="text-anchor:end"' : ""}>${e}</text>`).join("")}
      <text x="${L}" y="${T - 12}" class="hst__et hst__et--y">${max} perechi în bara cea mai înaltă</text>`;
    const s = asim(v);
    txt.innerHTML = log ? (d.txtLog || "") + ` Asimetria: <b>${s.toFixed(2).replace(".", ",")}</b>.`
                        : (d.txtLin || "") + ` Asimetria: <b>${s.toFixed(2).replace(".", ",")}</b>.`;
  }
  gazda.querySelectorAll(".hst__sc button").forEach(b => b.onclick = () => { log = b.dataset.l === "1"; deseneaza(); });
  deseneaza();
};

/* ===========================================================================
   20. NOR — două variabile, un nor de puncte
   Fiecare punct e o pereche de țări. Pe verticală logaritmul SCI-ului, pe
   orizontală alegi: distanța sau migranții. Perechile vecine sunt în
   chihlimbar. Dreapta e cea mai bună linie prin nor; r e scris dedesubt.
   Treci cu mouse-ul peste un punct și vezi perechea.
   =========================================================================== */
V.nor = (gazda, d) => {
  const P = d.puncte || [];             // [{t, x: {cheie: val}, y, g}]
  const VX = d.variabile || [];         // [{k, et, log}]
  let vx = 0;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="nor">
      <div class="cmd__sc nor__sc">${VX.map((v, i) => `<button type="button" data-v="${i}">${esc(v.et)}</button>`).join("")}</div>
      <div class="nor__desen">
        <svg viewBox="0 0 600 330" role="img" aria-label="nor de puncte"></svg>
        <div class="hs__balon nor__balon" hidden></div>
      </div>
      <div class="nor__leg"><span><i class="nor__p nor__p--g"></i>${esc(d.etG || "au graniță comună")}</span>
        <span><i class="nor__p"></i>${esc(d.etN || "nu au")}</span></div>
      <p class="cub__regula nor__txt"></p>
      ${d.cauta ? `<p class="nor__cauta"><b>Găsește:</b> ${d.cauta.t} <span>Dă clic pe punct.</span></p>` : ""}
    </div>`;
  const svg = gazda.querySelector("svg"), bal = gazda.querySelector(".nor__balon"), txt = gazda.querySelector(".nor__txt");
  const cauta = gazda.querySelector(".nor__cauta");
  let gasit = false;
  const L = 78, R = 588, T = 18, B = 290;
  function deseneaza(){
    gazda.querySelectorAll(".nor__sc button").forEach(b => b.classList.toggle("on", +b.dataset.v === vx));
    const v = VX[vx];
    const pts = P.filter(p => p.x[v.k] != null && p.x[v.k] > 0).map(p => ({ ...p, xx: Math.log10(p.x[v.k]), yy: Math.log10(p.y) }));
    const xs = pts.map(p => p.xx), ys = pts.map(p => p.yy);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    const X = x => L + (x - x0) / (x1 - x0) * (R - L), Y = y => B - (y - y0) / (y1 - y0) * (B - T);
    const n = pts.length, mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
    let sxy = 0, sxx = 0, syy = 0;
    pts.forEach(p => { sxy += (p.xx - mx) * (p.yy - my); sxx += (p.xx - mx) ** 2; syy += (p.yy - my) ** 2; });
    const b = sxy / sxx, a = my - b * mx, r = sxy / Math.sqrt(sxx * syy);
    const div = (a0, a1) => { const r = [];      // diviziuni 1, 2, 5 × 10^k în interval
      for (let k = Math.floor(a0); k <= Math.ceil(a1); k++) for (const m of [1, 2, 5]) {
        const t = k + Math.log10(m); if (t >= a0 - 1e-9 && t <= a1 + 1e-9) r.push(t); }
      return r.length > 7 ? r.filter(t => Math.abs(t - Math.round(t)) < 1e-9 || Math.abs(t - Math.round(t) - Math.log10(5)) < 1e-9) : r; };
    const tx = div(x0, x1), ty = div(y0, y1);
    const et = t => { const v = 10 ** t; return v >= 1 ? Math.round(v).toLocaleString("ro-RO") : v.toLocaleString("ro-RO", { maximumSignificantDigits: 1 }); };
    svg.innerHTML = `
      ${ty.map(t => `<line x1="${L}" x2="${R}" y1="${Y(t)}" y2="${Y(t)}" class="nor__grila"/><text x="${L - 6}" y="${Y(t) + 4}" class="hst__et nor__ety">${et(t)}</text>`).join("")}
      ${tx.map(t => `<text x="${X(t)}" y="${B + 18}" class="hst__et">${et(t)}</text>`).join("")}
      <text x="${R}" y="${B + 36}" class="hst__et nor__titlu-x">${esc(v.et)} (scară logaritmică)</text>
      <text x="${L}" y="${T - 6}" class="hst__et nor__titlu-y">${esc(d.etY || "SCI")}</text>
      <line x1="${X(x0)}" y1="${Y(a + b * x0)}" x2="${X(x1)}" y2="${Y(a + b * x1)}" class="nor__dreapta"/>
      ${pts.map((p, i) => `<circle cx="${X(p.xx)}" cy="${Y(p.yy)}" r="4.2" class="nor__p${p.g ? " nor__p--g" : ""}" data-i="${i}"/>`).join("")}`;
    svg.querySelectorAll("circle").forEach(c => {
      c.onmouseenter = () => { const p = pts[+c.dataset.i];
        bal.innerHTML = `<b>${esc(p.t)}</b><span>SCI ${Math.round(p.y).toLocaleString("ro-RO")} · ${esc(v.et)} ${p.x[v.k].toLocaleString("ro-RO", { maximumFractionDigits: 1 })}</span>`;
        bal.hidden = false; const rc = svg.getBoundingClientRect(), k = rc.width / 600;
        bal.style.left = Math.min(rc.width - 200, +c.getAttribute("cx") * k + 10) + "px"; bal.style.top = (+c.getAttribute("cy") * k - 10) + "px"; };
      c.onmouseleave = () => { bal.hidden = true; };
      /* căutarea: cât de departe e punctul ales deasupra dreptei, față de toate */
      if (d.cauta) c.onclick = () => {
        if (VX[vx].k !== (d.cauta.v || VX[0].k)){
          cauta.innerHTML = `<b>Găsește:</b> ${d.cauta.t} <span>Comută întâi pe „${esc((VX.find(x => x.k === (d.cauta.v || VX[0].k)) || VX[0]).et)}”.</span>`; return; }
        const rez = pts.map(q => q.yy - (a + b * q.xx));
        const i = +c.dataset.i, ord = rez.map((r, k) => [r, k]).sort((u, w) => w[0] - u[0]);
        const loc = ord.findIndex(([, k]) => k === i);
        svg.querySelectorAll("circle").forEach(x => x.classList.remove("nor__p--ales"));
        c.classList.add("nor__p--ales");
        if (loc === 0){ gasit = true;
          cauta.innerHTML = `<b>Găsit: ${esc(pts[i].t)}.</b> ${d.cauta.dupa || ""}`; cauta.classList.add("ok"); }
        else if (!gasit) cauta.innerHTML = `<b>Găsește:</b> ${d.cauta.t} <span>${esc(pts[i].t)} e ${rez[i] < 0
          ? "sub linie: mai puțin legată decât ar spune distanța"
          : `a ${loc + 1}-a din ${pts.length}, cât de sus stă peste linie`}. Caută mai sus, mai departe de linie.</span>`;
      };
    });
    txt.innerHTML = `<b>r = ${r.toFixed(2).replace(".", ",")}</b>, pe ${n} perechi. ${v.text || ""}`;
  }
  gazda.querySelectorAll(".nor__sc button").forEach(b => b.onclick = () => { vx = +b.dataset.v; deseneaza(); });
  deseneaza();
};

/* ===========================================================================
   21. AXA — același grafic, axa tăiată
   Două bare cu valori adevărate. Pe axa care pornește de la zero, diferența
   e cât e. Tai axa și diferența pare de trei ori mai mare. Graficul nu
   minte în cifre, minte în proporții.
   =========================================================================== */
V.axa = (gazda, d) => {
  const BR = d.bare || [];
  let taiat = false;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="axa">
      <div class="cmd__sc axa__sc">
        <button type="button" data-t="0">axa de la zero</button>
        <button type="button" data-t="1">axa tăiată la ${Number(d.taie).toLocaleString("ro-RO")}</button>
      </div>
      <svg viewBox="0 0 600 230" role="img" aria-label="bare"></svg>
      <p class="cub__regula axa__txt"></p>
    </div>`;
  const svg = gazda.querySelector("svg"), txt = gazda.querySelector(".axa__txt");
  function deseneaza(){
    gazda.querySelectorAll(".axa__sc button").forEach(b => b.classList.toggle("on", +b.dataset.t === +taiat));
    const lo = taiat ? d.taie : 0, hi = Math.max(...BR.map(b => b.v)) * 1.05;
    const L = 70, R = 590, T = 16, B = 196, bw = (R - L) / BR.length;
    const Y = v => B - (v - lo) / (hi - lo) * (B - T);
    svg.innerHTML = `
      <line x1="${L}" y1="${B}" x2="${R}" y2="${B}" class="hst__axa"/>
      <text x="${L - 8}" y="${B + 4}" class="hst__et nor__ety">${lo.toLocaleString("ro-RO")}</text>
      ${BR.map((b, i) => `<rect x="${L + i * bw + bw * .2}" y="${Y(b.v)}" width="${bw * .6}" height="${B - Y(b.v)}" rx="3" class="axa__b axa__b--${i}"/>
        <text x="${L + i * bw + bw / 2}" y="${Y(b.v) - 6}" class="hst__et axa__v">${b.v.toLocaleString("ro-RO")}</text>
        <text x="${L + i * bw + bw / 2}" y="${B + 18}" class="hst__et">${esc(b.t)}</text>`).join("")}
      ${taiat ? `<path d="M${L - 6} ${B - 8} l12 -6 M${L - 6} ${B - 2} l12 -6" class="axa__rupt"/>` : ""}`;
    const [a, b] = BR, raport = (h => h)((a.v - lo) / (b.v - lo));
    txt.innerHTML = taiat
      ? `Bara din stânga pare de <b>${raport.toFixed(1).replace(".", ",")} ori</b> mai înaltă. ${d.txtTaiat || ""}`
      : `Bara din stânga e de <b>${(a.v / b.v).toFixed(2).replace(".", ",")} ori</b> mai înaltă: exact cât sunt valorile. ${d.txtZero || ""}`;
  }
  gazda.querySelectorAll(".axa__sc button").forEach(b => b.onclick = () => { taiat = b.dataset.t === "1"; deseneaza(); });
  deseneaza();
};

/* ===========================================================================
   22. MODELE — patru modele, pas cu pas
   Fiecare model adaugă o variabilă. Coeficienții stau ca bare în jurul lui
   zero, fiecare variabilă cu culoarea ei, iar R² crește dedesubt. Se vede
   lucrul care contează: când intră migrația, coeficientul distanței se
   micșorează. O parte din ce părea efectul distanței era migrație.
   =========================================================================== */
V.modele = (gazda, d) => {
  const M = d.modele || [];             // [{nume, formula, r2, coef: {k: v}, text}]
  const VAR = d.variabile || [];        // [{k, et, c}]
  const LIM = d.lim || 0.8;
  let i = 0;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="mdl">
      <div class="cmd__sc mdl__sc">${M.map((m, k) => `<button type="button" data-m="${k}">${esc(m.nume)}</button>`).join("")}</div>
      <code class="mdl__f"></code>
      <div class="mdl__rand mdl__cap"><span></span><span class="mdl__axa"><i>−${LIM}</i><i>0</i><i>+${LIM}</i></span><span></span></div>
      ${VAR.map(v => `<div class="mdl__rand" data-k="${v.k}" style="--vc:var(--${v.c})">
          <span class="mdl__n">${esc(v.et)}</span>
          <span class="mdl__pista"><span class="mdl__zero"></span><span class="mdl__b"></span></span>
          <span class="mdl__v"></span></div>`).join("")}
      <div class="mdl__r2"><span class="mdl__n">R²</span>
        <span class="mdl__pista mdl__pista--r2"><span class="mdl__b mdl__b--r2"></span></span>
        <span class="mdl__v mdl__v--r2"></span></div>
      <p class="cub__regula mdl__txt"></p>
      <div class="dsf__act"><button class="btn btn--mic btn--tare" data-rol="urm" type="button">Modelul următor</button></div>
    </div>`;
  const $ = q => gazda.querySelector(q);
  function deseneaza(){
    const m = M[i];
    gazda.querySelectorAll(".mdl__sc button").forEach(b => b.classList.toggle("on", +b.dataset.m === i));
    $(".mdl__f").textContent = m.formula;
    VAR.forEach(v => {
      const r = gazda.querySelector(`.mdl__rand[data-k="${v.k}"]`), c = m.coef[v.k];
      const b = r.querySelector(".mdl__b"), val = r.querySelector(".mdl__v");
      r.classList.toggle("absent", c == null);
      if (c == null){ b.style.width = "0"; val.textContent = "nu intră"; return; }
      const w = Math.min(1, Math.abs(c) / LIM) * 50;
      b.style.width = w + "%";
      b.style.left = c >= 0 ? "50%" : (50 - w) + "%";
      val.textContent = (c >= 0 ? "+" : "−") + Math.abs(c).toFixed(2).replace(".", ",");
    });
    $(".mdl__b--r2").style.width = (m.r2 * 100) + "%";
    $(".mdl__v--r2").textContent = m.r2.toFixed(2).replace(".", ",");
    $(".mdl__txt").innerHTML = m.text || "";
    $('[data-rol="urm"]').textContent = i === M.length - 1 ? "De la capăt" : "Modelul următor";
  }
  gazda.querySelectorAll(".mdl__sc button").forEach(b => b.onclick = () => { i = +b.dataset.m; deseneaza(); });
  $('[data-rol="urm"]').onclick = () => { i = (i + 1) % M.length; deseneaza(); };
  deseneaza();
};

/* ===========================================================================
   23. GITDAG — laptopul tău și GitHub, pas cu pas
   Două depozite, unul lângă altul. Commit-urile sunt buline, colorate după
   cine le-a făcut; ramurile sunt etichete lipite de un commit; HEAD arată pe
   ce ramură ești. Fiecare pas e o comandă din fluxul de lucru al echipei
   (main + dev). Se vede ce se mută și ce nu: commit-urile rămân pe loc,
   etichetele avansează, iar push și pull copiază buline dintr-o parte în alta.
   =========================================================================== */
V.gitdag = (gazda, d) => {
  const C = d.commituri || {};          // id -> {x, r (rând), autor, mesaj, parinti: []}
  const A = d.autori || {};             // autor -> {et, c}
  const P = d.pasi || [];               // [{cmd, cine, txt, rau, L: {commits, et: {ram: id}, head}, R: {...}}]
  let i = 0;
  const panou = (titlu, cls) => `
    <div class="gd__panou ${cls}">
      <div class="gd__titlu">${titlu}</div>
      <svg viewBox="0 0 330 200" role="img" aria-label="${esc(titlu)}"></svg>
    </div>`;
  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="gd">
      <div class="gd__term"><span class="gd__cine"></span><code class="gd__cmd"></code></div>
      <div class="gd__doua">
        ${panou(d.etLocal || "💻 Laptopul tău", "gd__panou--l")}
        <div class="gd__sageti"><span class="gd__s gd__s--sus">push →</span><span class="gd__s gd__s--jos">← pull</span></div>
        ${panou(d.etRemote || "☁️ GitHub (origin)", "gd__panou--r")}
      </div>
      <div class="gd__leg">${Object.entries(A).map(([k, a]) => `<span><i style="background:var(--${a.c})"></i>${esc(a.et)}</span>`).join("")}</div>
      <div class="cmd__jos">
        <div class="cmd__txt gd__txt"></div>
        <div class="cmd__nav">
          <div class="cmd__puncte">${P.map((_, k) => `<i data-p="${k}"></i>`).join("")}</div>
          <button class="btn btn--mic" data-rol="inapoi" type="button">Înapoi</button>
          <button class="btn btn--mic btn--tare" data-rol="inainte" type="button">Pasul următor</button>
        </div>
      </div>
    </div>`;
  const $ = q => gazda.querySelector(q);
  const X = x => 40 + x * 78, Y = r => 64 + r * 50;
  let vazute = { L: new Set(), R: new Set() };

  function deseneaza(svg, st, latura, prefix){
    const are = new Set(st.commits);
    const linii = [], buline = [], etichete = [];
    st.commits.forEach(id => {
      const c = C[id];
      (c.parinti || []).filter(p => are.has(p)).forEach(p => {
        const a = C[p], x1 = X(a.x), y1 = Y(a.r), x2 = X(c.x), y2 = Y(c.r);
        linii.push(y1 === y2 ? `M${x1} ${y1} H${x2}`
          : `M${x1} ${y1} C${x1 + 30} ${y1} ${x2 - 30} ${y2} ${x2} ${y2}`);
      });
      const nou = !vazute[latura].has(id);
      buline.push(`<circle cx="${X(c.x)}" cy="${Y(c.r)}" r="${c.merge ? 10 : 9}" class="gd__c${nou ? " nou" : ""}${c.merge ? " merge" : ""}"
        style="--cc:var(--${(A[c.autor] || {}).c || "accent"})"><title>${esc(c.mesaj || id)}</title></circle>`);
    });
    /* etichetele: mai multe pe același commit se stivuiesc deasupra */
    const peCommit = {};
    Object.entries(st.et || {}).forEach(([ram, id]) => { (peCommit[id] = peCommit[id] || []).push(ram); });
    Object.entries(peCommit).forEach(([id, rams]) => {
      const c = C[id];
      rams.forEach((ram, k) => {
        const head = st.head === ram, txt = prefix + ram, w = (txt.length + (head ? 7 : 0)) * 7.1 + 14;
        const x = X(c.x) - w / 2, y = Y(c.r) - 34 - k * 22;
        etichete.push(`<g class="gd__et gd__et--${ram}${head ? " head" : ""}">
          <rect x="${x}" y="${y}" width="${w}" height="18" rx="9"/>
          <text x="${x + 7}" y="${y + 12.5}">${head ? "HEAD → " : ""}${txt}</text></g>`);
      });
    });
    svg.innerHTML = `${linii.map(l => `<path d="${l}" class="gd__l"/>`).join("")}${buline.join("")}${etichete.join("")}`;
    st.commits.forEach(id => vazute[latura].add(id));
  }

  function arata(){
    const p = P[i];
    $(".gd__cine").textContent = p.cine || "tu $";
    $(".gd__cine").classList.toggle("alt", !!p.cine && p.cine !== "tu $");
    $(".gd__cmd").textContent = p.cmd;
    $(".gd__term").classList.toggle("rau", !!p.rau);
    $(".gd__s--sus").classList.toggle("on", !!p.sus);
    $(".gd__s--jos").classList.toggle("on", !!p.jos);
    deseneaza($(".gd__panou--l svg"), p.L, "L", "");
    deseneaza($(".gd__panou--r svg"), p.R, "R", "origin/");
    $(".gd__txt").innerHTML = `<b>${i + 1}. ${p.t || ""}</b><p>${p.txt || ""}</p>`;
    gazda.querySelectorAll(".cmd__puncte i").forEach(e => e.classList.toggle("on", +e.dataset.p <= i));
    $('[data-rol="inapoi"]').disabled = i === 0;
    $('[data-rol="inainte"]').textContent = i === P.length - 1 ? "De la capăt" : "Pasul următor";
  }
  $('[data-rol="inainte"]').onclick = () => {
    if (i === P.length - 1){ i = 0; vazute = { L: new Set(), R: new Set() }; } else i++;
    arata();
  };
  $('[data-rol="inapoi"]').onclick = () => { i = Math.max(0, i - 1); arata(); };
  arata();
};


/* ===========================================================================
   SCI — indicele construit sub ochii lor, pas cu pas

   Formula scrisă pe tablă se uită. Aici se vede de unde vine fiecare bucată:
   punctele sunt utilizatori, liniile gri sunt toate prieteniile posibile
   (numitorul), liniile colorate sunt prieteniile reale (numărătorul). Apoi
   intră un loc mare, cu mai multe prietenii și indice mai mic, apoi o rețea
   de cinci locuri în care ordinea se schimbă după ce măsori. La final,
   scalarea din fișier. Numerele sunt mici, ca să se poată număra; raporturile
   sunt alese ca aritmetica să iasă rotund.
   =========================================================================== */

V.sci = (gazda, d) => {
  const NS = "http://www.w3.org/2000/svg";
  const grila = (cx, cy, n, col, sp) => { const rows = Math.ceil(n / col), r = [];
    for (let k = 0; k < n; k++){ const i = k % col, j = Math.floor(k / col);
      r.push([cx + (i - (col - 1) / 2) * sp, cy + (j - (rows - 1) / 2) * sp]); } return r; };
  const CAZ = d.cazuri || [
    { n: "Republica Moldova", u: 4, col: 2, f: [[0,0],[0,3],[1,1],[2,2],[4,0],[5,3]] },
    { n: "Italia", u: 12, col: 4, f: [[0,1],[1,5],[2,3],[2,8],[3,10],[4,4],[4,11],[5,6],[1,9]] },
  ];
  const A = 6, nf = x => x.toLocaleString("ro-RO", { maximumFractionDigits: 3 });
  const panou = (c, k) => {
    const a = grila(80, 110, A, 2, 34), b = grila(300, 110, c.u, c.col, c.col > 2 ? 28 : 34);
    const pos = a.flatMap(p => b.map(q => `<line x1="${p[0]}" y1="${p[1]}" x2="${q[0]}" y2="${q[1]}" class="sc__pos"/>`)).join("");
    const pr = c.f.map(([i, j]) => `<line x1="${a[i][0]}" y1="${a[i][1]}" x2="${b[j][0]}" y2="${b[j][1]}" class="sc__pr"/>`).join("");
    const pt = (arr, cls) => arr.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="9" class="${cls}"/>`).join("");
    const posibile = A * c.u, v = c.f.length / posibile;
    return `<figure class="sc__p">
      <svg viewBox="0 0 380 220" aria-hidden="true"><g class="sc__gpos">${pos}</g>${pr}${pt(a, "sc__i")}${pt(b, "sc__j")}
        <text x="80" y="208" text-anchor="middle" class="sc__et">Cluj · ${A}</text>
        <text x="300" y="208" text-anchor="middle" class="sc__et">${esc(c.n)} · ${c.u}</text></svg>
      <figcaption><span class="sc__calc"><b class="sc__f">${c.f.length}</b> prietenii / (${A} × ${c.u} = <b class="sc__u">${posibile}</b> posibile)</span>
        <span class="sc__v">= ${nf(v)}</span></figcaption></figure>`;
  };
  gazda.innerHTML = `
    <div class="sc">
      <p class="sc__formula"><i>SCI</i> = <span class="sc__fr"><span class="sc__f">prieteniile dintre cele două locuri</span>
        <span class="sc__u">utilizatori într-un loc × utilizatori în celălalt</span></span></p>
      <div class="sc__duo">${CAZ.map(panou).join("")}</div>
      <div class="sc__jos">
        <label class="sc__comut"><input type="checkbox"> arată și toate perechile posibile</label>
        <p class="sc__conc">${d.concluzie || ""}</p>
      </div>
    </div>`;
  const box = gazda.querySelector(".sc");
  gazda.querySelector(".sc__comut input").addEventListener("change", e => box.classList.toggle("sc--pos", e.target.checked));
};


/* ===========================================================================
   PY — un Python foarte mic, cât să răspundă ca o celulă Jupyter

   Știe exact ce trebuie la tipuri, liste, dicționare și JSON: nume, numere,
   texte, indexare (și negativă), type(), len(), print(), str(), int(),
   float(), .keys(), .values(). Răspunsurile și erorile au forma celor
   adevărate, ca să le recunoască în VS Code. Valorile vin din JSON, deci
   un float întreg (0.0) se scrie {"__f": 0}, iar un tuplu {"__t": [...]}.
   =========================================================================== */
const PY = (() => {
  const T = v => v === null ? "NoneType" : typeof v === "boolean" ? "bool"
    : typeof v === "string" ? "str"
    : typeof v === "number" ? (Number.isInteger(v) ? "int" : "float")
    : Array.isArray(v) ? "list"
    : v && typeof v === "object" && "__f" in v ? "float"
    : v && typeof v === "object" && "__t" in v ? "tuple"
    : v && v.__py ? v.__py : "dict";
  const nr = v => v && typeof v === "object" && "__f" in v ? v.__f : v;
  const fl = x => { const s = String(x); return /[.e]/.test(s) || !isFinite(x) ? s : s + ".0"; };
  const strRepr = s => {
    const q = s.includes("'") && !s.includes('"') ? '"' : "'";
    return q + s.replace(/\\/g, "\\\\").replace(new RegExp(q, "g"), "\\" + q).replace(/\n/g, "\\n") + q;
  };
  const repr = v => {
    const t = T(v);
    if (t === "NoneType") return "None";
    if (t === "bool") return v ? "True" : "False";
    if (t === "str") return strRepr(v);
    if (t === "int") return String(v);
    if (t === "float") return fl(nr(v));
    if (t === "tuple") return "(" + v.__t.map(repr).join(", ") + (v.__t.length === 1 ? ",)" : ")");
    if (t === "list") return "[" + v.map(repr).join(", ") + "]";
    if (t === "type") return `<class '${v.n}'>`;
    if (t === "dict_keys" || t === "dict_values") return `${t}([${v.v.map(repr).join(", ")}])`;
    return "{" + Object.entries(v).map(([k, x]) => strRepr(k) + ": " + repr(x)).join(", ") + "}";
  };
  /* ce afișează Jupyter pentru rezultatul unei celule */
  const afis = v => T(v) === "type" ? v.n : repr(v);
  const prt = v => T(v) === "str" ? v : repr(v);

  class Er extends Error { constructor(tip, msg){ super(msg); this.tip = tip; } }

  function tokeni(src){
    const t = [], re = /\s*(?:(\d+\.\d*|\d*\.\d+|\d+)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|([A-Za-z_]\w*)|(.))/gy;
    let m; re.lastIndex = 0;
    while (re.lastIndex < src.length && (m = re.exec(src))){
      if (m[1] !== undefined) t.push({ k: "n", v: m[1] });
      else if (m[2] !== undefined) t.push({ k: "s", v: m[2].slice(1, -1).replace(/\\(.)/g, "$1") });
      else if (m[3] !== undefined) t.push({ k: "i", v: m[3] });
      else if (m[4] !== undefined && m[4].trim()) t.push({ k: "p", v: m[4] });
    }
    return t;
  }

  function evalueaza(src, env){
    const tk = tokeni(src.trim()); let i = 0, tiparit = null;
    const vezi = () => tk[i], ia = () => tk[i++];
    const cere = v => { const x = ia(); if (!x || x.v !== v) throw new Er("SyntaxError", "invalid syntax"); };
    const FN = {
      type: a => ({ __py: "type", n: T(a) }),
      len: a => { const t = T(a);
        if (t === "str" || t === "list") return a.length;
        if (t === "tuple") return a.__t.length;
        if (t === "dict") return Object.keys(a).length;
        throw new Er("TypeError", `object of type '${t}' has no len()`); },
      print: a => { tiparit = (tiparit === null ? "" : tiparit + "\n") + prt(a); return null; },
      str: a => prt(a),
      int: a => { const t = T(a);
        if (t === "str"){ if (!/^\s*-?\d+\s*$/.test(a)) throw new Er("ValueError", `invalid literal for int() with base 10: ${strRepr(a)}`); return parseInt(a, 10); }
        if (t === "int" || t === "bool") return +a;
        if (t === "float") return Math.trunc(nr(a));
        throw new Er("TypeError", `int() argument must be a string or a number, not '${t}'`); },
      float: a => { const t = T(a);
        if (t === "str"){ if (!/^\s*-?(\d+\.?\d*|\.\d+)\s*$/.test(a)) throw new Er("ValueError", `could not convert string to float: ${strRepr(a)}`); return { __f: parseFloat(a) }; }
        if (t === "int" || t === "float" || t === "bool") return { __f: +nr(a) };
        throw new Er("TypeError", `float() argument must be a string or a real number, not '${t}'`); },
    };
    function primar(){
      const x = ia(); if (!x) throw new Er("SyntaxError", "invalid syntax");
      if (x.k === "n") return x.v.includes(".") ? { __f: parseFloat(x.v) } : parseInt(x.v, 10);
      if (x.k === "s") return x.v;
      if (x.k === "p" && x.v === "-"){ const y = primar(); const t = T(y);
        if (t === "int") return -y; if (t === "float") return { __f: -nr(y) };
        throw new Er("TypeError", `bad operand type for unary -: '${t}'`); }
      if (x.k === "p" && x.v === "("){ const v = expr(); cere(")"); return v; }
      if (x.k === "i"){
        if (x.v === "True") return true; if (x.v === "False") return false; if (x.v === "None") return null;
        if (vezi() && vezi().v === "(" && FN[x.v]){ ia(); const a = expr(); cere(")"); return FN[x.v](a); }
        if (!(x.v in env)) throw new Er("NameError", `name '${x.v}' is not defined`);
        return env[x.v];
      }
      throw new Er("SyntaxError", "invalid syntax");
    }
    function postfix(){
      let v = primar();
      for (;;){
        const x = vezi(); if (!x || x.k !== "p") break;
        if (x.v === "["){ ia(); const k = expr(); cere("]"); v = indexeaza(v, k); continue; }
        if (x.v === "."){ ia(); const m = ia(); cere("("); cere(")");
          if (T(v) === "dict" && m.v === "keys") { v = { __py: "dict_keys", v: Object.keys(v) }; continue; }
          if (T(v) === "dict" && m.v === "values") { v = { __py: "dict_values", v: Object.values(v) }; continue; }
          throw new Er("AttributeError", `'${T(v)}' object has no attribute '${m.v}'`); }
        break;
      }
      return v;
    }
    function expr(){
      let a = postfix();
      while (vezi() && vezi().k === "p" && (vezi().v === "+" || vezi().v === "-")){
        const op = ia().v, b = postfix(), ta = T(a), tb = T(b);
        const num = t => t === "int" || t === "float" || t === "bool";
        if (op === "+" && ta === "str" && tb === "str") a = a + b;
        else if (op === "+" && ta === "list" && tb === "list") a = [...a, ...b];
        else if (num(ta) && num(tb)){
          const r = op === "+" ? nr(a) + nr(b) : nr(a) - nr(b);
          a = ta === "float" || tb === "float" ? { __f: r } : r;
        }
        else if (op === "+" && ta === "str") throw new Er("TypeError", `can only concatenate str (not "${tb}") to str`);
        else throw new Er("TypeError", `unsupported operand type(s) for ${op}: '${ta}' and '${tb}'`);
      }
      return a;
    }
    const v = expr();
    if (i < tk.length) throw new Er("SyntaxError", "invalid syntax");
    return { v, tiparit };
  }

  function indexeaza(v, k){
    const t = T(v), tk = T(k);
    if (t === "list" || t === "tuple" || t === "str"){
      const a = t === "tuple" ? v.__t : v;
      if (tk !== "int") throw new Er("TypeError", `${t === "str" ? "string" : t} indices must be integers${t === "str" ? "" : " or slices"}, not ${tk}`);
      const j = k < 0 ? a.length + k : k;
      if (j < 0 || j >= a.length) throw new Er("IndexError", `${t === "str" ? "string" : t} index out of range`);
      return a[j];
    }
    if (t === "dict"){
      if (!(String(k) in v) || tk !== "str") throw new Er("KeyError", repr(k));
      return v[k];
    }
    throw new Er("TypeError", `'${t}' object is not subscriptable`);
  }

  /* drumul unei expresii de tip a[1]["b"]: rădăcina și pașii, pentru evidențiere */
  function drum(src){
    const m = src.trim().match(/^([A-Za-z_]\w*)((?:\s*\[[^\]]+\])*)\s*$/);
    if (!m) return null;
    const pasi = [...m[2].matchAll(/\[\s*([^\]]+?)\s*\]/g)].map(x => {
      const s = x[1]; return /^-?\d+$/.test(s) ? parseInt(s, 10) : s.replace(/^["']|["']$/g, "");
    });
    return { rad: m[1], pasi };
  }

  return { T, repr, afis, prt, evalueaza, indexeaza, drum, Er };
})();


/* Consola, ca o celulă Jupyter: scrii o expresie, apeși Enter, primești Out.
   Săgeata în sus aduce comanda de dinainte. Întoarce o funcție care spune
   de câte ori a fost folosită. */
function consolaJupyter(gazda, env, { start = 2, loc = "", laRulare = null } = {}){
  let n = start, ist = [], poz = 0;
  gazda.innerHTML = `<div class="jc__ist"></div>
    <label class="jc__linie"><span class="jc__in">In [${n}]:</span>
      <input class="jc__intrare" autocomplete="off" spellcheck="false" placeholder="${esc(loc)}" aria-label="Scrie o expresie Python și apasă Enter"></label>`;
  const istEl = gazda.querySelector(".jc__ist"), inp = gazda.querySelector(".jc__intrare");
  const eticheta = gazda.querySelector(".jc__in");
  inp.addEventListener("keydown", ev => {
    if (ev.key === "ArrowUp" && ist.length){ poz = Math.max(0, poz - 1); inp.value = ist[poz] || ""; ev.preventDefault(); return; }
    if (ev.key === "ArrowDown" && ist.length){ poz = Math.min(ist.length, poz + 1); inp.value = ist[poz] || ""; ev.preventDefault(); return; }
    if (ev.key !== "Enter") return;
    const src = inp.value.trim(); if (!src) return;
    ist.push(src); poz = ist.length;
    let html = `<div class="jc__r"><span class="jc__in">In [${n}]:</span><code>${esc(src)}</code></div>`;
    let rez = null;
    try {
      rez = PY.evalueaza(src, env);
      if (rez.tiparit !== null) html += `<pre class="jc__print">${esc(rez.tiparit)}</pre>`;
      if (rez.v === null && rez.tiparit === null)
        html += `<div class="jc__nota">nimic afișat: Jupyter nu arată rezultatul când e None</div>`;
      else if (!(rez.v === null && rez.tiparit !== null))
        html += `<div class="jc__r jc__r--out"><span class="jc__out">Out[${n}]:</span><code>${esc(PY.afis(rez.v))}</code></div>`;
    } catch (e){
      html += `<pre class="jc__err"><b>${esc(e.tip || "Error")}</b>: ${esc(e.message)}</pre>`;
    }
    istEl.insertAdjacentHTML("beforeend", html);
    istEl.scrollTop = istEl.scrollHeight;
    n++; eticheta.textContent = `In [${n}]:`; inp.value = "";
    if (laRulare) laRulare(src, rez);
  });
  return { folosiri: () => ist.length, focus: () => inp.focus() };
}


/* ===========================================================================
   CONSOLA DE TIPURI — ghicești tipul, iar dacă nu ești sigur, întrebi Python

   Valorile le-au văzut deja în caiet; aici nu le mai arăt pas cu pas. Scriu
   tipul fiecăreia, iar consola de dedesubt le răspunde ca Jupyter la
   type(variabila). Se înregistrează scorul și de câte ori au întrebat consola.
   =========================================================================== */
V.consola = (gazda, d) => {
  if (d.id) gazda.closest(".ix")?.classList.add("exc");
  const VARS = d.vars || [];
  const SIN = { none: "nonetype" };
  const norm = x => { const k = x.trim().replace(/^<class '|'>$/g, "").toLowerCase(); return SIN[k] || k; };
  let verificat = false;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="tcs">
      <div class="tcs__celula">
        <div class="tcs__cap"><span>${esc(d.fisier || "celulă")}</span><span class="jc__in">In [1]:</span></div>
        <pre class="tcs__cod">${(d.cod || []).map(l => esc(l)).join("\n")}</pre>
      </div>
      <div class="tcs__grila">
        ${VARS.map((x, k) => `<label class="tcs__r" data-k="${k}">
          <code class="tcs__n">${esc(x.n)}</code>
          <input class="tcs__t" autocomplete="off" spellcheck="false" placeholder="tipul" aria-label="tipul lui ${esc(x.n)}">
          <span class="tcs__st" aria-hidden="true"></span>
          <span class="tcs__e"></span>
        </label>`).join("")}
      </div>
      <div class="tcs__act">
        <button class="btn btn--mic btn--tare" data-rol="verifica" type="button">Verifică</button>
        <span class="tcs__scor"></span>
      </div>
      <div class="tcs__ajutor">
        <p><b>Nu ești sigur?</b> Întreabă Python. Scrie <code>type(${esc(VARS[0]?.n || "x")})</code> și apasă Enter, ca într-o celulă din Jupyter.</p>
        <div class="jc"></div>
      </div>
    </div>`;

  const cons = consolaJupyter(gazda.querySelector(".jc"), d.env || {}, { loc: `type(${VARS[0]?.n || "x"})` });
  const randuri = [...gazda.querySelectorAll(".tcs__r")];

  gazda.querySelector('[data-rol="verifica"]').onclick = async () => {
    let ok = 0, goale = 0;
    randuri.forEach((r, k) => {
      const x = VARS[k], inp = r.querySelector(".tcs__t"), v = inp.value;
      if (!v.trim()){ goale++; r.className = "tcs__r"; r.querySelector(".tcs__e").textContent = ""; return; }
      const bun = norm(v) === x.t.toLowerCase();
      if (bun) ok++;
      r.className = "tcs__r " + (bun ? "ok" : "nu");
      r.querySelector(".tcs__st").textContent = bun ? "✓" : "✗";
      r.querySelector(".tcs__e").innerHTML = bun ? (x.e || "") : `Tipul e <code>${esc(x.t)}</code>. ${x.e || ""}`;
    });
    const sc = gazda.querySelector(".tcs__scor");
    if (goale){ sc.textContent = `Mai ai ${goale} ${goale === 1 ? "rând gol" : "rânduri goale"}.`; return; }
    sc.innerHTML = `<b>${ok} din ${VARS.length}</b>${ok === VARS.length ? " · toate corecte" : " · citește explicațiile de sub rândurile roșii"}`;
    if (!verificat && d.id){
      verificat = true;
      await poarta(gazda, d.id, `${ok}/${VARS.length} consola:${cons.folosiri()}`);
    }
  };
};


/* ===========================================================================
   ACCES — drumul până la o valoare, construit cu clicul sau scris

   Trei feluri de a privi aceleași date:
     memorie   listele ca șir de căsuțe cu poziții (și pozițiile negative),
               dicționarele ca etichete cheie → valoare;
     coborare  vezi doar nivelul la care ai ajuns, ca niște cutii una în alta:
               intri într-o cutie și expresia crește cu un pas;
     arbore    tot răspunsul, cu fiecare rând apăsabil.
   Sub fiecare: expresia Python, „ce ai în mână” la fiecare pas (tipul și
   mărimea), Out ca în Jupyter, o consolă, și câteva ținte de găsit.
   =========================================================================== */
V.acces = (gazda, d) => {
  const ENV = d.env || {};
  const RAD = d.radacini || Object.keys(ENV);
  const VED = d.vedere || "arbore";
  const JSN = d.limbaj === "json";
  const PROV = d.provocari || [];
  const gasite = new Set();
  let cale = { rad: d.start || RAD[0], pasi: [] };

  const fmtCale = c => c.rad + c.pasi.map(p => typeof p === "number" ? `[${p}]` : `["${p}"]`).join("");
  const laCale = c => c.pasi.reduce((v, p) => PY.indexeaza(v, p), ENV[c.rad]);
  const norm = c => { let v = ENV[c.rad]; const o = [c.rad];
    for (const p of c.pasi){ const a = PY.T(v) === "tuple" ? v.__t : v;
      o.push(typeof p === "number" && p < 0 && Array.isArray(a) ? a.length + p : p); v = PY.indexeaza(v, p); }
    return JSON.stringify(o); };
  const marime = v => { const t = PY.T(v);
    if (t === "list") return `${v.length} ${v.length === 1 ? "element" : "elemente"}`;
    if (t === "tuple") return `${v.__t.length} elemente`;
    if (t === "dict") { const n = Object.keys(v).length; return `${n} ${n === 1 ? "cheie" : "chei"}`; }
    if (t === "str") return `${v.length} caractere`;
    return ""; };
  const NUME_T = { dict: "un dicționar", list: "o listă", tuple: "un tuplu", str: "un text (str)",
    int: "un număr întreg", float: "un număr cu zecimale", bool: "o valoare logică", NoneType: "None, nicio valoare" };
  const CE_FACI = { dict: "Ceri o <b>cheie</b>, între ghilimele: <code>[\"nume\"]</code>.",
    list: "Ceri o <b>poziție</b>, numărată de la 0: <code>[0]</code>, <code>[1]</code>… sau de la coadă: <code>[-1]</code>.",
    tuple: "Ceri o <b>poziție</b>, ca la listă." };
  const scurt = (v, n = 34) => { const r = PY.repr(v); return r.length > n ? r.slice(0, n - 1) + "…" : r; };
  const jsonVal = v => { const t = PY.T(v);
    if (t === "NoneType") return "null"; if (t === "bool") return v ? "true" : "false";
    if (t === "str") return JSON.stringify(v); if (t === "float") return String(v.__f ?? v); return String(v); };
  const cheie = k => JSN ? `"${esc(k)}"` : `'${esc(k)}'`;

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="acs acs--${VED}">
      ${PROV.length ? `<div class="acs__tinte"><span class="acs__tet">Găsește</span>${PROV.map((x, k) =>
        `<button class="acs__tinta" data-k="${k}" type="button"><i></i>${x.t}</button>`).join("")}</div>` : ""}
      <div class="acs__scena"></div>
      <div class="acs__expr"><span class="acs__eet">expresia</span><code class="acs__ec"></code></div>
      <div class="acs__mana"></div>
      <div class="acs__out"></div>
      ${d.consola !== false ? `<details class="acs__cons"${d.consolaDeschisa ? " open" : ""}><summary>Sau scrie tu expresia, în consolă</summary><div class="jc"></div></details>` : ""}
    </div>`;

  const $ = q => gazda.querySelector(q);
  const scena = $(".acs__scena");

  /* ---------- memorie: căsuțe pentru liste, etichete pentru dicționare ---- */
  function deseneazaMemorie(){
    scena.innerHTML = RAD.map(r => {
      const v = ENV[r], t = PY.T(v);
      if (t === "list" || t === "tuple"){
        const a = t === "tuple" ? v.__t : v;
        return `<div class="mem"><div class="mem__n"><code>${esc(r)}</code><span>${t}</span></div>
          <div class="mem__lista">${a.map((x, i) => `<div class="mem__cel">
            <button class="mem__i" data-c='${esc(JSON.stringify({ rad: r, pasi: [i] }))}' type="button">${i}</button>
            <button class="mem__v" data-c='${esc(JSON.stringify({ rad: r, pasi: [i] }))}' type="button">${esc(PY.repr(x))}</button>
            <button class="mem__i mem__i--neg" data-c='${esc(JSON.stringify({ rad: r, pasi: [i - a.length] }))}' type="button">${i - a.length}</button>
          </div>`).join("")}</div></div>`;
      }
      if (t === "dict"){
        return `<div class="mem"><div class="mem__n"><code>${esc(r)}</code><span>dict</span></div>
          <div class="mem__dict">${Object.entries(v).map(([k, x]) => `<button class="mem__pereche" data-c='${esc(JSON.stringify({ rad: r, pasi: [k] }))}' type="button">
            <span class="mem__k">${cheie(k)}</span><span class="mem__sag">→</span><span class="mem__dv">${esc(scurt(x, 26))}</span></button>`).join("")}</div></div>`;
      }
      return `<div class="mem"><button class="mem__simplu" data-c='${esc(JSON.stringify({ rad: r, pasi: [] }))}' type="button"><code>${esc(r)}</code> = ${esc(PY.repr(v))}</button></div>`;
    }).join("");
  }

  /* ---------- arbore: tot răspunsul, fiecare rând apăsabil --------------- */
  function nod(v, c, ind, eticheta){
    const t = PY.T(v), dc = esc(JSON.stringify(c));
    const pad = `style="--ind:${ind}"`;
    const et = eticheta ? `<span class="arb__k">${eticheta}</span><span class="arb__p">: </span>` : "";
    if (t === "dict" || t === "list" || t === "tuple"){
      const des = t === "dict" ? "{" : t === "list" ? "[" : "(", inc = t === "dict" ? "}" : t === "list" ? "]" : ")";
      const copii = t === "dict" ? Object.entries(v).map(([k, x]) => nod(x, { rad: c.rad, pasi: [...c.pasi, k] }, ind + 1, cheie(k)))
        : (t === "tuple" ? v.__t : v).map((x, i) => nod(x, { rad: c.rad, pasi: [...c.pasi, i] }, ind + 1, `<span class="arb__idx">${i}</span>`));
      return `<div class="arb__r arb__r--des" data-c='${dc}' ${pad}>${et}<span class="arb__b">${des}</span><span class="arb__m">${marime(v)}</span></div>
        ${copii.join("")}<div class="arb__r arb__r--inc" ${pad}><span class="arb__b">${inc}</span></div>`;
    }
    return `<div class="arb__r" data-c='${dc}' ${pad}>${et}<span class="arb__v arb__v--${t}">${esc(JSN ? jsonVal(v) : PY.repr(v))}</span></div>`;
  }
  function deseneazaArbore(){
    scena.innerHTML = `<div class="arb">${RAD.map(r => `<div class="arb__rad"><code>${esc(r)}</code> =</div>` + nod(ENV[r], { rad: r, pasi: [] }, 0, "")).join("")}</div>`;
  }

  /* ---------- coborâre: doar nivelul curent, ca niște cutii -------------- */
  function deseneazaCoborare(){
    let v; try { v = laCale(cale); } catch { cale = { rad: cale.rad, pasi: [] }; v = ENV[cale.rad]; }
    const t = PY.T(v);
    let corp;
    if (t === "dict" || t === "list" || t === "tuple"){
      const intrari = t === "dict" ? Object.entries(v) : (t === "tuple" ? v.__t : v).map((x, i) => [i, x]);
      corp = `<div class="cob__cutii cob__cutii--${t}">${intrari.map(([k, x]) => {
        const tx = PY.T(x), dc = esc(JSON.stringify({ rad: cale.rad, pasi: [...cale.pasi, k] }));
        return `<button class="cob__cut cob__cut--${tx === "dict" || tx === "list" ? "cont" : "frunza"}" data-c='${dc}' type="button">
          <span class="cob__acc">${typeof k === "number" ? `[${k}]` : `["${esc(k)}"]`}</span>
          <span class="cob__tip">${tx}${marime(x) ? ` · ${marime(x)}` : ""}</span>
          <span class="cob__prev">${esc(scurt(x, 40))}</span>
        </button>`; }).join("")}</div>`;
    } else {
      corp = `<div class="cob__frunza"><span class="cob__tip">${t}</span><b>${esc(PY.repr(v))}</b><span>Ai ajuns la o valoare. Mai jos nu se mai poate coborî.</span></div>`;
    }
    const sus = cale.pasi.length ? `<button class="cob__sus" type="button">↑ un nivel mai sus</button>` : "";
    scena.innerHTML = `<div class="cob__cadru" style="--niv:${cale.pasi.length}">
      <div class="cob__cap"><span class="cob__niv">nivelul ${cale.pasi.length}</span>${sus}</div>${corp}</div>`;
    scena.querySelector(".cob__sus")?.addEventListener("click", () => { cale = { rad: cale.rad, pasi: cale.pasi.slice(0, -1) }; arata(); });
  }

  const deseneaza = { memorie: deseneazaMemorie, arbore: deseneazaArbore, coborare: deseneazaCoborare }[VED];

  function arata(){
    if (VED === "coborare") deseneaza();
    /* evidențierea în scenă */
    const tinta = JSON.stringify(cale);
    scena.querySelectorAll("[data-c]").forEach(e => {
      const c = JSON.parse(e.dataset.c);
      const egal = e.dataset.c === tinta;
      const stramos = c.rad === cale.rad && c.pasi.length < cale.pasi.length &&
        c.pasi.every((p, i) => p === cale.pasi[i]);
      e.classList.toggle("on", egal); e.classList.toggle("drum", stramos);
    });
    /* expresia, colorată pe pași */
    $(".acs__ec").innerHTML = `<span class="ex__r">${esc(cale.rad)}</span>` + cale.pasi.map(p =>
      typeof p === "number" ? `<span class="ex__i">[${p}]</span>` : `<span class="ex__k">["${esc(p)}"]</span>`).join("");
    /* ce ai în mână, la fiecare pas */
    let v = ENV[cale.rad]; const lant = [{ acc: cale.rad, v }];
    let er = null;
    for (const p of cale.pasi){ try { v = PY.indexeaza(v, p); lant.push({ acc: typeof p === "number" ? `[${p}]` : `["${p}"]`, v, p }); }
      catch (e){ er = e; break; } }
    $(".acs__mana").innerHTML = `<span class="acs__met">ce ai în mână</span><div class="acs__lant">${lant.map((x, i) => {
      const t = PY.T(x.v);
      return `${i ? `<span class="acs__sag">→</span>` : ""}<button class="acs__za" data-i="${i}" type="button">
        <code>${esc(x.acc)}</code><span class="acs__zt acs__zt--${t}">${t}</span><span class="acs__zm">${marime(x.v)}</span></button>`; }).join("")}</div>
      <p class="acs__sfat">${er ? "" : (() => { const t = PY.T(v);
        return `Acum ai ${NUME_T[t] || t}. ${CE_FACI[t] || "Asta e o valoare: drumul s-a terminat aici."}`; })()}</p>`;
    $(".acs__out").innerHTML = er
      ? `<pre class="jc__err"><b>${esc(er.tip)}</b>: ${esc(er.message)}</pre>`
      : `<span class="jc__out">Out:</span><code>${esc((t => t.length > 170 ? t.slice(0, 169) + " …" : t)(PY.afis(v)))}</code>`;
    /* în arbore, rândul ales rămâne la vedere */
    if (VED === "arbore"){
      const box = scena.querySelector(".arb"), on = scena.querySelector(".arb__r.on");
      if (box && on && (on.offsetTop < box.scrollTop || on.offsetTop > box.scrollTop + box.clientHeight - 30))
        box.scrollTop = Math.max(0, on.offsetTop - 80);
    }
    /* ținte */
    PROV.forEach((x, k) => {
      if (gasite.has(k)) return;
      try { const c = PY.drum(x.cale);
        if (c && c.rad === cale.rad && (x.exact ? fmtCale(c) === fmtCale(cale) : norm(c) === norm(cale))) gasite.add(k); } catch {}
    });
    gazda.querySelectorAll(".acs__tinta").forEach((b, k) => b.classList.toggle("gata", gasite.has(k)));
  }

  scena.addEventListener("click", ev => {
    const e = ev.target.closest("[data-c]"); if (!e) return;
    cale = JSON.parse(e.dataset.c); arata();
  });
  $(".acs__mana").addEventListener("click", ev => {
    const b = ev.target.closest(".acs__za"); if (!b) return;
    cale = { rad: cale.rad, pasi: cale.pasi.slice(0, +b.dataset.i) }; arata();
  });
  gazda.querySelectorAll(".acs__tinta").forEach(b => b.addEventListener("click", () => {
    const x = PROV[+b.dataset.k];
    b.classList.add("ales"); setTimeout(() => b.classList.remove("ales"), 600);
    if (x.indiciu) $(".acs__mana .acs__sfat").innerHTML = `<b>Indiciu:</b> ${x.indiciu}`;
  }));
  if (d.consola !== false){
    consolaJupyter($(".jc"), ENV, { start: 1, loc: d.exemplu || `${RAD[0]}[0]`, laRulare: (src, rez) => {
      const c = PY.drum(src);
      if (c && c.rad in ENV){ try { c.pasi.reduce((v, p) => PY.indexeaza(v, p), ENV[c.rad]); cale = c; arata(); } catch {} }
    }});
  }
  if (VED !== "coborare") deseneaza();
  arata();
};


/* ===========================================================================
   GEOM — geometriile din Simple Features, desenate, cu fișa fiecăreia

   Arborele cu liniuțe arăta ierarhia, dar nu forma. Aici fiecare tip e
   desenat cum arată pe hartă, grupat după dimensiune (0 puncte, 1 linii,
   2 suprafețe), iar la clic primești fișa tehnică: definiția, WKT-ul, cum
   îl scrii în Shapely și PostGIS, regulile de validitate și ce facem noi cu
   el în proiect.
   =========================================================================== */
V.geom = (gazda, d) => {
  const G = d.geometrii || [];
  const I = {
    point: `<circle cx="40" cy="28" r="5"/>`,
    multipoint: `<circle cx="20" cy="18" r="4.5"/><circle cx="46" cy="36" r="4.5"/><circle cx="62" cy="16" r="4.5"/>`,
    linestring: `<polyline points="8,44 26,20 44,34 72,10" fill="none" class="g__l"/><circle cx="8" cy="44" r="3"/><circle cx="26" cy="20" r="3"/><circle cx="44" cy="34" r="3"/><circle cx="72" cy="10" r="3"/>`,
    multilinestring: `<polyline points="6,40 24,22 38,30" fill="none" class="g__l"/><polyline points="46,46 60,24 76,30" fill="none" class="g__l"/>`,
    polygon: `<path d="M10,46 L18,10 L52,6 L72,30 L54,50 Z M30,22 L44,20 L46,34 L32,36 Z" fill-rule="evenodd" class="g__s"/>`,
    multipolygon: `<path d="M6,40 L14,12 L38,10 L42,38 Z" class="g__s"/><path d="M50,22 L66,14 L76,30 L62,46 L50,40 Z" class="g__s"/><path d="M58,6 L66,4 L68,10 L60,12 Z" class="g__s"/>`,
    collection: `<circle cx="14" cy="16" r="4.5"/><polyline points="8,46 24,30 36,40" fill="none" class="g__l"/><path d="M46,12 L72,10 L70,40 L48,36 Z" class="g__s"/>`,
  };
  const DIM = ["0 · puncte", "1 · linii", "2 · suprafețe", "amestec"];
  let ales = d.start ?? G.findIndex(g => g.k === "polygon");

  gazda.innerHTML = `
    ${d.sarcina ? `<p class="ix__sarcina">${d.sarcina}</p>` : ""}
    <div class="geo">
      <div class="geo__grila">${G.map((g, k) => `<button class="geo__c geo__c--d${g.dim}" data-k="${k}" type="button">
        <svg viewBox="0 0 80 56" aria-hidden="true">${I[g.k] || ""}</svg>
        <span class="geo__n">${esc(g.n).replace(/^(Multi|Geometry)(?=[A-Z])/, "$1<wbr>")}</span><span class="geo__et">${esc(g.et)}</span>
      </button>`).join("")}</div>
      <div class="geo__fisa" aria-live="polite"></div>
    </div>`;

  const fisa = gazda.querySelector(".geo__fisa");
  function arata(k){
    ales = k; const g = G[k]; if (!g) return;
    gazda.querySelectorAll(".geo__c").forEach((b, j) => b.classList.toggle("on", j === k));
    const rand = (et, v, cod) => v ? `<div class="geo__r"><span class="geo__re">${et}</span>${cod ? `<code>${esc(v)}</code>` : `<p>${v}</p>`}</div>` : "";
    fisa.className = `geo__fisa geo__fisa--d${g.dim}`;
    fisa.innerHTML = `
      <div class="geo__fc">
        <svg viewBox="0 0 80 56" aria-hidden="true">${I[g.k] || ""}</svg>
        <div><h5>${esc(g.n)} <small>${esc(g.et)}</small></h5>
          <span class="geo__dim">dimensiune ${DIM[g.dim] ?? ""}</span></div>
      </div>
      <p class="geo__def">${g.def || ""}</p>
      <div class="geo__rs">
        ${rand("WKT", g.wkt, true)}
        ${rand("Python", g.py, true)}
        ${rand("PostGIS", g.pg, true)}
        ${rand("E validă dacă", g.valid)}
        ${rand("La noi", g.la)}
      </div>`;
  }
  gazda.querySelector(".geo__grila").addEventListener("click", ev => {
    const b = ev.target.closest(".geo__c"); if (b) arata(+b.dataset.k);
  });
  arata(ales < 0 ? 0 : ales);
};


/* ===========================================================================
   MASCA — cum păstrează pandas doar rândurile care te interesează

   Trei pași, fiecare cu bucata lui de cod aprinsă: alegi coloana, o compari
   (iese o coloană de True și False), apoi tabelul păstrează doar rândurile
   True. Rândurile sunt adevărate, din country.csv.
   =========================================================================== */
V.masca = (gazda, d) => {
  const R = d.randuri || [], C = d.coloane || [], col = d.coloana, val = d.valoare;
  const ki = C.indexOf(col);
  let pas = 0;
  const PASI = [
    { cod: `d`, txt: `Tabelul întreg. Aici, ${R.length} rânduri din cele ${d.total || "?"}.` },
    { cod: `d["${col}"]`, txt: `<code>d["${col}"]</code> alege o singură coloană: e o serie, cu o valoare pe fiecare rând.` },
    { cod: `d["${col}"] == "${val}"`, txt: `<code>==</code> compară <b>fiecare rând</b> cu <code>"${val}"</code>. Rezultatul e tot o coloană, de <code>True</code> și <code>False</code>: o mască.` },
    { cod: `d[d["${col}"] == "${val}"]`, txt: `Pusă între parantezele tabelului, masca păstrează doar rândurile <code>True</code>. Din tot fișierul rămân ${d.ramase || "?"} de rânduri.` },
  ];
  gazda.innerHTML = `
    <div class="msk">
      <div class="msk__cod"><code></code></div>
      <div class="msk__tab"><table>
        <thead><tr>${C.map((c, j) => `<th class="${j === ki ? "msk__k" : ""}">${esc(c)}</th>`).join("")}<th class="msk__m">== "${esc(val)}"</th></tr></thead>
        <tbody>${R.map(r => `<tr class="${r[ki] === val ? "da" : "nu"}">${r.map((x, j) => `<td class="${j === ki ? "msk__k" : ""}">${esc(x)}</td>`).join("")}
          <td class="msk__m">${r[ki] === val ? "True" : "False"}</td></tr>`).join("")}</tbody></table></div>
      <p class="msk__txt"></p>
      <div class="msk__nav">
        <button class="btn btn--mic" data-rol="inapoi" type="button">Înapoi</button>
        <span class="msk__pct">${PASI.map((_, k) => `<i data-k="${k}"></i>`).join("")}</span>
        <button class="btn btn--mic btn--tare" data-rol="inainte" type="button">Pasul următor</button>
      </div>
    </div>`;
  const $ = q => gazda.querySelector(q);
  function arata(){
    const m = $(".msk"); m.dataset.pas = pas;
    $(".msk__cod code").textContent = PASI[pas].cod;
    $(".msk__txt").innerHTML = PASI[pas].txt;
    gazda.querySelectorAll(".msk__pct i").forEach((e, k) => e.classList.toggle("on", k <= pas));
    $('[data-rol="inapoi"]').disabled = pas === 0;
    $('[data-rol="inainte"]').textContent = pas === PASI.length - 1 ? "De la capăt" : "Pasul următor";
  }
  $('[data-rol="inainte"]').onclick = () => { pas = pas === PASI.length - 1 ? 0 : pas + 1; arata(); };
  $('[data-rol="inapoi"]').onclick = () => { pas = Math.max(0, pas - 1); arata(); };
  arata();
};


/* ===========================================================================
   FOLDER — cum arată proiectul pe disc, și ce stă în fiecare dosar

   Lucrezi în folderul proiectului. Mediul virtual stă în el, în .venv, dar
   tu nu scrii acolo nimic. La clic pe fiecare dosar: ce pui în el, cine
   scrie acolo, și dacă urcă pe GitHub.
   =========================================================================== */
V.folder = (gazda, d) => {
  const N = d.noduri || [];
  let ales = d.start ?? 0;
  gazda.innerHTML = `
    <div class="fld">
      <div class="fld__arb">${N.map((x, k) => `<button class="fld__n fld__n--${x.fel || "dir"}${x.interzis ? " fld__n--x" : ""}" data-k="${k}" style="--ind:${x.ind || 0}" type="button">
        <span class="fld__ic" aria-hidden="true">${x.fel === "fis" ? "▤" : "▸"}</span><code>${esc(x.n)}</code>${x.scurt ? `<span class="fld__sc">${esc(x.scurt)}</span>` : ""}
      </button>`).join("")}</div>
      <div class="fld__fisa" aria-live="polite"></div>
    </div>`;
  const fisa = gazda.querySelector(".fld__fisa");
  function arata(k){
    ales = k; const x = N[k];
    gazda.querySelectorAll(".fld__n").forEach((b, j) => b.classList.toggle("on", j === k));
    fisa.className = "fld__fisa" + (x.interzis ? " fld__fisa--x" : "");
    fisa.innerHTML = `<h5><code>${esc(x.n)}</code></h5><p>${x.d || ""}</p>
      <dl>${x.cine ? `<dt>Cine scrie aici</dt><dd>${x.cine}</dd>` : ""}
          ${x.ex ? `<dt>De exemplu</dt><dd>${x.ex}</dd>` : ""}
          ${x.git ? `<dt>Pe GitHub</dt><dd>${x.git}</dd>` : ""}</dl>`;
  }
  gazda.querySelector(".fld__arb").addEventListener("click", ev => {
    const b = ev.target.closest(".fld__n"); if (b) arata(+b.dataset.k);
  });
  arata(ales);
};


/* ===========================================================================
   DSW — schema „Data Science Workflow”, exact ca la curs

   Aceleași piese și aceleași legături ca în schema din prezentare: banda
   „Analiza datelor” peste primele patru etape, raportarea în dreapta, baza
   de date jos în stânga, „ML engineering” sub implementare și optimizare,
   „Data science” dedesubt, peste tot. Săgețile pline sunt drumul, cele
   punctate sunt întoarcerile. Culorile sunt ale paletei sitului.
   =========================================================================== */
V.dsw = (gazda, d) => {
  const E = d.etape || {};
  const ch = (x0, y0, x1, y1, n = 46) => { const m = (y0 + y1) / 2;
    return `M${x0},${y0} L${x1 - n},${y0} L${x1},${m} L${x1 - n},${y1} L${x0},${y1} L${x0 + n},${m} Z`; };
  const txt = (x, y, linii, cls = "") => `<text x="${x}" y="${y - (linii.length - 1) * 14}" class="dsw__tx ${cls}" text-anchor="middle">${
    linii.map((l, i) => `<tspan x="${x}" dy="${i ? 28 : 0}">${esc(l)}</tspan>`).join("")}</text>`;
  const etapa = (k, forma, cx, cy, linii, cls) => `<g class="dsw__e dsw__e--${k}" data-k="${k}" tabindex="0" role="button" aria-label="${esc((E[k] || {}).n || k)}">
      ${forma}${txt(cx, cy + 8, linii, cls)}</g>`;
  const banda = (x, y, w, h, t, cls) => `<g class="dsw__b ${cls}"><rect x="${x}" y="${y}" width="${w}" height="${h}"/>${txt(x + w / 2, y + h / 2 + 9, [t], "dsw__bt")}</g>`;
  const sag = (id, w = 5) => `<marker id="${id}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="${w}" markerHeight="${w}" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z"/></marker>`;

  gazda.innerHTML = `
    <div class="dsw">
      <svg viewBox="0 0 1720 800" role="img" aria-label="Schema fluxului de lucru în știința datelor">
        <defs>${sag("dsw-a", 3.4)}${sag("dsw-p", 3.6)}${sag("dsw-g", 2.3)}</defs>
        ${banda(5, 3, 890, 74, "ANALIZA DATELOR", "dsw__b--ad")}
        ${banda(1149, 612, 482, 74, "ML ENGINEERING", "dsw__b--ml")}
        ${banda(40, 713, 1591, 74, "DATA SCIENCE", "dsw__b--ds")}

        <!-- săgețile punctate: întoarcerile -->
        <path d="M525,352 C600,300 690,330 735,420" class="dsw__p" marker-start="url(#dsw-p)" marker-end="url(#dsw-p)"/>
        <path d="M795,268 C830,360 930,410 1030,425" class="dsw__p" marker-start="url(#dsw-p)" marker-end="url(#dsw-p)"/>
        <path d="M1060,422 C1200,340 1450,345 1565,425" class="dsw__p" marker-start="url(#dsw-p)" marker-end="url(#dsw-p)"/>
        <path d="M1325,425 C1350,370 1395,330 1425,298" class="dsw__p" marker-start="url(#dsw-p)" marker-end="url(#dsw-p)"/>
        <path d="M360,642 C540,700 900,705 1045,600" class="dsw__p" marker-start="url(#dsw-p)" marker-end="url(#dsw-p)"/>

        ${etapa("def", `<path d="${ch(7, 93, 260, 263)}"/>`, 140, 178, ["DEFINIREA", "PROBLEMEI"], "")}
        ${etapa("col", `<path d="${ch(225, 93, 478, 263)}"/>`, 360, 178, ["COLECTAREA", "DATELOR"], "")}
        ${etapa("cur", `<path d="${ch(440, 93, 693, 263)}"/>`, 575, 178, ["CURĂȚAREA", "DATELOR"], "")}
        ${etapa("eda", `<path d="${ch(653, 93, 932, 263)}"/>`, 800, 178, ["ANALIZA", "EXPLORATORIE", "(EDA)"], "")}
        ${etapa("rap", `<rect x="1253" y="63" width="357" height="235" rx="50"/>`, 1432, 180, ["RAPORTARE", "VIZUALIZARE"], "dsw__tx--inv")}
        ${etapa("db", `<rect x="148" y="358" width="405" height="282" rx="46"/>`, 350, 499, ["POPULAREA ȘI", "GESTIONAREA UNEI", "BAZE DE DATE"], "dsw__tx--inv")}
        ${etapa("fe", `<path d="${ch(657, 428, 927, 598)}"/>`, 800, 513, ["FEATURE", "ENGINEERING"], "")}
        ${etapa("mod", `<path d="${ch(890, 428, 1205, 598)}"/>`, 1055, 513, ["MODELARE", "(Statistică/ML)"], "")}
        ${etapa("imp", `<path d="${ch(1173, 428, 1470, 598)}"/>`, 1328, 513, ["IMPLEMENTAREA", "MODELULUI"], "")}
        ${etapa("opt", `<path d="${ch(1438, 428, 1705, 598)}"/>`, 1580, 513, ["OPTIMIZAREA", "MODELULUI"], "")}
        <!-- săgețile pline: drumul -->
        <line x1="935" y1="178" x2="1238" y2="178" class="dsw__s dsw__s--sub" marker-end="url(#dsw-a)"/>
        <line x1="350" y1="268" x2="350" y2="353" class="dsw__s dsw__s--dublu" marker-start="url(#dsw-a)" marker-end="url(#dsw-a)"/>
        <line x1="555" y1="268" x2="385" y2="355" class="dsw__s dsw__s--dublu" marker-start="url(#dsw-a)" marker-end="url(#dsw-a)"/>
        <line x1="792" y1="268" x2="792" y2="398" class="dsw__s dsw__s--gros" marker-end="url(#dsw-g)"/>
        <line x1="1040" y1="425" x2="1225" y2="290" class="dsw__s dsw__s--gros dsw__s--mod" marker-end="url(#dsw-g)"/>

      </svg>
      <div class="dsw__i" aria-live="polite"><p class="dsw__d">${d.intro || ""}</p></div>
    </div>`;

  const info = gazda.querySelector(".dsw__i");
  const alege = k => {
    const x = E[k]; if (!x) return;
    gazda.querySelectorAll(".dsw__e").forEach(g => g.classList.toggle("on", g.dataset.k === k));
    info.innerHTML = `<p class="dsw__d"><b>${esc(x.n)}</b>${x.unde ? `<span class="dsw__u">${esc(x.unde)}</span>` : ""} ${x.d || ""}</p>
      ${x.noi ? `<p class="dsw__noi">La noi: ${x.noi}</p>` : ""}`;
  };
  gazda.querySelector("svg").addEventListener("click", ev => { const g = ev.target.closest(".dsw__e"); if (g) alege(g.dataset.k); });
  gazda.querySelector("svg").addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " "){ const g = ev.target.closest(".dsw__e"); if (g){ ev.preventDefault(); alege(g.dataset.k); } } });
};


/* ===========================================================================
   PANTA — aceeași listă de țări, ordonată în trei feluri

   Stânga: câți români trăiesc acolo. Mijloc: câți români la 1.000 de
   locuitori ai țării. Dreapta: SCI. Liniile arată cum urcă sau coboară
   fiecare țară. Apeși pe o țară și i se aprinde drumul.
   =========================================================================== */
V.panta = (gazda, d) => {
  const R = d.randuri || [], COL = d.coloane || [];
  const W = 760, H = 30 + R.length * 30, X = [150, 380, 610];
  const loc = k => { const o = [...R].sort((a, b) => b[k] - a[k]); return Object.fromEntries(o.map((r, i) => [r.cod, i])); };
  const L = COL.map(c => loc(c.k));
  const y = i => 30 + i * 30;
  const fmt = (v, c) => c.fmt === "mie" ? v.toLocaleString("ro-RO", { maximumFractionDigits: 1 }) : Math.round(v).toLocaleString("ro-RO");
  const evid = new Set(d.evidentiate || []);
  let ales = d.start || null;
  gazda.innerHTML = `
    <div class="pt">
      <svg viewBox="0 0 ${W} ${H + 10}" role="img" aria-label="Țările ordonate după numărul de români, după români la mie și după SCI">
        ${COL.map((c, j) => `<text x="${X[j]}" y="14" text-anchor="middle" class="pt__h">${esc(c.t)}</text>`).join("")}
        ${R.map(r => {
          const sus = L[2][r.cod] < L[0][r.cod], jos = L[2][r.cod] > L[0][r.cod];
          return `<g class="pt__r${evid.has(r.cod) ? " ev" : ""} ${sus ? "sus" : jos ? "jos" : ""}" data-c="${r.cod}">
            <polyline points="${X.map((x, j) => `${x},${y(L[j][r.cod]) + 6}`).join(" ")}" class="pt__l"/>
            ${COL.map((c, j) => `<circle cx="${X[j]}" cy="${y(L[j][r.cod]) + 6}" r="4.5" class="pt__c"/>`).join("")}
            <text x="${X[0] - 12}" y="${y(L[0][r.cod]) + 10}" text-anchor="end" class="pt__n">${esc(r.nume)} <tspan class="pt__v">${fmt(r[COL[0].k], COL[0])}</tspan></text>
            <text x="${X[2] + 12}" y="${y(L[2][r.cod]) + 10}" class="pt__n">${esc(r.nume)}</text>
          </g>`; }).join("")}
      </svg>
      <p class="pt__i" aria-live="polite"></p>
    </div>`;
  const info = gazda.querySelector(".pt__i");
  function arata(cod){
    ales = cod;
    gazda.querySelectorAll(".pt__r").forEach(g => g.classList.toggle("on", g.dataset.c === cod));
    gazda.querySelector(".pt").classList.toggle("pt--ales", !!cod);
    const r = R.find(x => x.cod === cod);
    info.innerHTML = r ? `<b>${esc(r.nume)}</b>: ${COL.map((c, j) => `${esc(c.scurt || c.t)} ${fmt(r[c.k], c)} (locul ${L[j][cod] + 1})`).join(" · ")}${r.nota ? `. ${r.nota}` : ""}` : (d.intro || "");
  }
  gazda.querySelector("svg").addEventListener("click", ev => { const g = ev.target.closest(".pt__r"); arata(g ? (g.dataset.c === ales ? null : g.dataset.c) : null); });
  arata(ales);
};


/* ===========================================================================
   DIADIC — de la un tabel de locuri la un tabel de perechi

   Trei județe. În stânga, tabelul lor obișnuit: un rând pe județ. În mijloc,
   matricea SCI: fiecare căsuță e o pereche. În dreapta, aceeași matrice
   scrisă ca tabel lung: un rând pe pereche, cu populația „de unde” și „spre
   unde” lipite din tabelul din stânga. Apeși o căsuță și vezi de unde vine
   fiecare valoare din rând.
   =========================================================================== */
V.diadic = (gazda, d) => {
  const J = d.judete || [], M = d.matrice || [];
  const n = J.length, f = x => Math.round(x).toLocaleString("ro-RO");
  let a = 0, b = 1;
  gazda.innerHTML = `
    <div class="dd">
      <section class="dd__c"><h4>Un rând = un județ</h4>
        <table class="dd__t dd__mon"><thead><tr><th>județ</th><th>populație</th></tr></thead>
        <tbody>${J.map((x, i) => `<tr data-i="${i}"><td>${esc(x.nume)}</td><td>${f(x.pop)}</td></tr>`).join("")}</tbody></table>
        <p class="dd__n">${n} rânduri</p></section>
      <section class="dd__c"><h4>Matricea SCI: o căsuță = o pereche</h4>
        <table class="dd__t dd__mat"><thead><tr><th></th>${J.map(x => `<th>${esc(x.sigla)}</th>`).join("")}</tr></thead>
        <tbody>${J.map((x, i) => `<tr><th>${esc(x.sigla)}</th>${J.map((y, j) => `<td><button data-a="${i}" data-b="${j}" type="button">${f(M[i][j] / 1000)}</button></td>`).join("")}</tr>`).join("")}</tbody></table>
        <p class="dd__n">în mii; apasă o căsuță</p></section>
      <section class="dd__c dd__c--lat"><h4>Un rând = o pereche</h4>
        <table class="dd__t dd__lung"><thead><tr><th>de unde</th><th>spre unde</th><th>SCI</th><th>pop. de unde</th><th>pop. spre unde</th></tr></thead>
        <tbody>${J.flatMap((x, i) => J.map((y, j) => `<tr data-a="${i}" data-b="${j}"><td>${esc(x.sigla)}</td><td>${esc(y.sigla)}</td><td>${f(M[i][j] / 1000)}</td><td class="dd__pa">${f(x.pop)}</td><td class="dd__pb">${f(y.pop)}</td></tr>`)).join("")}</tbody></table>
        <p class="dd__n">${n} × ${n} = ${n * n} rânduri</p></section>
    </div>
    <p class="dd__i" aria-live="polite"></p>`;
  const info = gazda.querySelector(".dd__i");
  function arata(){
    gazda.querySelectorAll(".dd__mat button").forEach(e => e.classList.toggle("on", +e.dataset.a === a && +e.dataset.b === b));
    gazda.querySelectorAll(".dd__mat button").forEach(e => e.classList.toggle("sim", +e.dataset.a === b && +e.dataset.b === a && a !== b));
    gazda.querySelectorAll(".dd__lung tr[data-a]").forEach(e => e.classList.toggle("on", +e.dataset.a === a && +e.dataset.b === b));
    gazda.querySelectorAll(".dd__mon tr[data-i]").forEach(e => { const i = +e.dataset.i;
      e.classList.toggle("ea", i === a); e.classList.toggle("eb", i === b); });
    const A = J[a], B = J[b];
    info.innerHTML = a === b
      ? `<b>${esc(A.nume)} cu ${esc(A.nume)}</b>: și perechea unui loc cu el însuși e un rând. Prieteniile din interiorul județului.`
      : `<b>${esc(A.nume)} → ${esc(B.nume)}</b>: SCI-ul vine din matrice. Populația „de unde” se lipește din rândul ${esc(A.nume)}, cea „spre unde” din rândul ${esc(B.nume)}: <b>două îmbinări</b> cu același tabel. Căsuța cu contur punctat e perechea inversă: la SCI, aceeași valoare.`;
  }
  gazda.querySelector(".dd__mat").addEventListener("click", ev => { const e = ev.target.closest("button[data-a]"); if (!e) return; a = +e.dataset.a; b = +e.dataset.b; arata(); });
  arata();
};


/* ===========================================================================
   RO — harta României, colorată după o întrebare simplă

   Pentru fiecare județ: e mai legat de Cluj sau de București? Culoarea arată
   încotro, intensitatea de câte ori. Treci cu mouse-ul peste un județ.
   =========================================================================== */
V.ro = (gazda, d) => {
  const J = d.judete || [], A = d.a || "Cluj", B = d.b || "București";
  const max = Math.max(...J.filter(x => x.r).map(x => Math.abs(Math.log2(x.r))));
  const cul = x => { if (!x.r) return "var(--ro-c)"; const t = Math.min(1, Math.abs(Math.log2(x.r)) / max);
    const p = Math.round(18 + 72 * Math.sqrt(t)); return `color-mix(in srgb,var(${x.r > 1 ? "--ro-a" : "--ro-b"}) ${p}%,var(--panza))`; };
  const spreA = J.filter(x => x.r > 1).length, spreB = J.filter(x => x.r && x.r < 1).length;
  gazda.innerHTML = `
    <div class="ro">
      <svg viewBox="${d.vb}" role="img" aria-label="Județele României, după legătura cu ${esc(A)} sau ${esc(B)}">
        ${J.map(x => `<path d="${x.d}" data-c="${x.cod}" class="ro__j${x.r ? "" : " ro__j--ref"}" style="fill:${cul(x)}"><title>${esc(x.nume)}</title></path>`).join("")}
        ${J.filter(x => !x.r).map(x => `<text x="${x.cx}" y="${x.cy}" text-anchor="middle" class="ro__et">${esc(x.nume)}</text>`).join("")}
      </svg>
      <aside class="ro__p">
        <div class="ro__leg"><span><i style="background:var(--ro-a)"></i>mai legat de ${esc(A)}</span><span><i style="background:var(--ro-b)"></i>mai legat de ${esc(B)}</span></div>
        <p class="ro__nr"><b>${spreA}</b> județe spre ${esc(A)}, <b>${spreB}</b> spre ${esc(B)}</p>
        <p class="ro__i" aria-live="polite">${d.intro || ""}</p>
      </aside>
    </div>`;
  const info = gazda.querySelector(".ro__i");
  const arata = cod => { const x = J.find(j => j.cod === cod); if (!x) return;
    gazda.querySelectorAll(".ro__j").forEach(p => p.classList.toggle("on", p.dataset.c === cod));
    info.innerHTML = !x.r ? `<b>${esc(x.nume)}</b>: unul dintre cele două orașe comparate.`
      : `<b>${esc(x.nume)}</b>: de ${(x.r > 1 ? x.r : 1 / x.r).toLocaleString("ro-RO", { maximumFractionDigits: 1 })} ori mai legat de ${esc(x.r > 1 ? A : B)} decât de ${esc(x.r > 1 ? B : A)}.`; };
  const svg = gazda.querySelector("svg");
  svg.addEventListener("mouseover", ev => { const p = ev.target.closest(".ro__j"); if (p) arata(p.dataset.c); });
  svg.addEventListener("click", ev => { const p = ev.target.closest(".ro__j"); if (p) arata(p.dataset.c); });
};

export default V;
