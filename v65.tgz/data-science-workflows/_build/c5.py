# -*- coding: utf-8 -*-
"""
Lecția 5: Agregare și baze de date.

Urmează prezentarea Curs_5.pptx: felurile de a uni tabele în pandas (concat,
merge, tipurile de join, join pe index), baza de date Neon, și comparația
PostgreSQL / MySQL.

Ce am adăugat peste prezentare, și de ce:
  - un bloc în care se vede ce iese din fiecare fel de îmbinare, pe două
    tabele mici, pentru că `inner` și `left` se învață numărând rânduri, nu
    citind definiții;
  - capcanele merge-ului (chei care nu se potrivesc, rânduri care se
    înmulțesc), pentru că acolo se pierd datele în tăcere, nu la sintaxă;
  - unitatea de analiză, pentru că proiectul lor are nevoie de un răspuns
    explicit la întrebarea „ce e un rând în tabelul final”;
  - partea de SQL propriu-zis: fără un `select` scris cu mâna, baza de date
    rămâne un loc unde se pune ceva, nu o unealtă.

Rulare:  python _build/c5.py
"""

from comun import Lectie, ix, verif, tabel, nota, surse

L = Lectie(5, "c5-agregare-si-baze-de-date", "Agregare și baze de date",
           "Unirea tabelelor în pandas, tipurile de join, capcanele lor, "
           "unitatea de analiză, și mutarea datelor într-o bază Postgres.")
sl = L.sl


# --------------------------------------------------------------------------
# Tabelele mici pe care se învață îmbinările. Valorile sunt adevărate: SCI-ul
# României cu patru parteneri, și câți cetățeni români trăiesc în patru țări
# (Eurostat migr_pop1ctz, 2024). Cheia care lipsește din dreapta e MD:
# Moldova nu raportează la Eurostat, deci cel mai puternic partener al
# României dispare la un inner join. Problema e reală, nu de exercițiu.
# --------------------------------------------------------------------------

STANGA = {"nume": "sci", "randuri": [
    {"cod": "MD", "sci": 173794},
    {"cod": "AT", "sci": 124693},
    {"cod": "DE", "sci": 91228},
    {"cod": "HU", "sci": 85021},
]}

DREAPTA = {"nume": "romani", "randuri": [
    {"cod": "AT", "romani": 153427},
    {"cod": "DE", "romani": 776424},
    {"cod": "HU", "romani": 15740},
    {"cod": "IT", "romani": 1073196},
]}

EXPLIC = {
    "concat": "<b>Una sub alta.</b> Opt rânduri: nimic nu se potrivește cu "
              "nimic, fiindcă <code>concat</code> nici nu se uită la chei. "
              "Coloanele se reunesc, iar unde tabelul nu avea coloana aceea "
              "rămâne <code>NaN</code>. E ce vrei când lipești ani diferiți "
              "din aceeași sursă, nu când adaugi coloane.",
    "inner": "<b>Doar ce e în amândouă.</b> Trei rânduri: AT, DE, HU. Moldova "
             "a dispărut, adică cel mai puternic partener al României, doar "
             "pentru că nu raportează migrația. Nicio celulă goală și nicio "
             "urmă a ei. De asta <code>inner</code> e periculos ca implicit.",
    "left": "<b>Tot ce e în stânga.</b> Patru rânduri, câte avea tabelul "
            "<code>sci</code>. MD rămâne, cu <code>NaN</code> la români: nu "
            "știm, și se vede că nu știm. IT nu apare, fiindcă în stânga am pus "
            "doar patru parteneri. Ăsta e felul pe care îl vrei când stânga e "
            "tabelul tău de bază.",
    "right": "<b>Tot ce e în dreapta.</b> Oglinda lui <code>left</code>: "
             "acum IT rămâne cu <code>NaN</code> la SCI, iar MD dispare. "
             "Se folosește rar: de obicei schimbi ordinea tabelelor și "
             "scrii <code>left</code>, care se citește mai ușor.",
    "outer": "<b>Tot, de peste tot.</b> Cinci rânduri: cele trei comune, plus "
             "MD fără migrație, plus IT fără SCI. E felul cu care verifici: "
             "dacă <code>outer</code> dă mai multe rânduri decât "
             "<code>inner</code>, știi exact cât ai fi pierdut.",
}

DUBLE = {"nume": "an_pop", "randuri": [
    {"cod": "MD", "an": 2020, "pop": 2.6},
    {"cod": "MD", "an": 2021, "pop": 2.6},
    {"cod": "MD", "an": 2022, "pop": 2.5},
    {"cod": "DE", "an": 2020, "pop": 83.2},
]}


# ===========================================================================
#  1-2. Cursul
# ===========================================================================

AGENDA = [
    ("Unirea tabelelor", "azi", "Una sub alta, sau una lângă alta. Două operații "
                                "complet diferite, cu nume care seamănă."),
    ("Tipurile de join", "azi", "inner, left, right, outer. Care ce păstrează "
                                "și, mai ales, ce aruncă."),
    ("Capcanele", "azi", "Chei care nu se potrivesc și rânduri care se înmulțesc. "
                         "Aici se pierd datele."),
    ("Unitatea de analiză", "azi", "Ce e un rând în tabelul vostru final. "
                                   "Fără răspunsul ăsta, agregarea n-are formă."),
    ("Baza de date", "azi", "Când fișierul nu mai ajunge, și cum se pun datele "
                            "într-un Postgres pe Neon."),
]

# Pașii pentru lecția 5.
# Regiunile și perechile: data/analiza_c4/referinta_c2_20261013/nuts2 (SCI ianuarie 2026, Eurostat 2024).
# Migrația: Eurostat migr_pop1ctz, 2024. SCI între țări: data/country.csv.

PAS_MERGE = {
    "fisier": "04_curatarea.ipynb · 5. Perechile de regiuni",
    "intro": "Un rând e o pereche de regiuni. Vrem lângă el populația <b>ambelor</b> capete. Asta cere două îmbinări, nu una.",
    "cod": "perechi = sci[sci[\"regiune_1\"] < sci[\"regiune_2\"]]\n"
           "atribute = regiuni[[\"regiune\", \"populatie\"]]\n\n"
           "capat_1 = atribute.add_suffix(\"_1\")\n"
           "perechi = perechi.merge(capat_1, on=\"regiune_1\", how=\"left\")\n"
           "perechi = perechi.merge(atribute.add_suffix(\"_2\"), on=\"regiune_2\", how=\"left\")\n"
           "print(len(perechi))",
    "pasi": [
        {"l": 1, "set": {"perechi": {"t": "DataFrame", "v": {"cols": ["regiune_1", "regiune_2", "sci"],
            "rows": [["HU11", "RO11", 34160], ["RO11", "RO12", 308881], ["…", "…", "…"]],
            "nota": "44.253 de perechi, fiecare o singură dată"}}},
         "txt": "SCI are fiecare pereche de două ori: Budapesta–Nord-Vest și Nord-Vest–Budapesta. <code>&lt;</code> între coduri păstrează doar una dintre ele."},
        {"l": 2, "set": {"atribute": {"t": "DataFrame", "v": {"cols": ["regiune", "populatie"],
            "rows": [["HU11", 1686222], ["RO11", 2539784], ["RO12", 2288061], ["…", "…"]],
            "nota": "un rând pe regiune (în caiet: și densitatea, și PIB-ul)"}}},
         "txt": "Tabelul regiunilor are o coloană <code>regiune</code>. Perechile au două: <code>regiune_1</code> și <code>regiune_2</code>. Numele nu se potrivesc."},
        {"l": 4, "set": {"capat_1": {"t": "DataFrame", "v": {"cols": ["regiune_1", "populatie_1"],
            "rows": [["HU11", 1686222], ["RO11", 2539784], ["RO12", 2288061], ["…", "…"]]}}},
         "txt": "<code>add_suffix(\"_1\")</code> pune <code>_1</code> la toate coloanele, inclusiv la cheie. Acum cheia se cheamă ca în perechi."},
        {"l": 5, "set": {"perechi": {"t": "DataFrame", "v": {"cols": ["regiune_1", "regiune_2", "sci", "populatie_1"],
            "rows": [["HU11", "RO11", 34160, 1686222], ["RO11", "RO12", 308881, 2539784], ["…", "…", "…", "…"]]}}},
         "txt": "Prima îmbinare: fiecare pereche primește populația primului capăt. Budapesta pe primul rând, Nord-Vest pe al doilea."},
        {"l": 6, "set": {"perechi": {"t": "DataFrame", "v": {"cols": ["regiune_1", "regiune_2", "sci", "populatie_1", "populatie_2"],
            "rows": [["HU11", "RO11", 34160, 1686222, 2539784], ["RO11", "RO12", 308881, 2539784, 2288061], ["…", "…", "…", "…", "…"]]}}}, "sterge": ["capat_1", "atribute"],
         "txt": "A doua îmbinare, același tabel de atribute, alt sufix. Nord-Vest apare acum ca al doilea capăt pe primul rând și ca primul pe al doilea."},
        {"l": 7, "out": "44253",
         "txt": "Verificarea din exercițiul de mai jos: tot 44.253. Cheile din dreapta sunt unice, deci niciun rând nu s-a înmulțit."},
    ],
}

PAS_AGREG = {
    "fisier": "tabelul regiunilor din C4 · de la regiuni la țări",
    "intro": "Ai un rând pe regiune. Vrei un rând pe țară. Schimbi unitatea de analiză cu <code>groupby</code>.",
    "cod": "regiuni = pd.read_csv(DATE / \"c4\" / \"regiuni_nuts2.csv\")\n\n"
           "pe_tara = regiuni.groupby(\"tara\")[\"populatie\"].agg([\"size\", \"sum\"])\n"
           "pe_tara.loc[[\"RO\", \"HU\", \"IT\", \"DE\"]]\n\n"
           "print(pe_tara.loc[\"RO\", \"sum\"] - 19051804)",
    "pasi": [
        {"l": 1, "set": {"regiuni": {"t": "DataFrame", "v": {"cols": ["regiune", "tara", "populatie"],
            "rows": [["RO11", "RO", 2539784], ["RO12", "RO", 2288061], ["HU11", "HU", 1686222], ["…", "…", "…"]],
            "nota": "298 de regiuni NUTS 2"}}},
         "txt": "Unitatea de acum: regiunea. Coloana <code>tara</code> spune în ce grup intră fiecare."},
        {"l": 3, "set": {"pe_tara": {"t": "DataFrame", "v": {"cols": ["size", "sum"], "index": ["…", "DE", "…", "HU", "IT", "…", "RO", "…"],
            "rows": [["…", "…"], [38, 83456045], ["…", "…"], [8, 9584627], [21, 58971230], ["…", "…"], [8, 19067576], ["…", "…"]],
            "nota": "un rând pe țară, în ordine alfabetică"}}},
         "txt": "<code>groupby(\"tara\")</code> strânge regiunile fiecărei țări; <code>agg</code> aplică două funcții deodată: <code>size</code> le numără, <code>sum</code> le adună populația."},
        {"l": 4, "out": "      size         sum\ntara\nRO       8  19067576.0\nHU       8   9584627.0\nIT      21  58971230.0\nDE      38  83456045.0",
         "txt": "România are 8 regiuni, Germania 38. Țara a devenit unitatea, iar țara e acum index: de aceea <code>.loc</code> o găsește după cod."},
        {"l": 6, "out": "15772.0",
         "txt": "Suma regiunilor (Eurostat) față de Banca Mondială, din C2: diferă cu 15.772 de oameni. Două surse, momente și estimări diferite. În proiect folosești una singură, și scrii care."},
    ],
}

_MIGR = [["IT", "RO", 1073196], ["IT", "AL", 416229], ["DE", "RO", 776424], ["ES", "RO", 620463], ["…", "…", "…"]]

PAS_SQL = {
    "fisier": "baza/intrebari.sql",
    "memoria": "ce are baza în mână",
    "intro": "SQL se scrie începând cu <code>select</code>, dar baza nu-l execută în ordinea asta. Urmărește ordinea adevărată: rândurile sar.",
    "cod": "select m.geo, m.persoane, s.sci\n"
           "from migratie m\n"
           "join legaturi s on s.tara_1 = 'RO' and s.tara_2 = m.geo\n"
           "where m.citizen = 'RO'\n"
           "order by m.persoane desc\n"
           "limit 3;",
    "pasi": [
        {"l": 2, "set": {"rezultat": {"t": "DataFrame", "v": {"cols": ["geo", "citizen", "persoane"], "rows": _MIGR,
            "nota": "tot tabelul migratie"}}},
         "txt": "Întâi <code>from</code>: din ce tabel. <code>m</code> e o poreclă scurtă pentru <code>migratie</code>."},
        {"l": 3, "set": {"rezultat": {"t": "DataFrame", "v": {"cols": ["geo", "citizen", "persoane", "sci"],
            "rows": [["IT", "RO", 1073196, 69327], ["IT", "AL", 416229, 69327], ["DE", "RO", 776424, 91228], ["ES", "RO", 620463, 54179], ["…", "…", "…", "…"]],
            "nota": "fiecare rând a primit SCI-ul România–țara lui"}}},
         "txt": "<code>join ... on</code> e <code>merge</code>: lângă fiecare rând se pune SCI-ul dintre România și țara de rezidență. Albanezii din Italia primesc tot SCI-ul România–Italia: e o legătură între țări, nu între cetățenii lor."},
        {"l": 4, "set": {"rezultat": {"t": "DataFrame", "v": {"cols": ["geo", "citizen", "persoane", "sci"],
            "rows": [["IT", "RO", 1073196, 69327], ["DE", "RO", 776424, 91228], ["ES", "RO", 620463, 54179], ["FR", "RO", 161220, 18075], ["…", "…", "…", "…"]],
            "nota": "doar românii"}}},
         "txt": "<code>where</code> filtrează, ca <code>d[d[\"citizen\"] == \"RO\"]</code>. Albanezii au plecat."},
        {"l": 5, "txt": "<code>order by ... desc</code> sortează descrescător. Aici ordinea era deja bună; de obicei nu e."},
        {"l": 6, "set": {"rezultat": {"t": "DataFrame", "v": {"cols": ["geo", "citizen", "persoane", "sci"],
            "rows": [["IT", "RO", 1073196, 69327], ["DE", "RO", 776424, 91228], ["ES", "RO", 620463, 54179]],
            "nota": "primele trei"}}},
         "txt": "<code>limit</code> taie la final. Baza a parcurs oricum tot tabelul."},
        {"l": 1, "set": {"rezultat": {"t": "DataFrame", "v": {"cols": ["geo", "persoane", "sci"],
            "rows": [["IT", 1073196, 69327], ["DE", 776424, 91228], ["ES", 620463, 54179]]}}},
         "out": " geo | persoane |   sci\n-----+----------+-------\n IT  |  1073196 | 69327\n DE  |   776424 | 91228\n ES  |   620463 | 54179",
         "txt": "Abia la urmă <code>select</code> alege coloanele de arătat. Ordinea după migranți nu e ordinea după SCI: Germania e mai legată de România decât Italia."},
    ],
}


sl("s1", "Cursul", "Despre ce e ora de azi",
   "<h2>Agregare și baze de date</h2>"
   "<p class=\"cheie\">Ai mai multe tabele curate. Azi devin unul singur, "
   "și pleacă dintr-un folder într-un loc din care se poate întreba.</p>"
   + ix("agenda", "Ora de azi",
        {"static": True, "titlu": "Ora de azi",
         "etape": [{"nume": n, "unde": u, "text": d} for n, u, d in AGENDA]},
        "Prima jumătate e pandas, a doua e SQL.")
   + nota("Caietul de azi", "<code>04_curatarea_si_integrarea_datelor.ipynb</code>, secțiunile 4–5 și 8: tabelul lat al regiunilor, perechile și îmbinările. Partea de baze de date nu are caiet: se face pe site și în Neon.", True),
   manual=
   "<h2>Agregare și baze de date</h2>"
   "<p>Până acum fiecare sursă a stat în fișierul ei: SCI într-unul, "
   "migrația în altul, indicatorii de la Eurostat în al treilea. Funcționează "
   "cât timp te uiți la ele pe rând. În momentul în care vrei să spui ceva "
   "de forma „perechile de țări cu mulți migranți sunt și mai legate”, îți "
   "trebuie un singur tabel.</p>"
   "<p>Unirea tabelelor pare o operație tehnică și e, de fapt, o decizie de "
   "cercetare: ce păstrezi când o sursă n-are o țară pe care cealaltă o are. "
   "Fiecare fel de join e un răspuns diferit la întrebarea asta, iar "
   "răspunsul schimbă câte rânduri rămân în analiză.</p>"
   "<p>A doua jumătate mută rezultatul dintr-un CSV într-o bază de date "
   "Postgres. Nu pentru că e mai modern, ci pentru că din momentul în care "
   "lucrați mai mulți pe aceleași date, fișierul devine problema.</p>"
   + ix("agenda", "Ora de azi",
        {"static": True, "titlu": "Ora de azi",
         "etape": [{"nume": n, "unde": u, "text": d} for n, u, d in AGENDA]})
   + nota("Caietul de azi", "<code>04_curatarea_si_integrarea_datelor.ipynb</code>, secțiunile 4–5 și 8: tabelul lat al regiunilor, perechile și îmbinările. Partea de baze de date nu are caiet: se face pe site și în Neon.", True))


sl("s2", "Cursul", "De ce nu ajunge un fișier",
   "<h2>Momentul în care CSV-ul devine problema</h2>"
   "<p>Nu e despre mărime. E despre ce se întâmplă când nu mai ești singur.</p>"
   + tabel(["Ce faci", "Cu fișiere", "Cu o bază de date"],
           [["Doi oameni modifică în același timp",
             "~date_final_v2_ANA.csv", "o singură copie, amândoi scriu în ea"],
            ["Vrei doar țările din UE, în 2022",
             "citești tot și filtrezi în memorie", "~where ue and an = 2022"],
            ["Verifici că nu ai duplicate",
             "scrii cod de fiecare dată", "~primary key, baza refuză"],
            ["Zece tabele legate între ele",
             "zece fișiere și o convenție de nume", "~join, scris o dată"],
            ["Ai greșit și vrei înapoi",
             "speri că ai un backup", "o ramură, sau un punct de restaurare"]])
   + nota("ȚINE MINTE", "Un CSV e bun până la prima colaborare. Pragul nu e "
                        "numărul de rânduri, e numărul de oameni."),
   manual=
   "<h2>Momentul în care CSV-ul devine problema</h2>"
   "<p>Întrebarea „de la câte rânduri trebuie o bază de date” are un răspuns "
   "prost, pentru că mărimea e rareori motivul. Pandas duce fără probleme "
   "câteva milioane de rânduri pe un laptop obișnuit, iar datele voastre sunt "
   "mult sub atât.</p>"
   "<p>Motivele adevărate sunt altele: mai mulți oameni care scriu în același "
   "loc, reguli care trebuie să țină singure (o țară nu poate apărea de două "
   "ori în același an), și întrebări pe care nu vrei să le rescrii de fiecare "
   "dată în Python.</p>"
   + tabel(["Ce faci", "Cu fișiere", "Cu o bază de date"],
           [["Doi oameni modifică în același timp",
             "~date_final_v2_ANA.csv", "o singură copie, amândoi scriu în ea"],
            ["Vrei doar țările din UE, în 2022",
             "citești tot și filtrezi în memorie", "~where ue and an = 2022"],
            ["Verifici că nu ai duplicate",
             "scrii cod de fiecare dată", "~primary key, baza refuză"],
            ["Zece tabele legate între ele",
             "zece fișiere și o convenție de nume", "~join, scris o dată"],
            ["Ai greșit și vrei înapoi",
             "speri că ai un backup", "o ramură, sau un punct de restaurare"]])
   + nota("ȚINE MINTE", "Un CSV e bun până la prima colaborare. Pragul nu e "
                        "numărul de rânduri, e numărul de oameni."),
   dupa=verif("c5-v1", 1,
              "Echipa voastră are 40.000 de rânduri și trei oameni care "
              "lucrează pe ele. Ce argument e cel mai bun pentru o bază de date?",
              ["Că 40.000 de rânduri sunt prea multe pentru pandas",
               "Că trei oameni au nevoie de o singură copie, nu de trei",
               "Că bazele de date sunt mai rapide",
               "Că așa se face în industrie"],
              "Mărimea nu e problema. Trei oameni cu trei copii ale aceluiași "
              "fișier sunt."))


# ===========================================================================
#  3-9. Unirea tabelelor
# ===========================================================================

sl("s3", "Unirea tabelelor", "Două operații, nu una",
   "<h2>Una sub alta, sau una lângă alta</h2>"
   "<p>Amândouă se numesc, în vorbire, „am unit tabelele”. În cod sunt două "
   "funcții diferite, care răspund la întrebări diferite.</p>"
   + tabel(["", "Concatenare", "Merge / join"],
           [["Ce adaugă", "rânduri", "coloane"],
            ["Când", "aceleași coloane, surse diferite",
             "tabele diferite, cu o cheie comună"],
            ["Exemplu la voi", "2020, 2021, 2022, descărcate separat",
             "SCI plus migrație, pe cod de țară"],
            ["În cod", "~pd.concat([a, b])", "~pd.merge(a, b, on=\"cod\")"],
            ["Ce poate strica", "coloane cu nume ușor diferite",
             "chei care nu se potrivesc"]])
   + nota("ÎNTREBAREA CARE LE SEPARĂ",
          "„Vreau mai multe rânduri sau mai multe coloane?” Dacă răspunsul e "
          "rânduri, e <code>concat</code>. Dacă e coloane, e <code>merge</code>."),
   manual=
   "<h2>Una sub alta, sau una lângă alta</h2>"
   "<p>Confuzia dintre cele două e cea mai frecventă greșeală la agregare, și "
   "e ușor de evitat dacă pui întrebarea în forma potrivită: vreau ca tabelul "
   "să crească în jos sau în lateral?</p>"
   "<p>Descarci datele Eurostat an cu an și vrei un singur tabel cu toți "
   "anii: cresc rândurile, deci <code>concat</code>. Ai tabelul cu SCI și vrei "
   "să-i adaugi populația fiecărei țări: cresc coloanele, deci "
   "<code>merge</code>.</p>"
   + tabel(["", "Concatenare", "Merge / join"],
           [["Ce adaugă", "rânduri", "coloane"],
            ["Când", "aceleași coloane, surse diferite",
             "tabele diferite, cu o cheie comună"],
            ["Exemplu la voi", "2020, 2021, 2022, descărcate separat",
             "SCI plus migrație, pe cod de țară"],
            ["În cod", "~pd.concat([a, b])", "~pd.merge(a, b, on=\"cod\")"],
            ["Ce poate strica", "coloane cu nume ușor diferite",
             "chei care nu se potrivesc"]])
   + nota("ÎNTREBAREA CARE LE SEPARĂ",
          "„Vreau mai multe rânduri sau mai multe coloane?” Dacă răspunsul e "
          "rânduri, e <code>concat</code>. Dacă e coloane, e <code>merge</code>."))


sl("s4", "Unirea tabelelor", "Ce iese din fiecare fel",
   "<h2>Numără rândurile</h2>"
   "<p>Două tabele mici, cu o cheie comună și câte una care nu se potrivește. "
   "Apasă pe fiecare fel de îmbinare și uită-te ce rămâne jos.</p>"
   + ix("imbinare", "Pe două tabele adevărate", {
       "id": "c5-imbinare-feluri", "intai": {"q": "În stânga: MD, AT, DE, HU. În dreapta: AT, DE, HU, IT. Câte rânduri dă un inner join?", "variante": ["4", "3", "5", "8"], "corect": 1, "dupa": "Inner păstrează doar cheile care sunt în amândouă: AT, DE, HU. Moldova și Italia cad, fără nicio eroare."}, "cheie": "cod",
       "stanga": STANGA, "dreapta": DREAPTA, "numeRez": "rezultat",
       "sarcina": "Încearcă-le pe toate cinci. Urmărește două lucruri: câte "
                  "rânduri ies, și unde apar celule goale.",
       "explicatii": EXPLIC})
   + nota("DE CE CONTEAZĂ",
          "Moldova nu e un detaliu de exercițiu: la datele noastre, "
          "<code>inner</code> scoate din analiză toate țările care nu "
          "raportează migrația, fără să scrie nicăieri că au dispărut."),
   manual=
   "<h2>Numără rândurile</h2>"
   "<p>Definițiile din documentație sunt corecte și inutile: se rețin cu "
   "greu și se confundă între ele. Felul în care se învață un join e să te "
   "uiți la două tabele mici și să numeri ce iese.</p>"
   "<p>Tabelele de mai jos au trei chei comune (AT, DE, HU), una doar în "
   "stânga (MD: Moldova nu raportează migrația la Eurostat) și una doar în "
   "dreapta (IT, pentru că în stânga am pus doar patru parteneri ai "
   "României).</p>"
   + ix("imbinare", "Pe două tabele adevărate", {
       "id": "c5-imbinare-feluri", "intai": {"q": "În stânga: MD, AT, DE, HU. În dreapta: AT, DE, HU, IT. Câte rânduri dă un inner join?", "variante": ["4", "3", "5", "8"], "corect": 1, "dupa": "Inner păstrează doar cheile care sunt în amândouă: AT, DE, HU. Moldova și Italia cad, fără nicio eroare."}, "cheie": "cod",
       "stanga": STANGA, "dreapta": DREAPTA, "numeRez": "rezultat",
       "sarcina": "Încearcă-le pe toate cinci.",
       "explicatii": EXPLIC})
   + nota("DE CE CONTEAZĂ",
          "Diferența dintre <code>inner</code> și <code>left</code> poate "
          "însemna douăzeci de țări care dispar din analiză fără să scrie "
          "nicăieri că au dispărut."))


sl("s5", "Unirea tabelelor", "Îmbinarea, în cod",
   "<h2>Scrie-o</h2>"
   + ix("pas", "Două capete, două îmbinări", PAS_MERGE)
   + ix("cod", "Lipește populația peste SCI", {
       "id": "c5-cod-merge", "indiciu": "Coloana după care lipești se dă cu parametrul on. Ca să păstrezi tot ce e în tabelul din stânga, felul e \"left\". Lipsurile rămase le găsești cu isna.",
       "iesire": "178 -> 178\n142", "fisier": "agregare/uneste.py",
       "sarcina": "Vrei să păstrezi toate țările din tabelul cu SCI, chiar "
                  "dacă n-au date de migrație.",
       "cod": "import pandas as pd\n\n"
              "sci = pd.read_csv(\"date/curat/sci.csv\")\n"
              "rom = pd.read_csv(\"date/curat/romani.csv\")\n\n"
              "# pastram tot ce e in sci, adaugam ce gasim in rom\n"
              "d = pd.merge(sci, rom, {{1}}=\"cod\", how={{2}})\n\n"
              "# verificare: numarul de randuri nu trebuie sa creasca\n"
              "print(len(sci), \"->\", len(d))\n\n"
              "# cate tari au ramas fara date de migratie\n"
              "print(d[\"romani\"].{{3}}().sum())",
       "goluri": {
           "1": {"ok": ["on"], "ajutor": "parametrul"},
           "2": {"ok": ["\"left\"", "'left'"], "ajutor": "felul, cu ghilimele"},
           "3": {"ok": ["isna", "isnull"], "ajutor": "metoda"}},
       "laBine": "Cele două linii de verificare de la final sunt partea pe "
                 "care o sare toată lumea și e singura care prinde greșelile.",
       "laRau": "Felul îmbinării se scrie ca text, între ghilimele. Ultima "
                "metodă întoarce True acolo unde lipsește ceva.",
       "explicatie": "<code>how=\"left\"</code> spune limpede cine e tabelul "
                     "de bază. Verificarea de după nu e paranoia: dacă "
                     "<code>len(d)</code> e mai mare decât <code>len(sci)</code>, "
                     "ai chei duplicate în dreapta și tocmai ți-ai înmulțit "
                     "rândurile — exact capcana de la slide-ul următor."}),
   manual=
   "<h2>Scrie-o</h2>"
   "<p>Sintaxa e scurtă; grija e la ce scrii după ea. Cele două linii de "
   "verificare de la final valorează mai mult decât îmbinarea în sine.</p>"
   + ix("pas", "Două capete, două îmbinări", PAS_MERGE)
   + ix("cod", "Lipește populația peste SCI", {
       "id": "c5-cod-merge", "indiciu": "Coloana după care lipești se dă cu parametrul on. Ca să păstrezi tot ce e în tabelul din stânga, felul e \"left\". Lipsurile rămase le găsești cu isna.",
       "iesire": "178 -> 178\n142", "fisier": "agregare/uneste.py",
       "sarcina": "Păstrezi toate țările din tabelul cu SCI.",
       "cod": "import pandas as pd\n\n"
              "sci = pd.read_csv(\"date/curat/sci.csv\")\n"
              "rom = pd.read_csv(\"date/curat/romani.csv\")\n\n"
              "d = pd.merge(sci, rom, {{1}}=\"cod\", how={{2}})\n\n"
              "print(len(sci), \"->\", len(d))\n"
              "print(d[\"romani\"].{{3}}().sum())",
       "goluri": {
           "1": {"ok": ["on"], "ajutor": "parametrul"},
           "2": {"ok": ["\"left\"", "'left'"], "ajutor": "felul"},
           "3": {"ok": ["isna", "isnull"], "ajutor": "metoda"}},
       "laBine": "Verificările de la final sunt partea importantă.",
       "laRau": "Felul îmbinării se scrie între ghilimele.",
       "explicatie": "Dacă <code>len(d)</code> e mai mare decât "
                     "<code>len(sci)</code>, ai chei duplicate în dreapta."}))


sl("s6", "Unirea tabelelor", "Când rândurile se înmulțesc",
   "<h2>Capcana care nu dă eroare</h2>"
   "<p>Același tabel <code>sci</code>, dar în dreapta populația e pe ani. "
   "Patru rânduri în stânga, patru în dreapta. Apasă <code>left</code>.</p>"
   + ix("imbinare", "Patru plus patru nu dau patru", {
       "id": "c5-imbinare-explozie", "intai": {"q": "În stânga sunt 4 țări. În dreapta, Moldova apare de trei ori (trei ani). Câte rânduri dă un left join?", "variante": ["4", "6", "12"], "corect": 1, "dupa": "Moldova din stânga se potrivește cu toate trei rândurile ei din dreapta: un rând devine trei. 4 − 1 + 3 = 6."}, "poarta": False, "cheie": "cod",
       "stanga": STANGA, "dreapta": DUBLE, "numeRez": "rezultat",
       "feluri": ["inner", "left"],
       "sarcina": "Numără rândurile care ies. Erau patru în stânga.",
       "explicatii": {
           "inner": "<b>Patru rânduri, din două chei.</b> Se potrivesc doar "
                    "MD și DE, dar MD apare de trei ori, fiindcă în dreapta "
                    "are trei ani. Valoarea SCI s-a copiat identic pe toate "
                    "trei. Dacă acum faci o medie pe SCI, MD cântărește de "
                    "trei ori cât DE.",
           "left": "<b>Șase rânduri, din patru.</b> MD de trei ori, DE o "
                   "dată, plus AT și HU cu goluri. Tabelul a crescut cu "
                   "cincizeci la sută fără să dea nicio eroare. Ăsta e tot "
                   "pericolul: codul merge, iar numerele de la final sunt "
                   "greșite."}})
   + nota("CUM TE APERI",
          "<code>pd.merge(..., validate=\"one_to_one\")</code> aruncă o eroare "
          "dacă cheia nu e unică. E o linie în plus care te scutește de o "
          "analiză refăcută."),
   dupa=verif("c5-v4", 2,
              "Vrei ca merge-ul să crape dacă o cheie apare de mai multe ori "
              "în dreapta. Ce adaugi?",
              ["how=\"inner\"",
               "on=[\"cod\", \"an\"]",
               "validate=\"one_to_one\"",
               "indicator=True"],
              "<code>validate</code> verifică relația dintre chei și aruncă "
              "eroare dacă nu e cea pe care ai promis-o. "
              "<code>indicator=True</code> e util și el, dar doar adaugă o "
              "coloană care spune de unde vine fiecare rând."),
   manual=
   "<h2>Capcana care nu dă eroare</h2>"
   "<p>Un join potrivește fiecare rând din stânga cu fiecare rând din dreapta "
   "care are aceeași cheie. Când cheia e unică de ambele părți, asta e ce "
   "aștepți. Când nu e, tabelul crește, iar valorile din stânga se copiază "
   "pe fiecare rând nou.</p>"
   "<p>Nu apare nicio eroare. Codul rulează, fișierul se scrie, iar mediile "
   "calculate după aceea sunt ponderate greșit, fiindcă unele țări apar de "
   "mai multe ori.</p>"
   + ix("imbinare", "Patru plus patru nu dau patru", {
       "id": "c5-imbinare-explozie", "intai": {"q": "În stânga sunt 4 țări. În dreapta, Moldova apare de trei ori (trei ani). Câte rânduri dă un left join?", "variante": ["4", "6", "12"], "corect": 1, "dupa": "Moldova din stânga se potrivește cu toate trei rândurile ei din dreapta: un rând devine trei. 4 − 1 + 3 = 6."}, "poarta": False, "cheie": "cod",
       "stanga": STANGA, "dreapta": DUBLE, "numeRez": "rezultat",
       "feluri": ["inner", "left"],
       "sarcina": "Numără rândurile care ies.",
       "explicatii": {
           "inner": "<b>Patru rânduri, din două chei.</b> MD apare de trei ori.",
           "left": "<b>Șase rânduri, din patru.</b> Tabelul a crescut fără "
                   "nicio eroare."}})
   + nota("CUM TE APERI",
          "<code>validate=\"one_to_one\"</code> aruncă o eroare dacă cheia nu "
          "e unică. Dacă vrei într-adevăr un rând pe țară și an, atunci cheia "
          "e <code>on=[\"cod\", \"an\"]</code>, nu doar codul."))


sl("s7", "Unirea tabelelor", "Când cheile nu se potrivesc",
   "<h2>Aceeași țară, trei scrieri</h2>"
   "<p>A doua capcană: cheile arată diferit, deci nu se potrivesc, deci "
   "<code>inner</code> întoarce un tabel gol și nimeni nu înțelege de ce.</p>"
   + tabel(["Sursă", "Cum scrie România", "Ce fel de cod"],
           [["Facebook SCI", "~RO", "ISO 3166-1 alpha-2"],
            ["Banca Mondială", "~ROU", "ISO 3166-1 alpha-3"],
            ["Eurostat", "~RO", "NUTS 0; dar Grecia e EL și Regatul Unit e UK"],
            ["Un fișier făcut de om", "~Romania, România, ROMANIA", "nimic"]])
   + ix("cod", "Fă-le să se potrivească", {
       "id": "c5-cod-chei", "indiciu": "Mai întâi lipești după aceeași coloană, deci on. Cheile comune sunt intersecția a două mulțimi: operatorul &. Când coloanele au nume diferite, dai left_on și right_on.",
       "iesire": "171 chei comune din 178", "fisier": "agregare/chei.py",
       "sarcina": "Banca Mondială dă coduri de trei litere, SCI dă două. "
                  "Aduci tabelul mare la cheia celui mic și verifici.",
       "cod": "# tabelul de traducere, adus o singura data\n"
              "harta = pd.read_csv(\"date/referinta/coduri.csv\")  # iso3, iso2\n\n"
              "# aducem codul de 3 litere la cel de 2\n"
              "bm = bm.merge(harta, {{1}}=\"iso3\", how=\"left\")\n\n"
              "# INAINTE de a imbina: cate chei chiar se potrivesc?\n"
              "comune = set(sci[\"cod\"]) {{2}} set(bm[\"iso2\"])\n"
              "print(len(comune), \"chei comune din\", len(set(sci[\"cod\"])))\n\n"
              "# abia acum\n"
              "d = sci.merge(bm, left_on=\"cod\", {{3}}=\"iso2\", how=\"left\")",
       "goluri": {
           "1": {"ok": ["on"], "ajutor": "parametrul"},
           "2": {"ok": ["&", "intersection"], "ajutor": "operatorul"},
           "3": {"ok": ["right_on"], "ajutor": "parametrul"}},
       "laBine": "Linia care numără cheile comune înainte de îmbinare e "
                 "obiceiul care te scutește de cele mai multe surprize.",
       "laRau": "Pentru intersecția a două mulțimi în Python e un singur "
                "caracter. Când coloanele-cheie au nume diferite, "
                "<code>on</code> se desface în două.",
       "explicatie": "Numărul tipărit de la mijloc e diagnosticul: dacă din "
                     "178 de chei se potrivesc 12, nu e o problemă de "
                     "<code>merge</code>, e o problemă de coduri, și se "
                     "repară înainte, nu după."}),
   manual=
   "<h2>Aceeași țară, trei scrieri</h2>"
   "<p>Fiecare sursă are nomenclatorul ei, iar codurile seamănă suficient cât "
   "să pară interschimbabile. Nu sunt.</p>"
   + tabel(["Sursă", "Cum scrie România", "Ce fel de cod"],
           [["Facebook SCI", "~RO", "ISO 3166-1 alpha-2"],
            ["Banca Mondială", "~ROU", "ISO 3166-1 alpha-3"],
            ["Eurostat", "~RO", "NUTS 0; dar Grecia e EL și Regatul Unit e UK"],
            ["Un fișier făcut de om", "~Romania, România, ROMANIA", "nimic"]])
   + "<p>Mai există o capcană care nu se vede cu ochiul: tipul. "
     "<code>2020</code> citit ca text nu se potrivește cu <code>2020</code> "
     "citit ca număr, iar <code>merge</code> nu te avertizează, pur și simplu "
     "nu găsește nimic.</p>"
   + ix("cod", "Fă-le să se potrivească", {
       "id": "c5-cod-chei", "indiciu": "Mai întâi lipești după aceeași coloană, deci on. Cheile comune sunt intersecția a două mulțimi: operatorul &. Când coloanele au nume diferite, dai left_on și right_on.",
       "iesire": "171 chei comune din 178", "fisier": "agregare/chei.py",
       "sarcina": "Aduci tabelul mare la cheia celui mic și verifici.",
       "cod": "harta = pd.read_csv(\"date/referinta/coduri.csv\")  # iso3, iso2\n"
              "bm = bm.merge(harta, {{1}}=\"iso3\", how=\"left\")\n\n"
              "comune = set(sci[\"cod\"]) {{2}} set(bm[\"iso2\"])\n"
              "print(len(comune), \"chei comune din\", len(set(sci[\"cod\"])))\n\n"
              "d = sci.merge(bm, left_on=\"cod\", {{3}}=\"iso2\", how=\"left\")",
       "goluri": {
           "1": {"ok": ["on"], "ajutor": "parametrul"},
           "2": {"ok": ["&", "intersection"], "ajutor": "operatorul"},
           "3": {"ok": ["right_on"], "ajutor": "parametrul"}},
       "laBine": "Numără cheile comune înainte de îmbinare.",
       "laRau": "Intersecția a două mulțimi e un singur caracter.",
       "explicatie": "Dacă din 178 de chei se potrivesc 12, e o problemă de "
                     "coduri, nu de <code>merge</code>."}))


sl("s8", "Unirea tabelelor", "Unitatea de analiză",
   "<h2>Ce e un rând în tabelul vostru</h2>"
   "<p>Înainte de orice îmbinare, răspunsul la întrebarea asta. După, e prea "
   "târziu: tabelul are deja o formă, și de obicei nu cea pe care o voiai.</p>"
   + ix("sortare", "Ce unitate cere fiecare întrebare", {
       "id": "c5-sort-unitate", "poarta": False,
       "sarcina": "Potrivește întrebarea de cercetare cu forma pe care "
                  "trebuie s-o aibă un rând.",
       "elemente": [
           {"t": "În ce țări trăiesc cei mai mulți români?", "cos": 0},
           {"t": "Care județe au cele mai multe legături în afara țării?", "cos": 1},
           {"t": "Perechile de țări cu mai mulți migranți sunt mai legate?", "cos": 2},
           {"t": "Județele din Moldova sunt legate de alte regiuni italiene decât cele din Ardeal?", "cos": 3}],
       "cosuri": [
           {"t": "o țară", "d": "un rând = o țară"},
           {"t": "o regiune", "d": "un rând = un județ sau o regiune"},
           {"t": "o pereche de țări", "d": "un rând = o legătură între țări"},
           {"t": "o pereche de regiuni", "d": "un rând = o legătură între regiuni"}],
       "laBine": "Datele SCI sunt diadice: unitatea naturală e perechea, nu "
                 "țara. Ca să ajungi la o unitate „țară”, trebuie să agregi "
                 "explicit, și atunci alegi cum: sumă, medie, maxim.",
       "explicatie": "Unitatea de analiză decide tot ce urmează: ce chei "
                     "folosești la îmbinare, ce verifici cu "
                     "<code>validate</code>, și ce înseamnă o medie. Scris în "
                     "<code>decizii.md</code>, e o propoziție. Nescris, e "
                     "sursa a jumătate din confuziile unui proiect."})
   + nota("LA PROIECTUL VOSTRU",
          "Scrieți undeva, într-o propoziție: „un rând în tabelul nostru final "
          "înseamnă ___”. Dacă echipa dă două răspunsuri diferite, ăsta e "
          "lucrul de rezolvat azi, înaintea codului."),
   manual=
   "<h2>Ce e un rând în tabelul vostru</h2>"
   "<p>Unitatea de analiză e nivelul la care observi: țara, perechea de țări, "
   "țara-an, individul, gospodăria. Pare o chestiune de vocabular, dar "
   "decide forma tabelului final și, prin ea, ce întrebări poți pune.</p>"
   "<p>Datele voastre pornesc de la o unitate diadică: SCI măsoară legătura "
   "<em>dintre</em> două locuri, deci un rând e o pereche. Dacă vreți să "
   "spuneți ceva despre o țară, trebuie să agregați perechile, și atunci "
   "alegerea funcției de agregare e o decizie teoretică: suma spune „cât de "
   "conectată e în total”, media spune „cât de conectată e în medie”, iar "
   "maximul spune „cât de tare e cea mai puternică legătură a ei”. Trei "
   "lucruri diferite.</p>"
   + ix("sortare", "Ce unitate cere fiecare întrebare", {
       "id": "c5-sort-unitate", "poarta": False,
       "sarcina": "Potrivește întrebarea cu forma unui rând.",
       "elemente": [
           {"t": "În ce țări trăiesc cei mai mulți români?", "cos": 0},
           {"t": "Care județe au cele mai multe legături în afara țării?", "cos": 1},
           {"t": "Perechile de țări cu mai mulți migranți sunt mai legate?", "cos": 2},
           {"t": "Județele din Moldova sunt legate de alte regiuni italiene decât cele din Ardeal?", "cos": 3}],
       "cosuri": [
           {"t": "o țară", "d": "un rând = o țară"},
           {"t": "o regiune", "d": "un rând = un județ sau o regiune"},
           {"t": "o pereche de țări", "d": "un rând = o legătură între țări"},
           {"t": "o pereche de regiuni", "d": "un rând = o legătură între regiuni"}],
       "laBine": "Datele SCI sunt diadice: unitatea naturală e perechea.",
       "explicatie": "Unitatea de analiză decide ce chei folosești la "
                     "îmbinare și ce înseamnă o medie."}))


sl("s9", "Unirea tabelelor", "Agregarea",
   "<h2>De la perechi la țări</h2>"
   + ix("prezice", "Ce face groupby", {
       "id": "c5-prezice-grup", "fisier": "agregare/proba.py",
       "cod": "import pandas as pd\n\n"
              "d = pd.DataFrame({\"tara\": [\"RO\", \"RO\", \"IT\"],\n"
              "                  \"sci\":  [10, 30, 5]})\n\n"
              "print(d.groupby(\"tara\")[\"sci\"].sum())",
       "intrebare": "Ce afișează?",
       "variante": ["tara\nIT     5\nRO    40", "tara\nRO    10\nRO    30\nIT     5",
                    "45", "tara\nRO    40\nIT     5"],
       "corect": 0,
       "indiciu": "groupby face câte un grup pentru fiecare valoare distinctă din tara; sum adună în fiecare grup. Și sortează grupurile după nume.",
       "laBine": "Din trei rânduri pe pereche, două rânduri pe țară.",
       "explicatie": "Rândurile cu aceeași țară se strâng într-un grup și se adună: RO = 10 + 30 = 40, IT = 5. "
                     "Grupurile ies în ordine alfabetică, de aceea IT e primul. Asta e schimbarea unității "
                     "de analiză, de la pereche la țară, din exercițiul de mai jos."})
   + ix("pas", "De la regiuni la țări", PAS_AGREG)
   + ix("cod", "Adu datele la unitatea pe care o vrei", {
       "id": "c5-cod-agregare", "indiciu": "Grupezi cu groupby, media se cere ca text, ca și \"sum\" de deasupra: \"mean\". La final, coloana de grupare redevine coloană cu reset_index.",
       "iesire": "(31684, 3)\n(178, 4)", "fisier": "agregare/agrega.py",
       "sarcina": "Ai un rând pe pereche. Vrei un rând pe țară, cu trei "
                  "măsuri diferite ale conectării.",
       "cod": "# un rand pe perechea (tara_sursa, tara_tinta)\n"
              "print(d.shape)\n\n"
              "t = (d\n"
              "     .{{1}}(\"tara_sursa\")\n"
              "     .agg(total=(\"sci\", \"sum\"),\n"
              "          medie=(\"sci\", {{2}}),\n"
              "          parteneri=(\"tara_tinta\", \"nunique\"))\n"
              "     .{{3}}())\n\n"
              "# acum un rand pe tara\n"
              "print(t.shape)",
       "goluri": {
           "1": {"ok": ["groupby"], "ajutor": "metoda"},
           "2": {"ok": ["\"mean\"", "'mean'"], "ajutor": "funcția, ca text"},
           "3": {"ok": ["reset_index"], "ajutor": "metoda"},
       },
       "laBine": "<code>reset_index()</code> de la final aduce cheia înapoi "
                 "ca o coloană obișnuită. Fără el, rămâne index, iar "
                 "<code>merge</code> de după n-o mai găsește.",
       "laRau": "Prima e metoda care grupează. A doua se scrie ca text, între "
                "ghilimele, ca și <code>\"sum\"</code> de deasupra.",
       "explicatie": "Cele trei măsuri nu sunt variante ale aceluiași lucru. "
                     "<code>total</code> favorizează țările cu mulți "
                     "parteneri, <code>medie</code> le pune pe toate pe picior "
                     "de egalitate, iar <code>parteneri</code> nu măsoară "
                     "deloc tăria, ci întinderea. Alegerea dintre ele e "
                     "teoretică, nu tehnică."}),
   manual=
   "<h2>De la perechi la țări</h2>"
   "<p>Agregarea e locul în care datele își schimbă unitatea. E și locul în "
   "care se iau, pe tăcute, decizii teoretice: ce funcție folosești ca să "
   "rezumi mai multe rânduri într-unul singur.</p>"
   + ix("pas", "De la regiuni la țări", PAS_AGREG)
   + ix("cod", "Adu datele la unitatea pe care o vrei", {
       "id": "c5-cod-agregare", "indiciu": "Grupezi cu groupby, media se cere ca text, ca și \"sum\" de deasupra: \"mean\". La final, coloana de grupare redevine coloană cu reset_index.",
       "iesire": "(31684, 3)\n(178, 4)", "fisier": "agregare/agrega.py",
       "sarcina": "De la un rând pe pereche, la un rând pe țară.",
       "cod": "print(d.shape)\n\n"
              "t = (d\n"
              "     .{{1}}(\"tara_sursa\")\n"
              "     .agg(total=(\"sci\", \"sum\"),\n"
              "          medie=(\"sci\", {{2}}),\n"
              "          parteneri=(\"tara_tinta\", \"nunique\"))\n"
              "     .{{3}}())\n\n"
              "print(t.shape)",
       "goluri": {
           "1": {"ok": ["groupby"], "ajutor": "metoda"},
           "2": {"ok": ["\"mean\"", "'mean'"], "ajutor": "funcția"},
           "3": {"ok": ["reset_index"], "ajutor": "metoda"}},
       "laBine": "<code>reset_index()</code> aduce cheia înapoi ca o coloană.",
       "laRau": "A doua se scrie ca text, între ghilimele.",
       "explicatie": "Suma favorizează țările cu mulți parteneri, media le "
                     "egalizează, numărul de parteneri măsoară întinderea, nu "
                     "tăria."}))


sl("s10", "Unirea tabelelor", "Join pe index",
   "<h2>Când cheia e chiar indexul</h2>"
   "<p><code>df1.join(df2)</code> e <code>merge</code> cu o singură "
   "presupunere: că te potrivești pe index, nu pe o coloană.</p>"
   + tabel(["Scrii", "Se potrivește pe", "Când e bun"],
           [["~a.merge(b, on=\"cod\")", "coloana cod, în amândouă",
             "cazul obișnuit"],
            ["~a.join(b)", "indexul amândurora", "după un groupby, sau la serii de timp"],
            ["~a.merge(b, left_on=\"cod\", right_index=True)",
             "coloană în stânga, index în dreapta", "amestecat"],
            ["~a.join(b, how=\"inner\")", "index, dar numai potrivirile",
             "join implicit e left, nu inner"]])
   + nota("DE REȚINUT",
          "<code>join</code> are <code>how=\"left\"</code> din oficiu, iar "
          "<code>merge</code> are <code>how=\"inner\"</code>. Două funcții "
          "care fac același lucru, cu implicit diferit: de aici vine o parte "
          "din confuzie."))


# ===========================================================================
#  11-18. Baze de date
# ===========================================================================

sl("s11", "Baze de date", "Ce e Neon",
   "<h2>Postgres, fără server de întreținut</h2>"
   "<p>Neon e PostgreSQL obișnuit, pus într-un loc în care nu trebuie să-l "
   "instalezi și nu trebuie să-l ții pornit.</p>"
   + ix("flux", "Ce se întâmplă când pui o întrebare", {
       "id": "c5-flux-neon", "intai": {"q": "Prima interogare de azi durează o secundă. A doua, o zecime. De ce?", "variante": ["Baza a ținut minte rezultatul", "Partea care calculează era oprită și s-a trezit la prima cerere", "Internetul era mai lent la început"], "corect": 1, "dupa": "Neon oprește partea care calculează (compute) când nu o folosește nimeni; datele (storage) rămân pe loc. Prima cerere o pornește, de aici secunda în plus."},
       "buton": "Trimite o interogare",
       "dus": "întrebarea pleacă", "intors": "rândurile se întorc",
       "gata": "gata, ai rezultatul",
       "titlu": "Apasă pe o stație",
       "intro": "Patru locuri prin care trece un <code>select</code>.",
       "statii": [
           {"n": "Scriptul tău", "et": "pandas", "ic": "🐍", "c": "ceas",
            "d": "<code>pd.read_sql(\"select ...\", con)</code>. Aici nu se "
                 "întâmplă nimic special: e doar un text trimis mai departe."},
           {"n": "Conexiunea", "et": "psycopg", "ic": "🔌", "c": "salvie",
            "d": "Șirul de conectare spune unde e baza, cine ești și pe ce "
                 "canal criptat. Stă în <code>.env</code>, niciodată în cod."},
           {"n": "Compute", "et": "pornește la cerere", "ic": "⚡", "c": "accent",
            "d": "Partea care execută interogarea. Dacă n-a mai fost "
                 "întrebată nimic de câteva minute, e oprită, și prima "
                 "întrebare o trezește. De aici vine „serverless”, și tot de "
                 "aici vine întârzierea de o secundă la prima cerere."},
           {"n": "Storage", "et": "mereu acolo", "ic": "🗄️", "c": "text-2",
            "d": "Datele propriu-zise, separate de partea care calculează. "
                 "Fiindcă sunt separate, se poate face o ramură: o copie a "
                 "bazei pe care experimentezi, fără să atingi originalul."}]})
   + nota("CE SE VEDE DIN SLIDE-UL ĂSTA",
          "Separarea dintre compute și storage e motivul pentru care Neon "
          "poate face ramuri la fel ca Git: datele stau pe loc, se pornește "
          "doar altă parte care calculează peste ele."),
   manual=
   "<h2>Postgres, fără server de întreținut</h2>"
   "<p>Neon e o platformă care oferă PostgreSQL complet gestionat, accesibil "
   "prin SQL standard. Tot ce știți despre Postgres rămâne valabil: aceleași "
   "comenzi, aceleași tipuri, aceleași extensii.</p>"
   "<p>Trei lucruri o deosebesc de un Postgres pus pe un server:</p>"
   "<ul>"
   "<li><strong>Serverless.</strong> Partea care execută interogările pornește "
   "automat la prima cerere și se oprește când nu mai e folosită. Plătești "
   "cât folosești, iar pentru un proiect de curs asta înseamnă, de obicei, "
   "zero.</li>"
   "<li><strong>Branching.</strong> Poți face o copie izolată a bazei, ca o "
   "ramură în Git, ca să încerci o transformare fără să strici datele "
   "bune.</li>"
   "<li><strong>Compute separat de storage.</strong> Motivul tehnic din "
   "spatele primelor două.</li>"
   "</ul>"
   + ix("flux", "Ce se întâmplă când pui o întrebare", {
       "id": "c5-flux-neon", "intai": {"q": "Prima interogare de azi durează o secundă. A doua, o zecime. De ce?", "variante": ["Baza a ținut minte rezultatul", "Partea care calculează era oprită și s-a trezit la prima cerere", "Internetul era mai lent la început"], "corect": 1, "dupa": "Neon oprește partea care calculează (compute) când nu o folosește nimeni; datele (storage) rămân pe loc. Prima cerere o pornește, de aici secunda în plus."},
       "buton": "Trimite o interogare",
       "dus": "întrebarea pleacă", "intors": "rândurile se întorc",
       "gata": "gata, ai rezultatul",
       "titlu": "Apasă pe o stație",
       "intro": "Patru locuri prin care trece un <code>select</code>.",
       "statii": [
           {"n": "Scriptul tău", "et": "pandas", "ic": "🐍", "c": "ceas",
            "d": "Un text SQL trimis mai departe."},
           {"n": "Conexiunea", "et": "psycopg", "ic": "🔌", "c": "salvie",
            "d": "Șirul de conectare stă în <code>.env</code>, niciodată în cod."},
           {"n": "Compute", "et": "pornește la cerere", "ic": "⚡", "c": "accent",
            "d": "Se trezește la prima întrebare. De aici întârzierea de o "
                 "secundă la prima cerere."},
           {"n": "Storage", "et": "mereu acolo", "ic": "🗄️", "c": "text-2",
            "d": "Datele, separate de partea care calculează. De aceea se pot "
                 "face ramuri."}]}))


sl("s12", "Baze de date", "Postgres sau MySQL",
   "<h2>Două baze, două profiluri</h2>"
   + ix("prezice", "Ce bază, pentru proiectul vostru", {
       "id": "c5-prezice-baza", "poarta": False, "fisier": "baza/intrebari.sql",
       "cod": "-- vreti contururile judetelor in baza\n"
              "-- si o intrebare: ce regiuni se invecineaza cu Clujul?\n"
              "select b.nume\n"
              "from regiuni a join regiuni b\n"
              "  on st_touches(a.contur, b.contur)\n"
              "where a.cod = 'RO113';",
       "intrebare": "Pe ce bază merge interogarea asta, fără nimic în plus?",
       "variante": ["MySQL: e mai rapid la citiri", "PostgreSQL, cu extensia PostGIS", "Pe orice bază SQL", "Pe niciuna: se face doar în Python"],
       "corect": 1,
       "indiciu": "st_touches e o funcție geografică. Care dintre cele două baze are o extensie geografică puternică?",
       "laBine": "Date eterogene, hărți, analiză: Postgres.",
       "explicatie": "<code>st_touches</code> vine din PostGIS, extensia geografică a lui Postgres. Niciuna dintre baze nu e "
                     "„mai bună”: MySQL e simplu și foarte rapid la citiri, potrivit pentru aplicații web cu trafic mare. "
                     "Postgres are tipuri bogate (JSONB) și extensii (PostGIS, pgvector), potrivite pentru analiză. "
                     "Proiectul vostru cade limpede pe Postgres.",
       "iesire": "  nume\n------------\n Bihor\n Sălaj\n Maramureș\n Bistrița-Năsăud\n Mureș\n Alba"})
   + tabel(["Diferență", "PostgreSQL", "MySQL"],
           [["Caracter", "puternic, flexibil, multe funcții avansate",
             "simplu, ușor, foarte rapid în aplicații web"],
            ["Tipuri de date", "JSONB, PostGIS, array-uri, tipuri proprii",
             "tipuri clasice, plus JSON simplu"],
            ["Performanță", "scrieri concurente și analitic",
             "citiri rapide, CRUD"],
            ["Ecosistem", "extensii puternice: PostGIS, pgvector",
             "simplu, stabil, foarte răspândit în web"]]),
   manual=
   "<h2>Două baze, două profiluri</h2>"
   "<p>Întrebarea „care e mai bună” n-are răspuns; întrebarea „care e mai "
   "potrivită pentru ce fac eu” are.</p>"
   + tabel(["Diferență", "PostgreSQL", "MySQL"],
           [["Caracter", "puternic, flexibil, multe funcții avansate",
             "simplu, ușor, foarte rapid în aplicații web"],
            ["Tipuri de date", "JSONB, PostGIS, array-uri, tipuri proprii",
             "tipuri clasice, plus JSON simplu"],
            ["Performanță", "scrieri concurente și analitic",
             "citiri rapide, CRUD"],
            ["Folosire", "analitică, aplicații complexe, date eterogene, GIS",
             "aplicații web mari, e-commerce, trafic intens"],
            ["Ecosistem", "extensii puternice: PostGIS, pgvector",
             "simplu, stabil, foarte răspândit în web"]])
   + ix("prezice", "Ce bază, pentru proiectul vostru", {
       "id": "c5-prezice-baza", "poarta": False, "fisier": "baza/intrebari.sql",
       "cod": "-- vreti contururile judetelor in baza\n"
              "-- si o intrebare: ce regiuni se invecineaza cu Clujul?\n"
              "select b.nume\n"
              "from regiuni a join regiuni b\n"
              "  on st_touches(a.contur, b.contur)\n"
              "where a.cod = 'RO113';",
       "intrebare": "Pe ce bază merge interogarea asta, fără nimic în plus?",
       "variante": ["MySQL: e mai rapid la citiri", "PostgreSQL, cu extensia PostGIS", "Pe orice bază SQL", "Pe niciuna: se face doar în Python"],
       "corect": 1,
       "indiciu": "st_touches e o funcție geografică. Care dintre cele două baze are o extensie geografică puternică?",
       "laBine": "Date eterogene, hărți, analiză: Postgres.",
       "explicatie": "<code>st_touches</code> vine din PostGIS, extensia geografică a lui Postgres. Niciuna dintre baze nu e "
                     "„mai bună”: MySQL e simplu și foarte rapid la citiri, potrivit pentru aplicații web cu trafic mare. "
                     "Postgres are tipuri bogate (JSONB) și extensii (PostGIS, pgvector), potrivite pentru analiză. "
                     "Proiectul vostru cade limpede pe Postgres.",
       "iesire": "  nume\n------------\n Bihor\n Sălaj\n Maramureș\n Bistrița-Năsăud\n Mureș\n Alba"}))


sl("s13", "Baze de date", "Conectarea",
   "<h2>Șirul de conectare, și unde stă</h2>"
   "<p>Un singur șir conține adresa, utilizatorul și parola. Dacă ajunge pe "
   "GitHub, baza voastră e a oricui.</p>"
   + ix("cod", "Conectează-te fără să scrii parola în cod", {
       "id": "c5-cod-conectare", "indiciu": "Toate trei sunt importate în primele rânduri: funcția care citește .env, funcția din os care citește o variabilă de mediu (getenv) și funcția care face motorul de conectare.",
       "iesire": "PostgreSQL 17.5 on x86_64-pc-linux-gnu, compiled by gcc ...", "fisier": "baza/conecteaza.py",
       "sarcina": "Șirul vine din <code>.env</code>, nu din fișierul cu cod.",
       "cod": "import os\n"
              "import pandas as pd\n"
              "from dotenv import load_dotenv\n"
              "from sqlalchemy import create_engine\n\n"
              "# citeste .env si pune valorile in mediu\n"
              "{{1}}()\n\n"
              "# postgresql+psycopg://user:parola@host/baza?sslmode=require\n"
              "url = os.{{2}}(\"DATABASE_URL\")\n"
              "if not url:\n"
              "    raise SystemExit(\"lipseste DATABASE_URL din .env\")\n\n"
              "motor = {{3}}(url)\n\n"
              "# proba: daca merge linia asta, conexiunea e buna\n"
              "print(pd.read_sql(\"select version()\", motor).iloc[0, 0])",
       "goluri": {
           "1": {"ok": ["load_dotenv"], "ajutor": "funcția"},
           "2": {"ok": ["getenv", "environ.get"], "ajutor": "funcția"},
           "3": {"ok": ["create_engine"], "ajutor": "funcția"}},
       "laBine": "Linia cu <code>raise</code> pare de prisos până în ziua în "
                 "care cineva clonează depozitul fără <code>.env</code> și "
                 "primește o eroare de conectare de neînțeles.",
       "laRau": "Toate trei sunt importate sus, în primele patru linii.",
       "explicatie": "<code>.env</code> intră în <code>.gitignore</code> "
                     "înainte de primul <code>add</code>. În depozit pui un "
                     "<code>.env.exemplu</code> cu numele variabilelor și "
                     "valori false, ca să știe colegii ce le trebuie."})
   + nota("ATENȚIE", "Șirul de conectare conține parola în clar. Dacă îl pui "
                     "din greșeală într-un commit, nu e destul să-l ștergi: "
                     "rămâne în istorie. Schimbi parola din Neon, imediat."),
   manual=
   "<h2>Șirul de conectare, și unde stă</h2>"
   "<p>Neon vă dă un șir de forma "
   "<code>postgresql://utilizator:parola@gazdă/bază?sslmode=require</code>. "
   "Conține tot ce trebuie ca să intri în bază, inclusiv parola, în clar.</p>"
   "<p>Regula e simplă și n-are excepții: șirul stă într-un fișier "
   "<code>.env</code>, iar <code>.env</code> e în <code>.gitignore</code> de "
   "la început. În depozit pui un <code>.env.exemplu</code> cu numele "
   "variabilelor și valori false.</p>"
   + ix("cod", "Conectează-te fără să scrii parola în cod", {
       "id": "c5-cod-conectare", "indiciu": "Toate trei sunt importate în primele rânduri: funcția care citește .env, funcția din os care citește o variabilă de mediu (getenv) și funcția care face motorul de conectare.",
       "iesire": "PostgreSQL 17.5 on x86_64-pc-linux-gnu, compiled by gcc ...", "fisier": "baza/conecteaza.py",
       "sarcina": "Șirul vine din <code>.env</code>.",
       "cod": "import os\n"
              "import pandas as pd\n"
              "from dotenv import load_dotenv\n"
              "from sqlalchemy import create_engine\n\n"
              "{{1}}()\n"
              "url = os.{{2}}(\"DATABASE_URL\")\n"
              "if not url:\n"
              "    raise SystemExit(\"lipseste DATABASE_URL din .env\")\n\n"
              "motor = {{3}}(url)\n"
              "print(pd.read_sql(\"select version()\", motor).iloc[0, 0])",
       "goluri": {
           "1": {"ok": ["load_dotenv"], "ajutor": "funcția"},
           "2": {"ok": ["getenv", "environ.get"], "ajutor": "funcția"},
           "3": {"ok": ["create_engine"], "ajutor": "funcția"}},
       "laBine": "Verificarea explicită scutește colegii de erori de neînțeles.",
       "laRau": "Toate trei sunt importate în primele patru linii.",
       "explicatie": "Dacă parola ajunge într-un commit, o schimbi din Neon: "
                     "ștergerea din fișier nu o scoate din istorie."}))


sl("s14", "Baze de date", "Scrii și citești",
   "<h2>Tabelul vostru, în bază</h2>"
   + ix("cod", "Pune tabelul curat în Postgres", {
       "id": "c5-cod-tosql", "indiciu": "Dacă tabelul există deja, îl înlocuiești: \"replace\". Citirea din bază se face cu read_sql. Constrângerea care face cheia unică e primary key.",
       "iesire": "178 scrise, 178 gasite", "fisier": "baza/incarca.py",
       "sarcina": "Scrii tabelul, apoi îl citești înapoi ca să verifici.",
       "cod": "d = pd.read_csv(\"date/curat/tabel_final.csv\")\n\n"
              "# scrie tabelul; daca exista deja, il inlocuieste\n"
              "d.to_sql(\"sci_tari\", motor, if_exists={{1}}, index=False)\n\n"
              "# citeste inapoi si compara\n"
              "verif = pd.{{2}}(\"select count(*) as n from sci_tari\", motor)\n"
              "print(len(d), \"scrise,\", verif[\"n\"][0], \"gasite\")\n\n"
              "# o cheie primara, ca baza sa refuze duplicatele\n"
              "with motor.begin() as c:\n"
              "    c.exec_driver_sql(\n"
              "        \"alter table sci_tari add {{3}} (cod)\")",
       "goluri": {
           "1": {"ok": ["\"replace\"", "'replace'"], "ajutor": "ce face dacă există"},
           "2": {"ok": ["read_sql", "read_sql_query"], "ajutor": "funcția"},
           "3": {"ok": ["primary key", "primary key", "PRIMARY KEY"],
                 "ajutor": "constrângerea"}},
       "laBine": "Cheia primară e lucrul pe care un CSV nu-l poate face: de "
                 "acum baza refuză un al doilea rând cu același cod.",
       "laRau": "Primul se scrie ca text, între ghilimele: "
                "<code>\"replace\"</code>, <code>\"append\"</code> sau "
                "<code>\"fail\"</code>.",
       "explicatie": "<code>if_exists=\"replace\"</code> șterge tabelul și-l "
                     "scrie din nou. E ce vrei cât timp construiești, dar "
                     "atenție: într-o bază pe care o folosesc și alții, "
                     "<code>\"append\"</code> e mai cuminte, iar "
                     "<code>\"fail\"</code> e cel mai cuminte."}),
   manual=
   "<h2>Tabelul vostru, în bază</h2>"
   "<p><code>to_sql</code> și <code>read_sql</code> sunt cele două capete ale "
   "drumului. Între ele, singura grijă e ce se întâmplă când rulezi scriptul "
   "a doua oară.</p>"
   + ix("cod", "Pune tabelul curat în Postgres", {
       "id": "c5-cod-tosql", "indiciu": "Dacă tabelul există deja, îl înlocuiești: \"replace\". Citirea din bază se face cu read_sql. Constrângerea care face cheia unică e primary key.",
       "iesire": "178 scrise, 178 gasite", "fisier": "baza/incarca.py",
       "sarcina": "Scrii tabelul, apoi îl citești înapoi ca să verifici.",
       "cod": "d = pd.read_csv(\"date/curat/tabel_final.csv\")\n\n"
              "d.to_sql(\"sci_tari\", motor, if_exists={{1}}, index=False)\n\n"
              "verif = pd.{{2}}(\"select count(*) as n from sci_tari\", motor)\n"
              "print(len(d), \"scrise,\", verif[\"n\"][0], \"gasite\")\n\n"
              "with motor.begin() as c:\n"
              "    c.exec_driver_sql(\n"
              "        \"alter table sci_tari add {{3}} (cod)\")",
       "goluri": {
           "1": {"ok": ["\"replace\"", "'replace'"], "ajutor": "ce face dacă există"},
           "2": {"ok": ["read_sql", "read_sql_query"], "ajutor": "funcția"},
           "3": {"ok": ["primary key", "PRIMARY KEY"], "ajutor": "constrângerea"}},
       "laBine": "Cheia primară e lucrul pe care un CSV nu-l poate face.",
       "laRau": "Primul se scrie între ghilimele.",
       "explicatie": "<code>\"replace\"</code> cât timp construiești, "
                     "<code>\"append\"</code> sau <code>\"fail\"</code> "
                     "într-o bază folosită și de alții."}))


sl("s15", "Baze de date", "SQL, cât vă trebuie",
   "<h2>Patru cuvinte și o ordine</h2>"
   "<p>Aceeași operație pe care o faceți în pandas, scrisă în limba bazei. "
   "Avantajul e că filtrarea se face acolo, și vine înapoi doar ce ai cerut.</p>"
   + ix("pas", "Ordinea în care lucrează baza", PAS_SQL)
   + ix("cod", "Scrie interogarea", {
       "id": "c5-cod-sql", "indiciu": "Două tabele se leagă cu join. Rândurile se filtrează cu where. Cele mai mari valori sus: ordine descrescătoare, desc.",
       "iesire": " geo | persoane |   sci\n-----+----------+--------\n IT  |  1073196 |  69327\n DE  |   776424 |  91228\n ES  |   620463 |  54179", "fisier": "baza/intrebari.sql",
       "sarcina": "Cele zece țări cu cei mai mulți români, și cât de legată "
                  "e România de fiecare.",
       "cod": "select\n"
              "    m.geo,\n"
              "    m.persoane,\n"
              "    s.sci\n"
              "from migratie m\n"
              "{{1}} legaturi s\n"
              "  on s.tara_1 = 'RO' and s.tara_2 = m.geo\n"
              "{{2}} m.citizen = 'RO'\n"
              "order by m.persoane {{3}}\n"
              "limit 10;",
       "goluri": {
           "1": {"ok": ["join", "inner join", "JOIN"], "ajutor": "cum legi tabelele"},
           "2": {"ok": ["where", "WHERE"], "ajutor": "filtrarea"},
           "3": {"ok": ["desc", "DESC"], "ajutor": "ordinea"}},
       "laBine": "<code>join ... on</code> e exact <code>pd.merge(..., "
                 "on=...)</code>, scris altfel. Aceleași feluri: "
                 "<code>left join</code>, <code>full outer join</code>.",
       "laRau": "Primul leagă două tabele pe o condiție. Al doilea filtrează "
                "rândurile. Al treilea pune cele mai mari valori sus.",
       "explicatie": "Ordinea în care se scrie nu e ordinea în care se "
                     "execută: baza filtrează întâi "
                     "(<code>where</code>), apoi grupează, apoi sortează, "
                     "apoi taie (<code>limit</code>). De asta "
                     "<code>limit 10</code> nu face interogarea de zece ori "
                     "mai rapidă: tot tabelul a fost parcurs oricum."})
   + nota("Ce iese",
          "Italia, Germania, Spania sus la migrație, cu SCI-uri care nu urmează "
          "aceeași ordine. E ghicitoarea din cursul 1, de data asta scoasă cu "
          "o interogare.", True),
   manual=
   "<h2>Patru cuvinte și o ordine</h2>"
   "<p>N-aveți nevoie de SQL avansat. Aveți nevoie de cinci construcții, care "
   "acoperă aproape tot ce faceți în pandas.</p>"
   + tabel(["În pandas", "În SQL"],
           [["~d[d.cod == 'RO']", "~where cod = 'RO'"],
            ["~d.merge(t, on='cod')", "~join tari t on t.cod = d.cod"],
            ["~d.groupby('cod').sum()", "~group by cod"],
            ["~d.sort_values('sci', ascending=False)", "~order by sci desc"],
            ["~d.head(10)", "~limit 10"]])
   + ix("pas", "Ordinea în care lucrează baza", PAS_SQL)
   + ix("cod", "Scrie interogarea", {
       "id": "c5-cod-sql", "indiciu": "Două tabele se leagă cu join. Rândurile se filtrează cu where. Cele mai mari valori sus: ordine descrescătoare, desc.",
       "iesire": " geo | persoane |   sci\n-----+----------+--------\n IT  |  1073196 |  69327\n DE  |   776424 |  91228\n ES  |   620463 |  54179", "fisier": "baza/intrebari.sql",
       "sarcina": "Cele zece țări cu cei mai mulți români, cu SCI-ul lor.",
       "cod": "select m.geo, m.persoane, s.sci\n"
              "from migratie m\n"
              "{{1}} legaturi s on s.tara_1 = 'RO' and s.tara_2 = m.geo\n"
              "{{2}} m.citizen = 'RO'\n"
              "order by m.persoane {{3}}\n"
              "limit 10;",
       "goluri": {
           "1": {"ok": ["join", "inner join", "JOIN"], "ajutor": "cum legi tabelele"},
           "2": {"ok": ["where", "WHERE"], "ajutor": "filtrarea"},
           "3": {"ok": ["desc", "DESC"], "ajutor": "ordinea"}},
       "laBine": "<code>join ... on</code> e <code>pd.merge</code> scris altfel.",
       "laRau": "Al treilea pune valorile mari sus.",
       "explicatie": "Ordinea de scriere nu e ordinea de execuție: "
                     "<code>where</code>, apoi grupare, apoi sortare, apoi "
                     "<code>limit</code>."}))


sl("s16", "Baze de date", "Ramurile bazei",
   "<h2>Un branch, dar pentru date</h2>"
   "<p>Aceeași idee ca la Git, altceva ramificat: nu codul, ci baza.</p>"
   + tabel(["Situație", "Fără ramură", "Cu ramură"],
           [["Vrei să încerci o transformare mare",
             "faci o copie a bazei, manual", "o ramură, în câteva secunde"],
            ["Vrei să testezi scriptul de încărcare",
             "scrii peste datele bune", "scrii în ramură, le compari"],
            ["Doi colegi lucrează în paralel",
             "se calcă pe tabele", "fiecare pe ramura lui"],
            ["Ai stricat ceva",
             "restaurezi din backup, dacă ai", "ștergi ramura"]])
   + nota("PENTRU PROIECT",
          "Nu e obligatoriu, dar e ieftin: faceți o ramură înainte de "
          "încărcarea mare, și o ștergeți după ce ați verificat. E cel mai "
          "simplu fel de a nu pierde o după-amiază."))


sl("s17", "Baze de date", "Unde faci ce",
   "<h2>În bază, sau în pandas?</h2>"
   "<p>Aceeași operație se poate scrie în amândouă. Regula practică: "
   "<strong>filtrezi și agregi în bază, analizezi în pandas.</strong></p>"
   + ix("prezice", "Ce aduci pe rețea", {
       "id": "c5-prezice-unde", "poarta": False, "fisier": "baza/unde.py",
       "cod": "# in baza: 40 de milioane de randuri (tara, an, sci)\n\n"
              "# A\n"
              "d = pd.read_sql(\"select * from legaturi\", con)\n"
              "m = d[d[\"an\"] == 2022].groupby(\"tara\")[\"sci\"].mean()\n\n"
              "# B\n"
              "m = pd.read_sql(\"select tara, avg(sci) from legaturi \"\n"
              "                \"where an = 2022 group by tara\", con)",
       "intrebare": "Amândouă dau aceeași medie pe țară. Câte rânduri vin pe rețea, în fiecare?",
       "variante": ["A: 40 de milioane · B: 40 de milioane", "A: 40 de milioane · B: câte o țară, sub 200",
                    "A: sub 200 · B: sub 200", "A: un rând · B: un rând"],
       "corect": 1,
       "indiciu": "În A, ce întoarce select * ? În B, filtrarea și gruparea le face baza, înainte să trimită ceva.",
       "laBine": "Lasă baza să reducă datele; adu în pandas doar ce a rămas.",
       "explicatie": "A aduce tot tabelul în memorie și abia apoi filtrează. B lasă baza să filtreze și să grupeze, și trimite înapoi un rând pe țară. "
                     "Regula: în bază ce reduce datele multe (filtrare, grupare, legare de tabele mari); în pandas ce e de încercat "
                     "pe date puține (grafice, modele, variante de transformare).",
       "iesire": "A: 40.000.000 de rânduri aduse\nB: 178 de rânduri aduse"}),
   manual=
   "<h2>În bază, sau în pandas?</h2>"
   "<p>Întrebarea apare la fiecare pas, iar răspunsul e aproape mereu același: "
   "lasă baza să reducă datele, și adu în pandas doar ce a rămas.</p>"
   "<p>Motivul nu e viteza bazei în sine, ci rețeaua: fiecare rând adus "
   "costă. Un <code>select count(*) group by tara</code> trimite înapoi "
   "câteva sute de rânduri; același lucru făcut prin citirea întregului "
   "tabel în pandas trimite milioane.</p>"
   + ix("prezice", "Ce aduci pe rețea", {
       "id": "c5-prezice-unde", "poarta": False, "fisier": "baza/unde.py",
       "cod": "# in baza: 40 de milioane de randuri (tara, an, sci)\n\n"
              "# A\n"
              "d = pd.read_sql(\"select * from legaturi\", con)\n"
              "m = d[d[\"an\"] == 2022].groupby(\"tara\")[\"sci\"].mean()\n\n"
              "# B\n"
              "m = pd.read_sql(\"select tara, avg(sci) from legaturi \"\n"
              "                \"where an = 2022 group by tara\", con)",
       "intrebare": "Amândouă dau aceeași medie pe țară. Câte rânduri vin pe rețea, în fiecare?",
       "variante": ["A: 40 de milioane · B: 40 de milioane", "A: 40 de milioane · B: câte o țară, sub 200",
                    "A: sub 200 · B: sub 200", "A: un rând · B: un rând"],
       "corect": 1,
       "indiciu": "În A, ce întoarce select * ? În B, filtrarea și gruparea le face baza, înainte să trimită ceva.",
       "laBine": "Lasă baza să reducă datele; adu în pandas doar ce a rămas.",
       "explicatie": "A aduce tot tabelul în memorie și abia apoi filtrează. B lasă baza să filtreze și să grupeze, și trimite înapoi un rând pe țară. "
                     "Regula: în bază ce reduce datele multe (filtrare, grupare, legare de tabele mari); în pandas ce e de încercat "
                     "pe date puține (grafice, modele, variante de transformare).",
       "iesire": "A: 40.000.000 de rânduri aduse\nB: 178 de rânduri aduse"}))


# ===========================================================================
#  19-21. Proiectul
# ===========================================================================

sl("s19", "Proiectul tău", "Fă tabelul final",
   "<h2>Un tabel, o unitate, o bază</h2>"
   "<p>Ce aveți de făcut până data viitoare.</p>"
   + ix("etape", "Pașii", {
       "titlu": "Patru pași", "intro": "Apasă pe fiecare.",
       "etape": [
           {"nume": "Scrieți unitatea", "unde": "decizii.md",
            "text": "O propoziție: „un rând în tabelul nostru final înseamnă "
                    "___”. Toată echipa trebuie să dea același răspuns."},
           {"nume": "Îmbinați", "unde": "agregare/uneste.py",
            "text": "Un script care pornește de la fișierele curate și scoate "
                    "un singur tabel. Cu <code>how</code> scris explicit, cu "
                    "<code>validate</code>, și cu numărul de rânduri tipărit "
                    "înainte și după."},
           {"nume": "Încărcați", "unde": "baza/incarca.py",
            "text": "Tabelul în Neon, cu o cheie primară. Șirul de conectare "
                    "în <code>.env</code>, și <code>.env</code> în "
                    "<code>.gitignore</code>."},
           {"nume": "Puneți o întrebare", "unde": "baza/intrebari.sql",
            "text": "Un <code>select</code> scris de voi, care răspunde la "
                    "ceva din întrebarea voastră de cercetare. Nu trebuie să "
                    "fie complicat, trebuie să fie al vostru."}]})
   + ix("dovada", "Dovada", {
       "id": "c5-dovada-baza",
       "sarcina": "Rulează comenzile și lipește ce scrie.",
       "pasi": [
           {"t": "Îmbinarea nu a înmulțit rândurile",
            "cmd": "python agregare/uneste.py",
            "gol": "lipește linia cu înainte -> după",
            "cauta": r"\d+[\s\S]*\d+",
            "daca_nu": "Caut două numere: câte rânduri aveai și câte ai acum. "
                       "Dacă scriptul nu le tipărește, adaugă linia de la "
                       "slide-ul 5."},
           {"t": "Tabelul e în bază",
            "cmd": "python -c \"import baza.conecteaza as b, pandas as pd; "
                   "print(pd.read_sql('select count(*) from sci_tari', b.motor))\"",
            "gol": "lipește numărul",
            "cauta": r"\d+",
            "daca_nu": "Caut numărul de rânduri din tabel. Dacă dă eroare de "
                       "conectare, verifică DATABASE_URL din .env."},
           {"t": "Secretele nu sunt în depozit",
            "cmd": "git check-ignore -v .env",
            "gol": "lipește linia",
            "cauta": r"gitignore",
            "daca_nu": "Dacă nu scrie nimic, <code>.env</code> NU e ignorat. "
                       "Adaugă-l în <code>.gitignore</code> acum."}],
       "explicatie": "Ultimul pas e cel mai important dintre cele trei. "
                     "Celelalte două se pot repara oricând; o parolă ajunsă "
                     "în istorie, nu."}),
   manual=
   "<h2>Un tabel, o unitate, o bază</h2>"
   "<p>Pasul de proiect al acestei lecții are patru bucăți, iar a patra e cea "
   "care arată că baza de date v-a folosit la ceva, nu doar că există.</p>"
   + ix("etape", "Pașii", {
       "titlu": "Patru pași", "intro": "Apasă pe fiecare.",
       "etape": [
           {"nume": "Scrieți unitatea", "unde": "decizii.md",
            "text": "„Un rând în tabelul nostru final înseamnă ___”."},
           {"nume": "Îmbinați", "unde": "agregare/uneste.py",
            "text": "Un script de la fișierele curate la un singur tabel."},
           {"nume": "Încărcați", "unde": "baza/incarca.py",
            "text": "Tabelul în Neon, cu cheie primară, cu secretele în .env."},
           {"nume": "Puneți o întrebare", "unde": "baza/intrebari.sql",
            "text": "Un select al vostru, legat de întrebarea de cercetare."}]})
   + ix("dovada", "Dovada", {
       "id": "c5-dovada-baza",
       "sarcina": "Rulează comenzile și lipește ce scrie.",
       "pasi": [
           {"t": "Îmbinarea nu a înmulțit rândurile",
            "cmd": "python agregare/uneste.py",
            "gol": "lipește linia cu înainte -> după",
            "cauta": r"\d+[\s\S]*\d+",
            "daca_nu": "Caut două numere: înainte și după."},
           {"t": "Tabelul e în bază",
            "cmd": "python -c \"import baza.conecteaza as b, pandas as pd; "
                   "print(pd.read_sql('select count(*) from sci_tari', b.motor))\"",
            "gol": "lipește numărul",
            "cauta": r"\d+",
            "daca_nu": "Verifică DATABASE_URL din .env."},
           {"t": "Secretele nu sunt în depozit",
            "cmd": "git check-ignore -v .env",
            "gol": "lipește linia",
            "cauta": r"gitignore",
            "daca_nu": "Dacă nu scrie nimic, .env nu e ignorat."}],
       "explicatie": "Ultimul pas e cel mai important dintre cele trei."}))


sl("s20", "Proiectul tău", "Unitatea voastră",
   "<h2>Scrieți-o acum</h2>"
   + ix("asteptari", "Un rând în tabelul vostru", {
       "id": "c5-unitate", "tip": "unitate", "minim": 40,
       "sarcina": "Completează: „Un rând în tabelul nostru final înseamnă "
                  "___, iar cheia care îl identifică e ___.”",
       "exemplu": "De exemplu: un rând înseamnă o pereche de țări, cu SCI, "
                  "migranții în ambele direcții și distanța, iar cheia e "
                  "(tara_1, tara_2). Sau: un rând e o pereche județ românesc, "
                  "provincie italiană, cu cheia (judet, provincie).",
       "multumesc": "O citesc înainte de cursul următor, și o compar cu ce "
                    "scrie în decizii.md."}),
   manual=
   "<h2>Scrieți-o acum</h2>"
   "<p>Propoziția asta pare banală până o scrieți: de obicei e momentul în "
   "care echipa descoperă că doi membri lucrau la tabele cu forme diferite.</p>"
   + ix("asteptari", "Un rând în tabelul vostru", {
       "id": "c5-unitate", "tip": "unitate", "minim": 40,
       "sarcina": "Completează: „Un rând în tabelul nostru final înseamnă "
                  "___, iar cheia care îl identifică e ___.”",
       "exemplu": "De exemplu: o pereche de țări, cu cheia (tara_1, tara_2).",
       "multumesc": "O citesc înainte de cursul următor."}))


sl("s21", "Mai departe", "Până data viitoare",
   "<h2>Cursul 6: analiza exploratorie</h2>"
   "<p>Aveți un tabel. Data viitoare ne uităm la el: statistici descriptive, "
   "vizualizare exploratorie, și ce se vede într-un grafic dar nu într-un "
   "rezumat numeric.</p>"
   + tabel(["Ce aduceți", "Unde"],
           [["Tabelul final, îmbinat", "~date/curat/tabel_final.csv"],
            ["Scriptul de îmbinare", "~agregare/uneste.py"],
            ["Tabelul încărcat în Neon", "o captură cu numărul de rânduri"],
            ["Unitatea de analiză, scrisă", "~decizii.md"],
            ["Un select al vostru", "~baza/intrebari.sql"]])
   + nota("DACĂ V-A RĂMAS CEVA",
          "Manualul lecției are tot ce am spus azi, pe larg, și puteți relua "
          "exercițiile de câte ori vreți. Ce faceți acolo se vede la mine, "
          "dar nu e obligatoriu și nu se notează.")
   + surse("Documentația agregării și a bazei", [
       ("pandas: merge, join, concat", "https://pandas.pydata.org/docs/user_guide/merging.html", "cele cinci feluri de îmbinare și <code>validate</code>"),
       ("pandas: groupby", "https://pandas.pydata.org/docs/user_guide/groupby.html", "grupare, <code>agg</code>, mai multe funcții deodată"),
       ("PostgreSQL: tutorialul", "https://www.postgresql.org/docs/current/tutorial.html", "<code>select</code>, <code>where</code>, <code>join</code>, <code>group by</code>, de la zero"),
       ("Neon: documentația", "https://neon.com/docs/introduction", "proiect, conectare, ramuri"),
   ]),
   manual=
   "<h2>Cursul 6: analiza exploratorie</h2>"
   "<p>Cu tabelul final în mână, lecția următoare e despre cum te uiți la el: "
   "statistici descriptive, distribuții, și vizualizare exploratorie, adică "
   "graficele pe care le faci pentru tine, nu pentru raport.</p>"
   + tabel(["Ce aduceți", "Unde"],
           [["Tabelul final, îmbinat", "~date/curat/tabel_final.csv"],
            ["Scriptul de îmbinare", "~agregare/uneste.py"],
            ["Tabelul încărcat în Neon", "o captură cu numărul de rânduri"],
            ["Unitatea de analiză, scrisă", "~decizii.md"],
            ["Un select al vostru", "~baza/intrebari.sql"]])
   + surse("Documentația agregării și a bazei", [
       ("pandas: merge, join, concat", "https://pandas.pydata.org/docs/user_guide/merging.html", "cele cinci feluri de îmbinare și <code>validate</code>"),
       ("pandas: groupby", "https://pandas.pydata.org/docs/user_guide/groupby.html", "grupare, <code>agg</code>, mai multe funcții deodată"),
       ("PostgreSQL: tutorialul", "https://www.postgresql.org/docs/current/tutorial.html", "<code>select</code>, <code>where</code>, <code>join</code>, <code>group by</code>, de la zero"),
       ("Neon: documentația", "https://neon.com/docs/introduction", "proiect, conectare, ramuri"),
   ]))


L.scrie_tot()
